/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003,2004 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _BCKCFG_H
#define _BCKCFG_H

const char BCKVERSION[] = "Blaster Construction Kit - v1.0";
const char BCKCOPYRIGHTYEAR[] = "2003,2004";
const char KNOWN_HASH[] = "2C 86 88 8F 2A F7 62 9B 35 09 C2 5F EF 57 8A 9D B0 50 78 6C";

const Uint8 DEBUGSECA1[] = { 0xA9, 0x08, 0x85, 0x14, 0x20, 0xBA, 0xCD, 0x20, 0xD9, 0xF5 };
const Uint8 DEBUGSECA2[] = { 0xEA, 0x20, 0x65, 0xF4, 0x20, 0xBA, 0xCD, 0x20, 0xE0, 0xFF };
const Uint8 DEBUGSECB1[] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
const Uint8 DEBUGSECB2[] = { 0xA5, 0x14, 0x29, 0x07, 0xD0, 0x03, 0x20, 0xD9, 0xF5, 0x60 };

const Uint8 DEBUGSECC1 = 0x08;
const Uint8 DEBUGSECC2 = 0x00;

const Uint32 DebugLocationA = 0x1C2CC;
const Uint32 DebugLocationB = 0x1FFF0;
const Uint32 DebugLocationC = 0x1C30E;

const Uint32 TextLocation = 0x27010;
const Uint32 GatewayLocation = 0x1DD8E;

const int NUM_GATES = 0x6C;
const int NUM_MISC = 17;

const Uint32 BossPointLocation = 0x1C5B2;
const Uint32 StartPointLocation = 0x1CA4B;

const Uint32 GateAStructureLocation = 0x19EA3;
const Uint32 GateBStructureLocation = 0x19EAA;

const Uint32 OverheadIceLocation = 0x1D275;
const Uint32 TankIceLocation = 0x196B5;

const Uint32 TankEnemyStatsLocation = 0x1A37A;
const Uint32 OverheadEnemyStatsLocation = 0;

const Uint32 TankEnemyStatsLength = 0x1E * 4;
const Uint32 OverheadEnemyStatsLength = 0x0F * 4;

const Uint32 BOSS_4_7_HP_LOCATION = 0x11716;
const Uint32 BOSS_4_ATTACK_PATTERN_LOCATION = 0x11957;
const int BOSS_4_ATTACK_PATTERN_LENGTH = 0x10;
const Uint32 BOSS_7_ATTACK_PATTERN_LOCATION = 0x11969;
const int BOSS_7_ATTACK_PATTERN_LENGTH = 0x32;
const Uint32 BOSS_2_6_HP_LOCATION = 0x11B66;
const Uint32 BOSS_2_6_HSPEED_LOCATION = 0x11B6A;
const Uint32 BOSS_2_6_VSPEED_LOCATION = 0x11B6E;
const Uint32 BOSS_3_HP_LOCATION = 0x1214B;
const Uint32 BOSS_3_SPAWN_PATTERN_X_LOCATION = 0x12186;
const Uint32 BOSS_3_SPAWN_PATTERN_Y_LOCATION = 0x12196;
const int BOSS_3_SPAWN_PATTERN_LENGTH = 0x10;
const Uint32 BOSS_3_ATTACK_PATTERN_LOCATION = 0x12352;
const int BOSS_3_ATTACK_PATTERN_LENGTH = 0x14;
const Uint32 BOSS_1_HP_LOCATION = 0x12585;
const Uint32 BOSS_1_HSPEED_LOCATION = 0x1258F;
const Uint32 BOSS_1_VSPEED_LOCATION = 0x12593;
const Uint32 BOSS_1_RIGHT_SPEED_LOCATION = 0x125B7;
const Uint32 BOSS_1_LEFT_SPEED_LOCATION = 0x125BB;
const Uint32 BOSS_1_DOWN_SPEED_LOCATION = 0x125CA;
const Uint32 BOSS_1_UP_SPEED_LOCATION = 0x125CE;
const Uint32 BOSS_5_HP_LOCATION = 0x126C7;
const Uint32 BOSS_8_HP_LOCATION = 0x12A1A;
const Uint32 BOSS_FINAL_HP_LOCATION = 0x12C6F;

struct sConfig {
	int GFXWidth;
	int GFXHeight;
	int GFXBPP;
	char ROMFilename[80];
	char EMUFilename[80];
};

struct sLevelInfo {
	Uint32 CharacterLocation;
	Uint32 PaletteLocation;
	Uint32 USBLocation;
	Uint32 SBLocation;
	Uint32 BLocation;
	Uint32 MapLocation;
	Uint32 USBAttributeLocation;
	Uint32 ScrollTableLocation;
	Uint32 NumUSB;
	Uint32 NumSB;
	Uint32 NumB;
	Uint32 ThingTypeLocation;
	Uint32 ThingXLocation;
	Uint32 ThingYLocation;
	Uint32 NumThing;
	Uint8 LevelNum;
	bool isOverhead;
};

extern FILE *Debug;

#ifdef _DEBUG
inline void DEBUG(const char *X) { fprintf(Debug, X); }
inline void DEBUG(const char *X, int Y) { fprintf(Debug, X, Y); }
inline void DEBUG(const char *X, int Y, int Z) { fprintf(Debug, X, Y, Z); }
inline void DEBUGOPEN() { Debug = fopen("debug.log", "w"); }
#else
inline void DEBUG(const char *X) { }
inline void DEBUG(const char *X, int Y) { }
inline void DEBUG(const char *X, int Y, int Z) { }
inline void DEBUGOPEN() { }
#endif

#endif
