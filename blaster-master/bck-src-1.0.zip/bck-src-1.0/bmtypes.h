/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _BMTYPES_H
#define _BMTYPES_H 1

inline int subPalette(Uint8 Block) { return Block & 0x03; }

inline int isTGateway(Uint8 Block) { return ( Block & 0x08 ) && ( ! ( ( Block & 0x04 ) || ( Block & 0x80 ) ) ); }
inline int isTTunnel(Uint8 Block) { return ( Block & 0x08 ) && ( Block & 0x04 ) && ( ! ( Block & 0x80) ); }
inline int isTDoorway(Uint8 Block) { return ( Block & 0x80 ) && ( Block & 0x08 ); }
inline int isTDamaging(Uint8 Block) { return Block & 0x10; }
inline int isTLadder(Uint8 Block) { return Block & 0x20; }
inline int isTWater(Uint8 Block) { return ( Block & 0x40 ) && ( ! ( Block & 0x80) ); }
inline int isTSolid(Uint8 Block) { return Block & 0x80; }
inline int isTCrushable(Uint8 Block) { return ( Block & 0x80 ) && ( Block & 0x40 ); }

inline int isODoorway(Uint8 Block) { return ( Block & 0x08 ) && ( Block & 0x04 ); }
inline int isOOverhang(Uint8 Block) { return ( Block & 0x04 ) && ( ! ( Block & 0x10 ) ); }
inline int isOTunnel(Uint8 Block) { return ( Block & 0x08 ) && ( ! ( Block & 0x04 ) ); }
inline int isODamaging(Uint8 Block) { return ( Block & 0x10 ) && ( ! ( Block & 0x04 ) ); }
inline int isODeath(Uint8 Block) { return ( Block & 0x10 ) && ( Block & 0x04 ); }
inline int isOSolid(Uint8 Block) { return Block & 0x80; }
inline int isOCrushable(Uint8 Block) { return ( Block & 0x80 ) && ( Block & 0x40 ); }

const int NUM_TANK_THINGS = 0x57;
const int NUM_OVERHEAD_THINGS = 0x2A;

#ifdef _WIN32
#define isblank(x) isspace(x)		// Keeps the compiler happy

// Print message boxes (win32err.cpp)

void ERR(const char *X);
void ERR(const char *X, int Y);
void ERR(const char *X, int Y, int Z);
void ERR(const char *X, const char *Y);
void ERR(const char *X, const char *Y, int Z);

#else

// Just print to the console

inline void ERR(const char *X) { printf(X); }
inline void ERR(const char *X, int Y) { printf(X, Y); }
inline void ERR(const char *X, int Y, int Z) { printf(X, Y, Z); }
inline void ERR(const char *X, const char *Y) { printf(X, Y); }
inline void ERR(const char *X, const char *Y, int Z) { printf(X, Y, Z); }

#endif	// #ifdef _WIN32

#endif // #ifndef _BMTYPES_H
