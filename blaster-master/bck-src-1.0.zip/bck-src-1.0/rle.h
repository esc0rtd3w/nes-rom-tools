/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _RLE_H
#define _RLE_H 1

const int NUM_RLE = 19;

enum RLE_TYPE {
	RLE_PAUSE_SCREEN,
	RLE_INTRO_SCREEN,
	RLE_TITLE_SCREEN,
	RLE_ENDING_SCREEN,
	RLE_BOSS26,
	RLE_BOSS47,
	RLE_BOSS1,
	RLE_BOSS3,
	RLE_BOSS5,
	RLE_BOSS8,
	RLE_FINAL_BOSS_SCREEN,
	RLE_INTRO_SCREEN_1,
	RLE_INTRO_SCREEN_2,
	RLE_INTRO_SCREEN_3,
	RLE_INTRO_SCREEN_4,
	RLE_INTRO_SCREEN_5,
	RLE_INTRO_SCREEN_6,
	RLE_INTRO_SCREEN_7,
	RLE_INTRO_SCREEN_8
};

class cRLE {
	private:
		Uint8 CharData[4096];
		Uint8 Palette[16];
		Uint8 *RLEData;
		Uint32 DataLength;
		static cGFX *Graphics;
	public:
		cRLE();
		~cRLE();
		void LoadRLE(FILE *DataFile, RLE_TYPE RLE_Index);
		void SwitchTo();
		void DisplayRLE(int x, int y);
		inline int GetData(unsigned int index) { if (index >= DataLength) { return -1; } else { return RLEData[index]; } }
		inline void SetData(unsigned int index, Uint8 Data) { if (index >= DataLength) { return; } else { RLEData[index] = Data; } }
		static inline void SetGraphics(cGFX *NGraphics) { Graphics = NGraphics; }
};

#endif
