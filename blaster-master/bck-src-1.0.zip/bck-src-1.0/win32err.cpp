/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

// This file isn't needed at all except in Windows
#ifdef _WIN32
#include <windows.h>
#include <stdio.h>

void ERR(const char *X) 
{ 
	MessageBox(NULL, X, "Notice", MB_OK); 
}

void ERR(const char *X, int Y) 
{ 
	char Buffer[80];
	sprintf(Buffer, X, Y);
	MessageBox(NULL, Buffer, "Notice", MB_OK); 
}

void ERR(const char *X, int Y, int Z) 
{
	char Buffer[80];
	sprintf(Buffer, X, Y, Z);
	MessageBox(NULL, Buffer, "Notice", MB_OK);
}

void ERR(const char *X, const char *Y) 
{
	char Buffer[80];
	sprintf(Buffer, X, Y);
	MessageBox(NULL, Buffer, "Notice", MB_OK);
}

void ERR(const char *X, const char *Y, int Z) 
{ 
	char Buffer[80];
	sprintf(Buffer, X, Y, Z);
	MessageBox(NULL, Buffer, "Notice", MB_OK);
}
#endif

