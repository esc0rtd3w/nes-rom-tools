/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#ifdef _WIN32
#include <windows.h>
#endif
#include "nesgfx.h"
#include "video.h"
#include "bmtypes.h"
#include "level.h"
#include "bckcfg.h"
#include "SHA1.h"
#include "rle.h"

#ifdef _DEBUG
FILE *Debug;
#endif

enum {
	BROWSE_SAVE,
	BROWSE_REVERT,
	BROWSE_QUITSAVE,
	BROWSE_QUIT,
	BROWSE_TEST,
	BROWSE_SWITCHSAVE,
	BROWSE_SWITCH
};

int BrowseLevel(cLevel &Level, cGFX *Graphics, cRLE *RLE);

inline void Exit(int x) { SDL_Quit(); exit(x); }

int main(int argc, char *argv[])
{
	SDL_Event event;
	FILE *DataFile, *ConfigFile, *LevelInfoFile;
	sConfig Config;
	sLevelInfo LevelInfo;	
	cGFX Graphics;
	cLevel Levels[16];
	cRLE RLE[NUM_RLE];
	Uint8 CharData[4096],
		TextData[4096],
		Palette[16],
		GatewayData[NUM_GATES * 3];
	char Type;
	char *LevelInfoFilename;
	char Buffer[80];
	Uint16 ToDisplay = 0;
	int LevelInfoType;
	bool AllLevels = false;
	Uint8 mask[128] = { 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x1F, 0xF8, 0x00, 
					0x00, 0x3F, 0xFC, 0x00, 
					0x00, 0x7F, 0xFE, 0x00, 
					0x00, 0xFF, 0xFF, 0x00, 
					0x00, 0xFF, 0xFF, 0x00, 
					0x01, 0xFF, 0xFF, 0x80,	
					0x01, 0xFF, 0xFF, 0x80,	
					0x01, 0xFF, 0xFF, 0x80,	
					0x01, 0xFF, 0xFF, 0x80,	
					0x01, 0xFF, 0xFF, 0x80,	
					0x01, 0xFF, 0xFF, 0x80,	
					0x01, 0xFF, 0xFF, 0x80,	
					0x00, 0xFF, 0xFF, 0x00, 
					0x00, 0x7F, 0xFE, 0x00, 
					0x00, 0xFF, 0xFF, 0x00, 
					0x01, 0xFF, 0xFF, 0x80,	
					0x01, 0xFF, 0xFF, 0x80,	
					0x01, 0xFF, 0xFF, 0x80,	
					0x00, 0xFF, 0xFF, 0x80,	
					0x00, 0xFF, 0xFF, 0x80,	
					0x00, 0xFF, 0xFF, 0x80,	
					0x00, 0xFF, 0xFF, 0x00,	
					0x00, 0xFF, 0xFE, 0x00, 
					0x00, 0xFF, 0xFE, 0x00, 
					0x00, 0xFF, 0xFF, 0x00,	
					0x00, 0x7F, 0xFF, 0x00,	
					0x00, 0x7F, 0xFF, 0x00,	
					0x00, 0x7F, 0xFF, 0x00,	
					0x00, 0x3F, 0x7E, 0x00,	
					0x00, 0x7E, 0x3C, 0x00,
					0x00, 0x00, 0x00, 0x00};

	DEBUGOPEN();

	if (argc > 1) {
		Type = argv[1][1];
		ToDisplay = atoi(argv[1] + 2);

		if (Type == 'h' || argv[1][0] != '-') {
#ifdef _WIN32
			char LongBuffer[2048];
			sprintf(LongBuffer, "%s\nCopyright (c) %s Benjamin Cutler\nThis program is released under the GPL - NO WARRANTY - See COPYING\nUsage: bck [-command[#]] [levelinfofile] [dumpfile]\nIf no command is given, defaults to '-e'\nIf no levelinfofile is given, defaults to 'all.cfg'\nSingle Commands (executes, then waits for a keypress or a mouse click and quits)\n -c Display a single character, or >255 for the entire table\n -u Display a single USB, or >255 for the entire table\n -s Display a single SB, or >255 for the entire table\n -b Display a single Block (too big to show them all at once)\n -r Display a Screen's worth of blocks as well as scroll bits\n -R Same as above, but don't clip off the extraneous chunks\n -z View RLE screen # (valid numbers are 0-18)\n -l Display level info (ignores number)\n -d Dump the entire level map (LARGE!, requires dumpfile, ignores number)\n If dumpfile is specified, the display will be written in BMP format\nInteractive Commands\n -e Edit level(s) (ignores number, ignores dumpfile)\nOther Commands\n -v Verify ROM (compares SHA1 to known value, lets you know if you have a compatible ROM)\n -h Print this help", BCKVERSION, BCKCOPYRIGHTYEAR);
			MessageBox(NULL, LongBuffer, BCKVERSION, MB_OK);
#else
			printf("%s\n", BCKVERSION);
			printf("Copyright (c) %s Benjamin Cutler\n", BCKCOPYRIGHTYEAR);
			printf("This program is released under the GPL - NO WARRANTY - See COPYING\n");
			printf("Usage: bck [-command[#]] [levelinfofile] [dumpfile]\n");
			printf("If no command is given, defaults to '-e'\n");
			printf("If no levelinfofile is given, defaults to 'all.cfg'\n");
			printf("Single Commands (executes, then waits for a keypress or a mouse click and quits)\n");
			printf(" -c Display a single character, or >255 for the entire table\n");
			printf(" -u Display a single USB, or >255 for the entire table\n");
			printf(" -s Display a single SB, or >255 for the entire table\n");
			printf(" -b Display a single Block (too big to show them all at once)\n");
			printf(" -r Display a Screen's worth of blocks as well as scroll bits\n");
			printf(" -R Same as above, but don't clip off the extraneous chunks\n");
			printf(" -z View RLE screen # (valid numbers are 0-18)\n");
			printf(" -l Display level info (ignores number)\n");
			printf(" -d Dump the entire level map (LARGE!, requires dumpfile, ignores number)\n");
			printf(" If dumpfile is specified, the display will be written in BMP format\n");
			printf("Interactive Commands\n");
			printf(" -e Edit level(s) (ignores number, ignores dumpfile)\n");
			printf("Other Commands\n");
			printf(" -v Verify ROM (compares SHA1 to known value, lets you know if you have a compatible ROM)\n");
			printf(" -h Print this help\n");
#endif
			exit(1);
		}
		if (argc > 2) {
			LevelInfoFilename = argv[2];
		} else {
			LevelInfoFilename = "all.cfg";
		}
	} else {
		Type = 'e';
		LevelInfoFilename = "all.cfg";
	}

	if( SDL_Init(SDL_INIT_VIDEO) < 0 ) {
	       	ERR("Couldn't initialize SDL: %s\n", SDL_GetError());
       		exit(1);
	}
	
	if ( ! ( ConfigFile = fopen("bck.cfg", "r") ) ) {
		ERR("Error opening bck.cfg!\n");
		Exit(1);
	}

	fgets(Buffer, 79, ConfigFile);

	if ( sscanf(Buffer, "%d %d %d\n", &Config.GFXWidth, &Config.GFXHeight, &Config.GFXBPP) != 3 ) {
		ERR("Error: Not enough values on first line of bck.cfg!\n(Should be <WIDTH> <HEIGHT> <BITDEPTH>)\n");
		Exit(1);
	}

	fgets(Config.ROMFilename, 79, ConfigFile);

	while (!isalpha(Config.ROMFilename[strlen(Config.ROMFilename) - 1])) {
		Config.ROMFilename[strlen(Config.ROMFilename) - 1] = '\0';
	}
 
	if ( ! ( DataFile = fopen(Config.ROMFilename, "r+b") ) ) {
		ERR("Error opening %s (ROM)!\n", Config.ROMFilename);
		ERR(Config.ROMFilename);
		Exit(1);
	}

	fgets(Config.EMUFilename, 79, ConfigFile);
	
	while (!isalpha(Config.EMUFilename[strlen(Config.EMUFilename) - 1])) {
		Config.EMUFilename[strlen(Config.EMUFilename) - 1] = '\0';
	}

	if ( ! ( LevelInfoFile = fopen(LevelInfoFilename, "r") ) ) {
		ERR("Error opening %s (Level Info File)!\n", LevelInfoFilename);
		Exit(1);
	}

	fgets(Buffer, 79, LevelInfoFile);

	sscanf(Buffer, "%d", &LevelInfoType);

	switch(LevelInfoType) {
		case(1): {
			int Dummy;
			fgets(Buffer, 79, LevelInfoFile);
			if ((Dummy = sscanf(Buffer, "%x %x %x %x %x %x %x %x %x %x %x",
				&LevelInfo.CharacterLocation,
				&LevelInfo.PaletteLocation,
				&LevelInfo.USBLocation,
				&LevelInfo.SBLocation,
				&LevelInfo.BLocation,
				&LevelInfo.MapLocation,
				&LevelInfo.USBAttributeLocation,
				&LevelInfo.ScrollTableLocation,
				&LevelInfo.NumUSB,
				&LevelInfo.NumSB,
				&LevelInfo.NumB)) != 11) {
				ERR("Error with %s (level info file type 1), not enough values! (%d)\n", LevelInfoFilename, Dummy);
				Exit(1);
			}
			break;
		}
		case(2): {
			Uint32 Temp, Temp2;
			int Dummy;
			fgets(Buffer, 79, LevelInfoFile);
			if ((Dummy = sscanf(Buffer, "%x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %d %d",
				&LevelInfo.CharacterLocation,
				&LevelInfo.PaletteLocation,
				&LevelInfo.USBLocation,
				&LevelInfo.SBLocation,
				&LevelInfo.BLocation,
				&LevelInfo.MapLocation,
				&LevelInfo.USBAttributeLocation,
				&LevelInfo.ScrollTableLocation,
				&LevelInfo.NumUSB,
				&LevelInfo.NumSB,
				&LevelInfo.NumB,
				&LevelInfo.ThingTypeLocation,
				&LevelInfo.ThingXLocation,
				&LevelInfo.ThingYLocation,
				&LevelInfo.NumThing,
				&Temp,
				&Temp2)) != 17) {
				ERR("Error with %s (level info file type 2), not enough values! (%d)\n", LevelInfoFilename, Dummy);
				Exit(1);
			}
			LevelInfo.LevelNum = Temp;
			LevelInfo.isOverhead = Temp2;
			break;
		}
		case(3): {
			char LevelInfoFileNames[16][80];
			int Dummy;
			FILE *LevelInfoFileTemp;
			if ((Dummy = fscanf(LevelInfoFile, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
				LevelInfoFileNames[0],
				LevelInfoFileNames[1],
				LevelInfoFileNames[2],
				LevelInfoFileNames[3],
				LevelInfoFileNames[4],
				LevelInfoFileNames[5],
				LevelInfoFileNames[6],
				LevelInfoFileNames[7],
				LevelInfoFileNames[8],
				LevelInfoFileNames[9],
				LevelInfoFileNames[10],
				LevelInfoFileNames[11],
				LevelInfoFileNames[12],
				LevelInfoFileNames[13],
				LevelInfoFileNames[14],
				LevelInfoFileNames[15])) != 16) {
				ERR("Error with %s (level info file type 3), not enough values! (%d)\n", LevelInfoFilename, Dummy);
				Exit(1);
			}
			for(int Loop = 0; Loop < 16; Loop++) {
				Uint32 Temp, Temp2;
				if (!(LevelInfoFileTemp = fopen(LevelInfoFileNames[Loop], "r"))) {
					ERR("Error opening %s!\n", LevelInfoFileNames[Loop]);
					Exit(1);
				}
				fgets(Buffer, 79, LevelInfoFileTemp);		// Dummy out the first line
				fgets(Buffer, 79, LevelInfoFileTemp);
				if ((Dummy = sscanf(Buffer, "%x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %d %d",
					&LevelInfo.CharacterLocation,
					&LevelInfo.PaletteLocation,
					&LevelInfo.USBLocation,
					&LevelInfo.SBLocation,
					&LevelInfo.BLocation,
					&LevelInfo.MapLocation,
					&LevelInfo.USBAttributeLocation,
					&LevelInfo.ScrollTableLocation,
					&LevelInfo.NumUSB,
					&LevelInfo.NumSB,
					&LevelInfo.NumB,
					&LevelInfo.ThingTypeLocation,
					&LevelInfo.ThingXLocation,
					&LevelInfo.ThingYLocation,
					&LevelInfo.NumThing,
					&Temp,
					&Temp2)) != 17) {
					ERR("Error with %s (while trying to load all levels), not enough values! (%d)\n", LevelInfoFileNames[Loop], Dummy);
					Exit(1);
				}
				LevelInfo.LevelNum = Temp;
				LevelInfo.isOverhead = Temp2;
				Levels[Loop].LoadInfo(LevelInfo);
				Levels[Loop].LoadLevel(DataFile);
				fclose(LevelInfoFileTemp);
				LevelInfoFileTemp = NULL;
			}	
			AllLevels = true;
			break;
		}
		default: {
			ERR("Error with %s (level info file), unknown version: %d\n", LevelInfoFilename, LevelInfoType);
			Exit(1);
			break;
		}
	}

	fseek(DataFile, TextLocation, SEEK_SET);
	fread(TextData, 1, 4096, DataFile);

	fseek(DataFile, LevelInfo.CharacterLocation, SEEK_SET);
	fread(CharData, 1, 4096, DataFile);

	fseek(DataFile, LevelInfo.PaletteLocation, SEEK_SET);
	fread(Palette, 1, 16, DataFile);
	
	fseek(DataFile, GatewayLocation, SEEK_SET);
	fread(GatewayData, 1, NUM_GATES * 3, DataFile);

	Graphics.LoadCharacters(CharData);
	Graphics.LoadText(TextData);
	Graphics.LoadPalette(Palette);

	if (!AllLevels) {
		Levels[0].LoadInfo(LevelInfo);
		Levels[0].LoadLevel(DataFile);
	}

	RLE[RLE_PAUSE_SCREEN].LoadRLE(DataFile, RLE_PAUSE_SCREEN);
	RLE[RLE_INTRO_SCREEN].LoadRLE(DataFile, RLE_INTRO_SCREEN);
	RLE[RLE_TITLE_SCREEN].LoadRLE(DataFile, RLE_TITLE_SCREEN);
	RLE[RLE_ENDING_SCREEN].LoadRLE(DataFile, RLE_ENDING_SCREEN);
	RLE[RLE_BOSS26].LoadRLE(DataFile, RLE_BOSS26);
	RLE[RLE_BOSS47].LoadRLE(DataFile, RLE_BOSS47);
	RLE[RLE_BOSS1].LoadRLE(DataFile, RLE_BOSS1);
	RLE[RLE_BOSS3].LoadRLE(DataFile, RLE_BOSS3);
	RLE[RLE_BOSS5].LoadRLE(DataFile, RLE_BOSS5);
	RLE[RLE_BOSS8].LoadRLE(DataFile, RLE_BOSS8);
	RLE[RLE_FINAL_BOSS_SCREEN].LoadRLE(DataFile, RLE_FINAL_BOSS_SCREEN);
	RLE[RLE_INTRO_SCREEN_1].LoadRLE(DataFile, RLE_INTRO_SCREEN_1);
	RLE[RLE_INTRO_SCREEN_2].LoadRLE(DataFile, RLE_INTRO_SCREEN_2);
	RLE[RLE_INTRO_SCREEN_3].LoadRLE(DataFile, RLE_INTRO_SCREEN_3);
	RLE[RLE_INTRO_SCREEN_4].LoadRLE(DataFile, RLE_INTRO_SCREEN_4);
	RLE[RLE_INTRO_SCREEN_5].LoadRLE(DataFile, RLE_INTRO_SCREEN_5);
	RLE[RLE_INTRO_SCREEN_6].LoadRLE(DataFile, RLE_INTRO_SCREEN_6);
	RLE[RLE_INTRO_SCREEN_7].LoadRLE(DataFile, RLE_INTRO_SCREEN_7);
	RLE[RLE_INTRO_SCREEN_8].LoadRLE(DataFile, RLE_INTRO_SCREEN_8);

	cLevel::SetGraphics(&Graphics);

	cLevel::LoadGateways(GatewayData);

	cLevel::LoadMisc(DataFile);

	cRLE::SetGraphics(&Graphics);

	if (Type != 'd') {
	 	if (Graphics.InitGraphics(Config.GFXWidth, Config.GFXHeight, Config.GFXBPP, SDL_HWSURFACE | SDL_DOUBLEBUF)) {
			Exit(1);
		}
	} else {
		if (Graphics.InitGraphics(2048, 2048, 32, SDL_HWSURFACE | SDL_DOUBLEBUF)) {
			Exit (1);
		}
	}

	SDL_WM_SetCaption(BCKVERSION, BCKVERSION);

	SDL_WM_SetIcon(SDL_LoadBMP("bck.bmp"), mask);

	if (Type != 'e') {
		if (AllLevels && Type != 'v' && Type != 'z') {
			ERR("Error: Type 3 config files can only use -e as their command.\n");
			Exit(1);
		}
		Graphics.Lock();

		switch(Type) {
			case('c'): {
				if (ToDisplay < 256) {	
					Graphics.DisplayCharacter(0, 0, ToDisplay);
				} else {
					Uint16 Loop;
					for (Loop = 0; Loop < 256; Loop++) {
						Graphics.DisplayCharacter(Loop % 16 * 8, Loop / 16 * 8, Loop);
					}
				}
				break;
			}
			case('u'): {
				if (ToDisplay < 256) {
					Levels[0].DisplayUSBlock(0, 0, ToDisplay);
					Levels[0].DisplayUSBlockInfo(272, 32, ToDisplay);
				} else {
					Uint16 Loop;
					for (Loop = 0; Loop < LevelInfo.NumUSB; Loop++) {
						Levels[0].DisplayUSBlock(Loop % 16 * 16, Loop / 16 * 16, Loop);
					}
				}
				break;
			}
			case('s'): {
               	        	if (ToDisplay < 256) {
                        		Levels[0].DisplaySBlock(0, 0, ToDisplay);
					Levels[0].DisplaySBlockInfo(272, 32, ToDisplay);
                	        } else {
					Uint16 Loop;
					for (Loop = 0; Loop < LevelInfo.NumSB; Loop++) {
						Levels[0].DisplaySBlock(Loop % 16 * 32, Loop / 16 * 32, Loop);
					}
				}
				break;
        	        }
			case('b'): {
				Levels[0].DisplayBlock(0, 0, ToDisplay);
				Levels[0].DisplayBlockInfo(272, 32, ToDisplay);
				break;
			}
			case('r'): {
				Levels[0].DisplayRoom(ToDisplay);
				Levels[0].DisplayRoomInfo(272, 32, ToDisplay);
				break;
			}
			case('R'): {
				Levels[0].DisplayRoomPlus(ToDisplay);
				Levels[0].DisplayRoomInfo(336, 32, ToDisplay);
				break;
			}
			case('d'): {
				if ( argc < 4 ) {
					ERR("Error: -d requires a dumpfile\n");
				} else {
					for (int Loop = 0; Loop < 64; Loop++) {
						Levels[0].DisplayRoom((Loop % 8) * 256, (Loop / 8) * 256, Loop);
					}
				}
				break;
			}
			case('l'): {
				Levels[0].DisplayInfo(0, 0);
				break;
			}
			case('v'): {
				CSHA1 Hash;
				char Buffer[80], Buffer2[80];

				Hash.HashFile(Config.ROMFilename);
				Hash.Final();
				Hash.ReportHash(Buffer, CSHA1::REPORT_HEX);

				sprintf(Buffer2, "GENERATED HASH %s\n", Buffer);
				ERR(Buffer2);
				Graphics.DisplayText(0, 0, Buffer2);

				sprintf(Buffer2, "KNOWN HASH     %s\n", KNOWN_HASH);
				ERR(Buffer2);
				Graphics.DisplayText(0, 8, Buffer2);

				if (!strcmp(KNOWN_HASH, Buffer)) {
					ERR("Good rom!\n");
					Graphics.DisplayText(0, 16, "GOOD ROM!");
				} else {
					ERR("Unknown rom, may not work!\n");
					Graphics.DisplayText(0, 16, "UNKNOWN ROM!");
				}
				
				break;
			}
			case('z'): {
				if (ToDisplay > 18) {
					ERR("Error: Invalid RLE screen.\n");
					Exit(1);
					break;
				}
				RLE[ToDisplay].SwitchTo();
				RLE[ToDisplay].DisplayRLE(0, 0);
				break;
			}
			default: {
				ERR("Error: Invalid command.\n");
				Exit(1);
				break;
			}
		} // switch (Type) {
	
		if (Type != 'd' && Type != 'v') {
			Graphics.DisplayPalette(512, 0);
		}
	
		Graphics.Unlock();
	
		Graphics.Update();

		if (argc > 3) {
			Graphics.DumpToFile(argv[3]);
		}

		do {
			SDL_WaitEvent( &event );
		} while ( ( event.type != SDL_KEYDOWN ) && ( event.type != SDL_MOUSEBUTTONDOWN ) && ( event.type != SDL_QUIT ) ); 
	} else { // if (Type != 'e')
		bool Quit = false;
		int CurLevel = AllLevels * 0x08;
		if (AllLevels) {
			Levels[CurLevel].SwitchTo();
		}
		do {
			switch(BrowseLevel(Levels[CurLevel], &Graphics, RLE)) {
				case (BROWSE_SAVE): {
					Levels[CurLevel].SaveLevel(DataFile);
					ERR("Saved Level\n");
					break;
				}
				case (BROWSE_REVERT): {
					Levels[CurLevel].LoadLevel(DataFile);
					ERR("Reloaded Level\n");
					break;
				}
				case (BROWSE_QUITSAVE): {
					Levels[CurLevel].SaveLevel(DataFile);
					ERR("Saved Level\n");
					Quit = true;
					break;
				}
				case (BROWSE_QUIT): {
					Quit = true;
					break;
				}
				case (BROWSE_TEST): {
					fclose(DataFile);
#ifdef _WIN32
					sprintf(Buffer, "%s \"%s\"", Config.EMUFilename, Config.ROMFilename);
#else
					sprintf(Buffer, "%s \"%s\" &", Config.EMUFilename, Config.ROMFilename);
#endif
					printf("Executing command: %s\n", Buffer);
					system(Buffer);
					if (!(DataFile = fopen(Config.ROMFilename, "r+b"))) {
						ERR("Error reopening %s after test!\n", Config.ROMFilename);
						Exit(1);
					}
					break;
				}
				case (BROWSE_SWITCHSAVE): {
					if (AllLevels) {
						Levels[CurLevel].SaveLevel(DataFile);
						ERR("Saved Level\n");
						++CurLevel %= 16;
						Levels[CurLevel].SwitchTo();
					}
					break;
				}
				case (BROWSE_SWITCH): {
					if (AllLevels) {
						++CurLevel %= 16;
						Levels[CurLevel].SwitchTo();
					}
					break;
				}
			}
		} while (!Quit);
	}
	fclose(DataFile);
	fclose(ConfigFile);
	fclose(LevelInfoFile);

	Graphics.Windowed();
	
	cLevel::SetGraphics(NULL);

	exit(0);
}
