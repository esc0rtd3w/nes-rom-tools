/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <SDL/SDL.h>
#include <stdio.h>
#include <string.h>
#include "nesgfx.h"
#include "video.h"
#include "rle.h"
#include "bmtypes.h"

const Uint32 RLE_LOCATIONS[NUM_RLE] =
	{	0xC02C,			// Pause
		0xC23E,			// Intro
		0xC4D9,			// Title
		0xC650,			// Ending
		0xCA6F,			// Boss 2&6
		0xCCAF,			// Boss 4&7
		0xCDAF,			// Boss 1
		0xCEEF,			// Boss 3
		0xD0DC,			// Boss 5
		0xD43C,			// Boss 8
		0xD70C,			// Final Boss' Room
		0xD9CC,			// Intro Screen 1
		0xDAE7,			// Intro Screen 2
		0xDBD8,			// Intro Screen 3
		0xDCE9,			// Intro Screen 4
		0xDD8B,			// Intro Screen 5
		0xDE82,			// Intro Screen 6
		0xDFAF,			// Intro Screen 7
		0xE0D1			// Intro Screen 8
		};

const Uint32 RLE_LENGTHS[NUM_RLE] =
	{	0x212,			// Pause
		0x29B,			// Intro
		0x177,			// Title
		0x41F,			// Ending
		0x240,			// Boss 2&6
		0x100,			// Boss 4&7
		0x140,			// Boss 1
		0x1ED,			// Boss 3
		0x360,			// Boss 5
		0x2D0,			// Boss 8
		0x2B0,			// Final Boss' Room
		0x11B,			// Intro Screen 1
		0x0F1,			// Intro Screen 2
		0x111,			// Intro Screen 3
		0x0A2,			// Intro Screen 4
		0x0F7,			// Intro Screen 5
		0x12D,			// Intro Screen 6
		0x122,			// Intro Screen 7
		0x0B3
		};

const Uint32 RLE_CHARACTER_LOCATIONS[NUM_RLE] = 
	{ 	0x35010,		// Pause
		0x3D010,		// Intro
		0x27010,		// Title
		0x3F010,		// Ending
		0x38010,		// Boss 2&6
		0x38010,		// Boss 4&7
		0x39010,		// Boss 1 
		0x39010, 		// Boss 3
		0x3A010,		// Boss 5
		0x3B010,		// Boss 8
		0x3B010,		// Final Boss Room
		0x24010,		// Intro Screen 1
		0x24010,		// Intro Screen 2
		0x24010,		// Intro Screen 3
		0x25010,		// Intro Screen 4
		0x25010,		// Intro Screen 5
		0x24010,		// Intro Screen 6
		0x25010,		// Intro Screen 7
		0x25010			// Intro Screen 8
		};

const Uint8 RLE_PALETTES[NUM_RLE][16] =
	{	{ 0x0F, 0x35, 0x25, 0x15, 0x0F, 0x30, 0x00, 0x0B, 0x0F, 0x3C, 0x1C, 0x0C, 0x0F, 0x37, 0x17, 0x07 }, // Pause
		{ 0x0F, 0x27, 0x07, 0x17, 0x0F, 0x1C, 0x2C, 0x0A, 0x0F, 0x38, 0x17, 0x27, 0x0F, 0x30, 0x00, 0x0B }, // Intro
		{ 0x0F, 0x3C, 0x2C, 0x12, 0x0F, 0x3C, 0x2C, 0x12, 0x0F, 0x3C, 0x2C, 0x12, 0x0F, 0x3C, 0x2C, 0x12 },	// Title (Game cycles #3)
		{ 0x0F, 0x30, 0x21, 0x1B, 0x0F, 0x2A, 0x1A, 0x0A, 0x0F, 0x2C, 0x1B, 0x0C, 0x0F, 0x30, 0x15, 0x00 }, // Ending
		{ 0x0F, 0x06, 0x17, 0x27, 0x0F, 0x06, 0x17, 0x27, 0x0F, 0x06, 0x17, 0x27, 0x0F, 0x06, 0x17, 0x27 },	// Boss 2&6 (Colors are for 2)
		{ 0x0F, 0x0A, 0x1A, 0x27, 0x0F, 0x0A, 0x1A, 0x27, 0x0F, 0x0A, 0x1A, 0x27, 0x0F, 0x0A, 0x1A, 0x27 }, // Boss 4&7 (Colors are for 4)
		{ 0x0F, 0x05, 0x15, 0x25, 0x0F, 0x05, 0x15, 0x25, 0x0F, 0x05, 0x15, 0x25, 0x0F, 0x05, 0x15, 0x25 }, // Boss 1
		{ 0x0F, 0x16, 0x11, 0x38, 0x0F, 0x05, 0x15, 0x25, 0x0F, 0x00, 0x0B, 0x3C, 0x0F, 0x07, 0x0B, 0x00 }, // Boss 3
		{ 0x0F, 0x06, 0x16, 0x27, 0x0F, 0x06, 0x16, 0x14, 0x0F, 0x06, 0x16, 0x27, 0x0F, 0x06, 0x16, 0x14 }, // Boss 5 
		{ 0x0F, 0x07, 0x00, 0x10, 0x0F, 0x09, 0x07, 0x00, 0x0F, 0x15, 0x25, 0x25, 0x0F, 0x09, 0x1A, 0x24 }, // Boss 8
		{ 0x0F, 0x07, 0x00, 0x10, 0x0F, 0x09, 0x07, 0x00, 0x0F, 0x17, 0x07, 0x28, 0x0F, 0x09, 0x1A, 0x24 }, // Final Boss Room
		{ 0x07, 0x21, 0x17, 0x30, 0x07, 0x29, 0x17, 0x30, 0x07, 0x36, 0x17, 0x30, 0x07, 0x0A, 0x1A, 0x21 }, // Intro Screen 1
		{ 0x07, 0x21, 0x17, 0x30, 0x07, 0x29, 0x17, 0x30, 0x07, 0x36, 0x17, 0x30, 0x07, 0x0A, 0x1A, 0x21 }, // Intro Screen 2
		{ 0x07, 0x21, 0x17, 0x30, 0x07, 0x29, 0x17, 0x30, 0x07, 0x36, 0x17, 0x30, 0x07, 0x0A, 0x1A, 0x21 }, // Intro Screen 3
		{ 0x07, 0x21, 0x17, 0x30, 0x07, 0x29, 0x17, 0x30, 0x07, 0x36, 0x17, 0x30, 0x07, 0x0A, 0x1A, 0x21 }, // Intro Screen 4 
		{ 0x07, 0x11, 0x15, 0x30, 0x07, 0x29, 0x17, 0x0F, 0x07, 0x0F, 0x00, 0x30, 0x07, 0x0A, 0x1A, 0x21 }, // Intro Screen 5
		{ 0x07, 0x21, 0x17, 0x30, 0x07, 0x29, 0x17, 0x30, 0x07, 0x36, 0x17, 0x30, 0x07, 0x0A, 0x1A, 0x21 }, // Intro Screen 6 
		{ 0x07, 0x11, 0x15, 0x30, 0x07, 0x29, 0x17, 0x0F, 0x07, 0x0F, 0x00, 0x30, 0x07, 0x0A, 0x1A, 0x21 }, // Intro Screen 7
		{ 0x07, 0x11, 0x15, 0x30, 0x07, 0x25, 0x15, 0x05, 0x07, 0x0F, 0x00, 0x30, 0x07, 0x0A, 0x1A, 0x21 }  // Intro Screen 8
		};

cGFX *cRLE::Graphics;

cRLE::cRLE()
{
	RLEData = NULL;
}

cRLE::~cRLE()
{
	if (RLEData) {
		delete RLEData;
	}
}

void cRLE::LoadRLE(FILE *DataFile, RLE_TYPE RLE_Index)
{

	RLEData = new Uint8[RLE_LENGTHS[RLE_Index]];

	DataLength = RLE_LENGTHS[RLE_Index];

	fseek(DataFile, RLE_LOCATIONS[RLE_Index], SEEK_SET);
	fread(RLEData, 1, DataLength, DataFile);

	memcpy(Palette, RLE_PALETTES[RLE_Index], 16);

	fseek(DataFile, RLE_CHARACTER_LOCATIONS[RLE_Index], SEEK_SET);
	fread(CharData, 1, 4096, DataFile);
}

void cRLE::SwitchTo()
{
	Graphics->LoadCharacters(CharData);
	Graphics->LoadPalette(Palette);
}

void cRLE::DisplayRLE(int x, int y)
{
	Uint8 GraphicsArray[1024];						// Holds the graphical data while it's being built
	Uint8 ColorArray[1024];							// Holds the color data while it's being built
	const unsigned int ArrayLength = 0x3C0;			// How much graphical data to build (constant?)
	unsigned int Built = 0;							// How much is built so far
	unsigned int Index = 0;							// How far into the RLE data we've processed
	unsigned int Left = 0;							// Some of the screens use character/color overlap, so this is neccessary to make sure the correct data is loaded, instead of just a simple loop
	bool MultiScreen = false;						// Multiple screens? (Ending, Boss 5)
	Uint8 Command;									// Current Command being executed

	// ERR("Entering DisplayRLE()\n");
	// ERR("ArrayLength is: $%04X\n", ArrayLength);
	// ERR("DataLength is: $%04X\n", DataLength);

	if((DataLength == RLE_LENGTHS[RLE_ENDING_SCREEN]) || (DataLength == RLE_LENGTHS[RLE_BOSS5])) {
		// ERR("Multi-screened\n");
		MultiScreen = true;
	}


	// ERR("Starting Graphics Parsing\n");

	do {
		Command = RLEData[Index];
		// ERR("Parsing Command from $%04X: $%02X ", Index, Command);
		if (Command == 0x80) {							// Next (0x80) bytes are copied verbatim
			// ERR("(Next ($80) bytes are copied verbatim)\n");
			Index++;
			Left = 0x80;
			while (Left) {
				// ERR("Loading $%02X from index $%04X ", RLEData[Index], Index);
				// ERR("into index $%04X\n", Built);
				if (Built < ArrayLength) {
					GraphicsArray[Built] = RLEData[Index];
					Index++;
					Built++;
					Left--;
				} else {
					break;
				}
			}
		} else if (Command > 0x80) {					// (0x81-0xFF) Next (Command - 0x80) bytes are copied verbatim
			Index++;
			Left = Command - 0x80;
			// ERR("(Next ($%02X) bytes are copied verbatim)\n", Left);
			while (Left) {
				// ERR("Loading $%02X from index $%04X ", RLEData[Index], Index);
				// ERR("into index $%04X\n", Built);
				if (Built < ArrayLength) {
					GraphicsArray[Built] = RLEData[Index];
					Index++;
					Built++;
					Left--;
				} else {
					break;
				}
			}
		} else {										// (0x00-0x7F) Repeat next byte (Command) times
			Index++;
			Left = Command;
			// ERR("(Repeat next byte ($%02X) ($%02X) times)\n", RLEData[Index], Left);
			while (Left) {
				// ERR("Loading $%02X from index $%04X ", RLEData[Index], Index);
				// ERR("into index $%04X\n", Built);
				if (Built < ArrayLength) {
					GraphicsArray[Built] = RLEData[Index];
					Built++;
					Left--;
				} else {
					break;
				}
			}
			Index++;
		}
	} while (Built < ArrayLength);

	// ERR("Ended Graphics Parsing at index $%04X built $%04X\n", Index, Built);
	// ERR("Left = $%02X\n", Left);

	if (DataLength != RLE_LENGTHS[RLE_BOSS3]) {
		memset(ColorArray, 0, 1024);
	} else {
		memset(ColorArray, 2, 1024);
	}

	Built = 0;
	// ERR("Starting Color Parsing\n");
	do {
		if (Left == 0) {
			Command = RLEData[Index];
			// ERR("Parsing Command from $%04X: $%02X\n", Index, Command);
		} else {
			if (Command >= 0x80) {			// Step Back a byte if we're reading a string
				Index--;
			} else {
				Index -= 2;					// Step Back two bytes if we're repeating
			}
			// ERR("Reading left over data from Command: $%02X ($%02X bytes left)\n", Command, Left);
		}
		if (Command > 0x80) {					// String of different bytes
			Index++;
			if (!Left) { Left = Command - 0x80; }
			// ERR("(Next ($%02X) bytes are copied verbatim)\n", Left);
			while(Left) {
				// ERR("Value at index $%04X: $%02X\n", Index, RLEData[Index]);
				ColorArray[Built] = (RLEData[Index] & 0x03) >> 0;
				ColorArray[Built + 1] = (RLEData[Index] & 0x03) >> 0;
				ColorArray[Built + 32] = (RLEData[Index] & 0x03) >> 0;
				ColorArray[Built + 32 + 1] = (RLEData[Index] & 0x03) >> 0;
				ColorArray[Built + 2] = (RLEData[Index] & 0x0C) >> 2;
				ColorArray[Built + 3] = (RLEData[Index] & 0x0C) >> 2;
				ColorArray[Built + 32 + 2] = (RLEData[Index] & 0x0C) >> 2;
				ColorArray[Built + 32 + 3] = (RLEData[Index] & 0x0C) >> 2;
				ColorArray[Built + 32 * 2] = (RLEData[Index] & 0x30) >> 4;
				ColorArray[Built + 32 * 2 + 1] = (RLEData[Index] & 0x30) >> 4;
				ColorArray[Built + 32 * 3] = (RLEData[Index] & 0x30) >> 4;
				ColorArray[Built + 32 * 3 + 1] = (RLEData[Index] & 0x30) >> 4;
				ColorArray[Built + 32 * 2 + 2] = (RLEData[Index] & 0xC0) >> 6;
				ColorArray[Built + 32 * 2 + 3] = (RLEData[Index] & 0xC0) >> 6;
				ColorArray[Built + 32 * 3 + 2] = (RLEData[Index] & 0xC0) >> 6;
				ColorArray[Built + 32 * 3 + 3] = (RLEData[Index] & 0xC0) >> 6;
				Index++;
				Built += 4;
				if ((Built % 32) == 0) {
					Built += (32 * 3);
				}
				if (Built >= ArrayLength) {		// Double check so we don't overstep
					// ERR("Hit limit during parse loop at index $%04X\n", Index);
					break;
				}
				Left--;
			}
		} else {								// String of repeated byte
			Index++;
			if (!Left) { Left = Command; }
			// ERR("(Repeat next byte ($%02X) ($%02X) times)\n", RLEData[Index], Left);
			while(Left) {
				ColorArray[Built] = (RLEData[Index] & 0x03) >> 0;
				ColorArray[Built + 1] = (RLEData[Index] & 0x03) >> 0;
				ColorArray[Built + 32] = (RLEData[Index] & 0x03) >> 0;
				ColorArray[Built + 32 + 1] = (RLEData[Index] & 0x03) >> 0;
				ColorArray[Built + 2] = (RLEData[Index] & 0x0C) >> 2;
				ColorArray[Built + 3] = (RLEData[Index] & 0x0C) >> 2;
				ColorArray[Built + 32 + 2] = (RLEData[Index] & 0x0C) >> 2;
				ColorArray[Built + 32 + 3] = (RLEData[Index] & 0x0C) >> 2;
				ColorArray[Built + 32 * 2] = (RLEData[Index] & 0x30) >> 4;
				ColorArray[Built + 32 * 2 + 1] = (RLEData[Index] & 0x30) >> 4;
				ColorArray[Built + 32 * 3] = (RLEData[Index] & 0x30) >> 4;
				ColorArray[Built + 32 * 3 + 1] = (RLEData[Index] & 0x30) >> 4;
				ColorArray[Built + 32 * 2 + 2] = (RLEData[Index] & 0xC0) >> 6;
				ColorArray[Built + 32 * 2 + 3] = (RLEData[Index] & 0xC0) >> 6;
				ColorArray[Built + 32 * 3 + 2] = (RLEData[Index] & 0xC0) >> 6;
				ColorArray[Built + 32 * 3 + 3] = (RLEData[Index] & 0xC0) >> 6;
				Built += 4;
				if ((Built % 32) == 0) {
					Built += (0x60);
				}
				if (Built >= ArrayLength) {		// Double check so we don't overstep
					// ERR("Hit limit during parse loop at index $%04X\n", Index);
					break;
				}
				Left--;
			}
			Index++;
		}
		// ERR("Built = $%04X\n", Built);
	} while (Built < ArrayLength);
	// ERR("Ended Color Parsing at index $%04X built $%04X\n", Index, Built);
	// ERR("Left = $%02X\n", Left);

	for(unsigned int Loop = 0; Loop < ArrayLength; Loop++) {		// Display built data
		Graphics->DisplayCharacter((Loop % 32) * 8, (Loop / 32) * 8, GraphicsArray[Loop], ColorArray[Loop]);
	}

	if (MultiScreen) {				// Not the most elegant solution, but works for now
		Built = 0;
		do {
			Command = RLEData[Index];
			// ERR("Parsing Command from $%04X: $%02X ", Index, Command);
			if (Command == 0x80) {							// Next (0x80) bytes are copied verbatim
				// ERR("(Next ($80) bytes are copied verbatim)\n");
				Index++;
				Left = 0x80;
				while (Left) {
					// ERR("Loading $%02X from index $%04X ", RLEData[Index], Index);
					// ERR("into index $%04X\n", Built);
					if (Built < ArrayLength) {
						GraphicsArray[Built] = RLEData[Index];
						Index++;
						Built++;
						Left--;
					} else {
						break;
					}
				}
			} else if (Command > 0x80) {					// (0x81-0xFF) Next (Command - 0x80) bytes are copied verbatim
				Index++;
				Left = Command - 0x80;
				// ERR("(Next ($%02X) bytes are copied verbatim)\n", Left);
				while (Left) {
					// ERR("Loading $%02X from index $%04X ", RLEData[Index], Index);
					// ERR("into index $%04X\n", Built);
					if (Built < ArrayLength) {
						GraphicsArray[Built] = RLEData[Index];
						Index++;
						Built++;
						Left--;
					} else {
						break;
					}
				}
			} else {										// (0x00-0x7F) Repeat next byte (Command) times
				Index++;
				Left = Command;
				// ERR("(Repeat next byte ($%02X) ($%02X) times)\n", RLEData[Index], Left);
				while (Left) {
					// ERR("Loading $%02X from index $%04X ", RLEData[Index], Index);
					// ERR("into index $%04X\n", Built);
					if (Built < ArrayLength) {
						GraphicsArray[Built] = RLEData[Index];
						Built++;
						Left--;
					} else {
						break;
					}
				}
				Index++;
			}
		} while (Built < ArrayLength);
	
		// ERR("Ended Graphics Parsing at index $%04X built $%04X\n", Index, Built);
		// ERR("Left = $%02X\n", Left);
	
		memset(ColorArray, 0, 1024);
	
		Built = 0;
		// ERR("Starting Color Parsing\n");
		do {
			if (Left == 0) {
				Command = RLEData[Index];
				// ERR("Parsing Command from $%04X: $%02X\n", Index, Command);
			} else {
				if (Command >= 0x80) {			// Step Back a byte if we're reading a string
					Index--;
				} else {
					Index -= 2;					// Step Back two bytes if we're repeating
				}
				// ERR("Reading left over data from Command: $%02X ($%02X bytes left)\n", Command, Left);
			}
			if (Command > 0x80) {					// String of different bytes
				Index++;
				if (!Left) { Left = Command - 0x80; }
				// ERR("(Next ($%02X) bytes are copied verbatim)\n", Left);
				while(Left) {
					// ERR("Value at index $%04X: $%02X\n", Index, RLEData[Index]);
					ColorArray[Built] = (RLEData[Index] & 0x03) >> 0;
					ColorArray[Built + 1] = (RLEData[Index] & 0x03) >> 0;
					ColorArray[Built + 32] = (RLEData[Index] & 0x03) >> 0;
					ColorArray[Built + 32 + 1] = (RLEData[Index] & 0x03) >> 0;
					ColorArray[Built + 2] = (RLEData[Index] & 0x0C) >> 2;
					ColorArray[Built + 3] = (RLEData[Index] & 0x0C) >> 2;
					ColorArray[Built + 32 + 2] = (RLEData[Index] & 0x0C) >> 2;
					ColorArray[Built + 32 + 3] = (RLEData[Index] & 0x0C) >> 2;
					ColorArray[Built + 32 * 2] = (RLEData[Index] & 0x30) >> 4;
					ColorArray[Built + 32 * 2 + 1] = (RLEData[Index] & 0x30) >> 4;
					ColorArray[Built + 32 * 3] = (RLEData[Index] & 0x30) >> 4;
					ColorArray[Built + 32 * 3 + 1] = (RLEData[Index] & 0x30) >> 4;
					ColorArray[Built + 32 * 2 + 2] = (RLEData[Index] & 0xC0) >> 6;
					ColorArray[Built + 32 * 2 + 3] = (RLEData[Index] & 0xC0) >> 6;
					ColorArray[Built + 32 * 3 + 2] = (RLEData[Index] & 0xC0) >> 6;
					ColorArray[Built + 32 * 3 + 3] = (RLEData[Index] & 0xC0) >> 6;
					Index++;
					Built += 4;
					if ((Built % 32) == 0) {
						Built += (32 * 3);
					}
					if (Built >= ArrayLength) {		// Double check so we don't overstep
						// ERR("Hit limit during parse loop at index $%04X\n", Index);
						break;
					}
					Left--;
				}
			} else {								// String of repeated byte
				Index++;
				if (!Left) { Left = Command; }
				// ERR("(Repeat next byte ($%02X) ($%02X) times)\n", RLEData[Index], Left);
				while(Left) {
					ColorArray[Built] = (RLEData[Index] & 0x03) >> 0;
					ColorArray[Built + 1] = (RLEData[Index] & 0x03) >> 0;
					ColorArray[Built + 32] = (RLEData[Index] & 0x03) >> 0;
					ColorArray[Built + 32 + 1] = (RLEData[Index] & 0x03) >> 0;
					ColorArray[Built + 2] = (RLEData[Index] & 0x0C) >> 2;
					ColorArray[Built + 3] = (RLEData[Index] & 0x0C) >> 2;
					ColorArray[Built + 32 + 2] = (RLEData[Index] & 0x0C) >> 2;
					ColorArray[Built + 32 + 3] = (RLEData[Index] & 0x0C) >> 2;
					ColorArray[Built + 32 * 2] = (RLEData[Index] & 0x30) >> 4;
					ColorArray[Built + 32 * 2 + 1] = (RLEData[Index] & 0x30) >> 4;
					ColorArray[Built + 32 * 3] = (RLEData[Index] & 0x30) >> 4;
					ColorArray[Built + 32 * 3 + 1] = (RLEData[Index] & 0x30) >> 4;
					ColorArray[Built + 32 * 2 + 2] = (RLEData[Index] & 0xC0) >> 6;
					ColorArray[Built + 32 * 2 + 3] = (RLEData[Index] & 0xC0) >> 6;
					ColorArray[Built + 32 * 3 + 2] = (RLEData[Index] & 0xC0) >> 6;
					ColorArray[Built + 32 * 3 + 3] = (RLEData[Index] & 0xC0) >> 6;
					Built += 4;
					if ((Built % 32) == 0) {
						Built += (0x60);
					}
					if (Built >= ArrayLength) {		// Double check so we don't overstep
						// ERR("Hit limit during parse loop at index $%04X\n", Index);
						break;
					}
					Left--;
				}
				Index++;
			}
			// ERR("Built = $%04X\n", Built);
		} while (Built < ArrayLength);

		// ERR("Ended Color Parsing at index $%04X built $%04X\n", Index, Built);
		// ERR("Left = $%02X\n", Left);

		for(unsigned int Loop = 0; Loop < ArrayLength; Loop++) {		// Display built data
			Graphics->DisplayCharacter((Loop % 32) * 8, (Loop / 32) * 8 + 256, GraphicsArray[Loop], ColorArray[Loop]);
		}
	} // if (MultiScreen)
}
