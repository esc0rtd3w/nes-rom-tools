/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <SDL/SDL.h>
#include <string.h>
#include "video.h"
#include "level.h"
#include "bmtypes.h"
#include "nesgfx.h"

const char *TankThingNames[] = 
	{ "GRAY CATERPILLAR",	// 0x00
	"GRAY BULLET VERT",
	"GRAY BULLET HORIZ",
	"RED DROPPER",
	"GRAY HULK",
	"GRAY HOPPER 6",
	"RED CATERPILLAR",
	"MINE",
	"CEILING TURRET",
	"BOMB ROCK",
	"GRAY ALIEN",
	"GRAY BOMBER",
	"ORB DIVER",
	"BEE",
	"GRAY ORB",
	"RED SKULL BOMBER",
	"GRAY SHOOTER",		// 0x10
	"KAMIKAZE ORB",
	"GRAY HOPPER 12",
	"RED FLIER SPAWN",
	"GRAY FLIER SPAWN",
	"BOMB HAND",
	"METROID SWIMMER",
	"FISH",
	"CHARGING SHELL",
	"GRAY SWIMMER SPAWN",
	"CRESCENT ROLLER",
	"BOMB BOILER",
	"RED BULLET VERT",
	"RED BULLET HORIZ",
	"UN",
	"UN",
	"GATE GUARD",		//0x20
	"POWER 1",
	"POWER 4",
	"GUN 1",
	"GUN 4",
	"HOVER 1",
	"HOVER 4",
	"HOMING MISSILES",
	"THUNDER BREAK",
	"MULTI WARHEAD",
	"GATE",
	"LEFT LOCK",
	"RIGHT LOCK",
	"UFG",
	"BE",
	"UFG",
	"BUG",			//0x30
	"UFG",
	"UN",
	"UN",
	"UFG",
	"UBG",
	"UFG",
	"UO",
	"UFG",
	"UBG",
	"CS",
	"UN",
	"UFG",
	"UBG",
	"CS",
	"UN",
	"UFG",			//0x40
	"BE",
	"CS",
	"BUG",
	"UFG",
	"BE",
	"BE",
	"UBG",
	"UBG",
	"CS",
	"UBG",
	"UFG",
	"BE",
	"CS",
	"UBG",
	"UFG",
	"UN",			//0x50
	"CS",
	"UBG",
	"BE",
	"UFG",
	"UBG",
	"UBG",			//0x56
	};	
	
const char *OverheadThingNames[] =
	{
	"ROBOT",		//0x00
	"EYE",
	"ROBED SKELETON",
	"EYE SPAWN",
	"CIRCLE CAMERAS",
	"GRAY GUMDROP",
	"FLIER SPAWN",
	"CHARGING ROBOT",
	"GRAY SPINNER",
	"CROSS SHOOTER",
	"VERTICAL CAMERA",
	"HORIZONAL CAMERA",
	"SLIDER",
	"GRAY SPITTER",
	"GRAY ZOMBIE HEAD",
	"RED GUMDROP",
	"UNKNOWN",		//0x10
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"UNKNOWN",
	"BOSS",			//0x20
	"POWER 1",
	"POWER 4",
	"GUN 1",
	"GUN 4",
	"HOVER 1",
	"HOVER 4",
	"HOMING MISSILES",
	"THUNDER BREAK",
	"MULTI WARHEAD",	//0x29
	};

sGatewayInfo cLevel::GatewayInfo;
sMiscInfo cLevel::MiscInfo;
cGFX *cLevel::Graphics;

cLevel::cLevel()
{
	for (int Loop = 0; Loop < 256; Loop++) {
		CharArray[Loop] = USBArray[Loop] = SBArray[Loop] = BArray[Loop] = 0;
		USBPixelArray[Loop] = 0;
		USBSurfaceArray[Loop] = 0;
	}
}

cLevel::~cLevel()
{
	for (int Loop = 0; Loop < 256; Loop++) {
		if (CharArray[Loop]) {
			delete CharArray[Loop];
		}
		if (USBArray[Loop]) {
			delete USBArray[Loop];
		}
		if (SBArray[Loop]) {
			delete SBArray[Loop];
		}
		if (BArray[Loop]) {
			delete BArray[Loop];
		}
		if (USBPixelArray[Loop]) {
			delete USBPixelArray[Loop];
		}
		if (USBSurfaceArray[Loop]) {
			SDL_FreeSurface(USBSurfaceArray[Loop]);
			delete USBSurfaceArray[Loop];
		}
	}
}

Uint8 cLevel::GetMapData(Uint8 Room, Uint8 x, Uint8 y)
{
	int RoomBase = (Room / 8 * 128) + (Room % 8 * 4);
	if ( (Room % 8) == 7 ) { 
		if (x == 4) {
			RoomBase -= 32;
		}
	} 
	return MapData[(RoomBase + y * 32 + x) % 1024];
}

void cLevel::SetPalette(Uint8 Index, Uint8 Value)
{
	Palette[Index] = Value % 0x40;
}

void cLevel::SetUSBData(Uint8 USBlock, Uint8 Character, Uint16 Value)
{
	if ((USBlock < LevelInfo.NumUSB) && (Value < 256)) {
		USBArray[USBlock][Character] = Value;
		BuildUSBGFX(USBlock);
	}
}

void cLevel::SetSBData(Uint8 SBlock, Uint8 USBlock, Uint16 Value)
{
	if ((SBlock < LevelInfo.NumSB) && (Value < LevelInfo.NumUSB)) {
		SBArray[SBlock][USBlock] = Value;
	}
}

void cLevel::SetBData(Uint8 Block, Uint8 SBlock, Uint16 Value)
{
	if ((Block < LevelInfo.NumB) && (Value < LevelInfo.NumSB)) {
		BArray[Block][SBlock] = Value;
	}
}

void cLevel::SetMapData(Uint8 Room, Uint8 x, Uint8 y, Uint16 Value)
{
	int RoomBase = (Room / 8 * 128) + (Room % 8 * 4);
	if ( (Room % 8) == 7 ) { 
		if (x == 4) {
			RoomBase -= 32;
		}
	} 
	if ((Room < 64) && (x < 5) && (y < 5) && (Value < LevelInfo.NumB)) {
		MapData[(RoomBase + y * 32 + x) % 1024] = Value;
	}
}

void cLevel::ToggleUSBAttBit(Uint8 USBlock, int Bit)
{
	USBAtt[USBlock] = USBAtt[USBlock] ^ (0x01 << Bit);
	if (Bit < 2) // Changed SubPalette
	{
		BuildUSBGFX(USBlock);
	}
}

void cLevel::ToggleScrollBit(Uint8 Room, int Direction)
{
	switch(Direction) {
		case(DIR_UP) : {
			ScrollTable[Room / 8] = ScrollTable[Room / 8] ^ (0x80 >> (Room % 8));
			break;
		}
		case(DIR_DOWN) : {
			ScrollTable[(Room / 8 + 1) % 8] = ScrollTable[(Room / 8 + 1) % 8] ^ (0x80 >> (Room % 8));
			break;
		}
		case(DIR_LEFT) : {
			ScrollTable[Room / 8 + 8] = ScrollTable[Room / 8 + 8] ^ (0x80 >> (Room % 8));
			break;
		}
		case(DIR_RIGHT) : {
 			ScrollTable[Room / 8 + 8] = ScrollTable[Room / 8 + 8] ^ (0x80 >> ((Room + 1) % 8));
			break;
		}
	}
}

void cLevel::BuildUSBGFX(Uint8 USBlock)
{
	int CurPixel, TempPixel;
	if (USBPixelArray[USBlock] && USBArray[USBlock]) {
		for (int LoopA = 0; LoopA < 8; LoopA++) {
			for (int LoopB = 0; LoopB < 8; LoopB++) {
				for (int LoopC = 0; LoopC < 4; LoopC++) {
					CurPixel = LoopA * 16 + LoopB + (LoopC % 2) * 8 + (LoopC / 2) * 128;
					TempPixel = CharArray[USBArray[USBlock][LoopC]][LoopA * 8 + LoopB];
					USBPixelArray[USBlock][CurPixel] = NesColors[Palette[TempPixel + subPalette(USBAtt[USBlock]) * 4]];
				}
			}
		}
	}
	SDL_LockSurface(USBSurfaceArray[USBlock]);
	memcpy(USBSurfaceArray[USBlock]->pixels, USBPixelArray[USBlock], 1024);
	SDL_UnlockSurface(USBSurfaceArray[USBlock]);
}

/*void cLevel::LoadUSBGFX(Uint8 USBlock)
{
	SDL_LockSurface(USBSurfaceArray[USBlock]);
	memcpy(USBSurfaceArray[USBlock]->pixels, USBPixelArray[USBlock], 1024);
	SDL_UnlockSurface(USBSurfaceArray[USBlock]);
}*/

void cLevel::SetThingData(Uint8 Thing, Uint8 x, Uint8 y, Uint8 Type)
{
	if (Thing < LevelInfo.NumThing) {
		ThingInfo.XPos[Thing] = x & 0x7F;
		ThingInfo.YPos[Thing] = y & 0x7F;
		ThingInfo.Type[Thing] = Type;
	}
}

void cLevel::SetGatewayData(Uint8 Gateway, Uint8 x, Uint8 y, Uint8 Level)
{
	if (Gateway < NUM_GATES) {
		GatewayInfo.X[Gateway] = x & 0x7F;
		GatewayInfo.Y[Gateway] = y & 0x7F;
		GatewayInfo.Level[Gateway] = Level & 0x0F;
	}
}

void cLevel::LoadInfo(sLevelInfo Info)
{
	memcpy(&LevelInfo, &Info, sizeof(sLevelInfo));
}

void cLevel::LoadLevel(FILE *DataFile)
{
	Uint8 TUSBData[1024],
		TSBData[1024],
		TBData[1024],
		TMap[1024],
		TUSBAttributes[256],
		TScrollTable[16],
		TPalette[16],
		TThingTypes[256],
		TThingX[256],
		TThingY[256];

	fseek(DataFile, LevelInfo.CharacterLocation, SEEK_SET);
	fread(CharData, 1, 4096, DataFile);
	
	fseek(DataFile, LevelInfo.PaletteLocation, SEEK_SET);
	fread(TPalette, 1, 16, DataFile);

	fseek(DataFile, LevelInfo.USBLocation, SEEK_SET);
	fread(TUSBData, 1, 1024, DataFile);

	fseek(DataFile, LevelInfo.SBLocation, SEEK_SET);
	fread(TSBData, 1, 1024, DataFile);

	fseek(DataFile, LevelInfo.BLocation, SEEK_SET);
	fread(TBData, 1, 1024, DataFile);
	
	fseek(DataFile, LevelInfo.MapLocation, SEEK_SET);
	fread(TMap, 1, 1024, DataFile);
	
	fseek(DataFile, LevelInfo.USBAttributeLocation, SEEK_SET);
	fread(TUSBAttributes, 1, 256, DataFile);

	fseek(DataFile, LevelInfo.ScrollTableLocation, SEEK_SET);
	fread(TScrollTable, 1, 16, DataFile);
	
	fseek(DataFile, LevelInfo.ThingTypeLocation, SEEK_SET);
	fread(TThingTypes, 1, LevelInfo.NumThing, DataFile);

	fseek(DataFile, LevelInfo.ThingXLocation, SEEK_SET);
	fread(TThingX, 1, LevelInfo.NumThing, DataFile);

	fseek(DataFile, LevelInfo.ThingYLocation, SEEK_SET);
	fread(TThingY, 1, LevelInfo.NumThing, DataFile);

	LoadUSBAttributes(TUSBAttributes);
	LoadPalette(TPalette);
	LoadCharacters(CharData);
	LoadUSBlocks(TUSBData);
	LoadSBlocks(TSBData);
	LoadBlocks(TBData);
	LoadMap(TMap);
	LoadScrollTable(TScrollTable);
	LoadThings(TThingTypes, TThingX, TThingY);
}

void cLevel::LoadPalette(Uint8 *PaletteData)
{
	memcpy(Palette, PaletteData, 16);
}


void cLevel::LoadCharacters(Uint8 *TCharData)
{
        for (int Loop = 0; Loop < 256; Loop++) {
                CharArray[Loop] = new Uint8[64];
                LoadCharacter(TCharData, CharArray[Loop], Loop);
        }
}

void cLevel::LoadUSBlocks(Uint8 *USBData)
{
	Uint32 rmask, gmask, bmask, amask;

#if SDL_BYTEORDER == SDL_BIG_ENDIAN
	rmask = 0x0000ff00;
	gmask = 0x00ff0000;
	bmask = 0xff000000;
	amask = 0x00000000;
#else
	rmask = 0x00ff0000;
	gmask = 0x0000ff00;
	bmask = 0x000000ff;
	amask = 0x00000000;
#endif
	for (Uint32 Loop = 0; Loop < LevelInfo.NumUSB; Loop++) {
		USBArray[Loop] = new Uint8[4];
		memcpy(USBArray[Loop], USBData + (Loop * 4), 4);
		USBPixelArray[Loop] = new Uint32[256];
		USBSurfaceArray[Loop] = SDL_CreateRGBSurface(SDL_HWSURFACE, 16, 16, 32, rmask, gmask, bmask, amask);
		if (USBSurfaceArray[Loop]->pitch != 64) {
			ERR("Pitch != 64\n");
		}
		BuildUSBGFX(Loop);
	}
}

void cLevel::LoadSBlocks(Uint8 *SBData)
{
        for (Uint32 Loop = 0; Loop < LevelInfo.NumSB; Loop++) {
                SBArray[Loop] = new Uint8[4];
                memcpy(SBArray[Loop], SBData + (Loop * 4), 4);
        }
}

void cLevel::LoadBlocks(Uint8 *BData)
{
        for (Uint32 Loop = 0; Loop < LevelInfo.NumB; Loop++) {
                BArray[Loop] = new Uint8[4];
                memcpy(BArray[Loop], BData + (Loop * 4), 4);
        }
}

void cLevel::LoadUSBAttributes(Uint8 *USBAttributes)
{
	memcpy(USBAtt, USBAttributes, LevelInfo.NumUSB);
}

void cLevel::LoadMap(Uint8 *Map)
{
	memcpy(MapData, Map, 1024);
}

void cLevel::LoadScrollTable(Uint8 *Scroll)
{
	memcpy(ScrollTable, Scroll, 16);
}

void cLevel::LoadThings(Uint8 *Types, Uint8 *X, Uint8 *Y)
{
	ThingInfo.Type = new Uint8[LevelInfo.NumThing];
	ThingInfo.XPos = new Uint8[LevelInfo.NumThing];
	ThingInfo.YPos = new Uint8[LevelInfo.NumThing];
	memcpy(ThingInfo.Type, Types, LevelInfo.NumThing);
	memcpy(ThingInfo.XPos, X, LevelInfo.NumThing);
	memcpy(ThingInfo.YPos, Y, LevelInfo.NumThing);
}

void cLevel::LoadGateways(Uint8 *Gateway)
{
	memcpy(GatewayInfo.Level, Gateway, NUM_GATES);
	memcpy(GatewayInfo.X, Gateway + NUM_GATES, NUM_GATES);
	memcpy(GatewayInfo.Y, Gateway + NUM_GATES * 2, NUM_GATES);
}

void cLevel::LoadMisc(FILE *DataFile)
{
	fseek(DataFile, BossPointLocation, SEEK_SET);
	fread(MiscInfo.BossPoints, 1, 16, DataFile);

	fseek(DataFile, StartPointLocation, SEEK_SET);
	fread(MiscInfo.StartPoints, 1, 16, DataFile);

	fseek(DataFile, GateAStructureLocation, SEEK_SET);
	fread(MiscInfo.GateAStructure, 1, 4, DataFile);

	fseek(DataFile, GateBStructureLocation, SEEK_SET);
	fread(MiscInfo.GateBStructure, 1, 4, DataFile);

	fseek(DataFile, OverheadIceLocation, SEEK_SET);
	fread(&MiscInfo.OverheadIce, 1, 1, DataFile);

	fseek(DataFile, TankIceLocation, SEEK_SET);
	fread(&MiscInfo.TankIce, 1, 1, DataFile);

	fseek(DataFile, BOSS_4_7_HP_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss47HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_4_ATTACK_PATTERN_LOCATION, SEEK_SET);
	fread(MiscInfo.Boss4APattern, 1, BOSS_4_ATTACK_PATTERN_LENGTH, DataFile);

	fseek(DataFile, BOSS_7_ATTACK_PATTERN_LOCATION, SEEK_SET);
	fread(MiscInfo.Boss7APattern, 1, BOSS_7_ATTACK_PATTERN_LENGTH, DataFile);

	fseek(DataFile, BOSS_2_6_HP_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss26HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_2_6_HSPEED_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss26HSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_2_6_VSPEED_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss26VSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_3_HP_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss3HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_3_SPAWN_PATTERN_X_LOCATION, SEEK_SET);
	fread(MiscInfo.Boss3SXPattern, 1, BOSS_3_SPAWN_PATTERN_LENGTH, DataFile);

	fseek(DataFile, BOSS_3_SPAWN_PATTERN_Y_LOCATION, SEEK_SET);
	fread(MiscInfo.Boss3SYPattern, 1, BOSS_3_SPAWN_PATTERN_LENGTH, DataFile);

	fseek(DataFile, BOSS_3_ATTACK_PATTERN_LOCATION, SEEK_SET);
	fread(MiscInfo.Boss3APattern, 1, BOSS_3_ATTACK_PATTERN_LENGTH, DataFile);

	fseek(DataFile, BOSS_1_HP_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss1HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_HSPEED_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss1HSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_VSPEED_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss1VSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_RIGHT_SPEED_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss1RSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_LEFT_SPEED_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss1LSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_DOWN_SPEED_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss1DSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_UP_SPEED_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss1USpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_5_HP_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss5HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_8_HP_LOCATION, SEEK_SET);
	fread(&MiscInfo.Boss8HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_FINAL_HP_LOCATION, SEEK_SET);
	fread(&MiscInfo.BossFinalHP, 1, 1, DataFile);

	fseek(DataFile, TankEnemyStatsLocation, SEEK_SET);
	fread(MiscInfo.TankEnemyStats, 1, TankEnemyStatsLength, DataFile);

	Uint8 BBuffer[10];

	fseek(DataFile, DebugLocationA, SEEK_SET);
	fread(BBuffer, 1, 10, DataFile);

	if (!memcmp(BBuffer, DEBUGSECA1, 10)) {
		MiscInfo.LevelSelect = false;
	} else {
		MiscInfo.LevelSelect = true;
	}

#ifdef _DEBUG
	DEBUG("---Start Misc Dump (Load)---\n");
	fwrite(&MiscInfo, 1, sizeof(sMiscInfo), Debug);
	DEBUG("\n---End Misc Dump (Load)---\n");
#endif
}

void cLevel::DisplayUSBlock(int x, int y, Uint8 USBlock)
{
	if (USBlock >= LevelInfo.NumUSB) {
		ERR("Warning: USBlock index out of range (%X)\n", USBlock);
		return;
	}
	Graphics->BlitBlock(USBSurfaceArray[USBlock], x, y); 
}

void cLevel::DisplayUSBlockScale(int x, int y, Uint8 USBlock, Uint8 Scale)
{
	if (USBlock >= LevelInfo.NumUSB) {
		ERR("Warning: USBlock index out of range (%X)\n", USBlock);
		return;
	}
        Graphics->DisplayCharacterScale(x            , y            , USBArray[USBlock][0], subPalette(USBAtt[USBlock]), Scale);
        Graphics->DisplayCharacterScale(x + 8 * Scale, y            , USBArray[USBlock][1], subPalette(USBAtt[USBlock]), Scale);
        Graphics->DisplayCharacterScale(x            , y + 8 * Scale, USBArray[USBlock][2], subPalette(USBAtt[USBlock]), Scale);
        Graphics->DisplayCharacterScale(x + 8 * Scale, y + 8 * Scale, USBArray[USBlock][3], subPalette(USBAtt[USBlock]), Scale);
}

void cLevel::DisplaySBlock(int x, int y, Uint8 SBlock)
{
	if (SBlock >= LevelInfo.NumSB) {
		ERR("Warning: SBlock index out of range (%X)\n", SBlock);
		return;
	}
	DisplayUSBlock(x     , y     , SBArray[SBlock][0]);
	DisplayUSBlock(x + 16, y     , SBArray[SBlock][1]);
	DisplayUSBlock(x     , y + 16, SBArray[SBlock][2]);
	DisplayUSBlock(x + 16, y + 16, SBArray[SBlock][3]);
}

void cLevel::DisplayBlock(int x, int y, Uint8 Block)
{
	if (Block >= LevelInfo.NumB) {
		ERR("Warning: Block index out of range (%X)\n", Block);
		return;
	}
	DisplaySBlock(x     , y     , BArray[Block][0]);
	DisplaySBlock(x + 32, y     , BArray[Block][1]);
	DisplaySBlock(x     , y + 32, BArray[Block][2]);
	DisplaySBlock(x + 32, y + 32, BArray[Block][3]);
}

void cLevel::DisplayRoom(int x, int y, Uint8 Room)
{
	int LoopA, LoopB;
	int RoomBase = (Room / 8 * 128) + (Room % 8 * 4);
	int CurBlock;
	for (LoopA = 0; LoopA < 5; LoopA++) {
		for (LoopB = 0; LoopB < 5; LoopB++) {
			CurBlock = (RoomBase + (LoopA * 32) + LoopB);
			// Check for being on the far right edge
			if ( ( (Room % 8) == 7 ) && (LoopB == 4) ) {
				CurBlock -= 0x20;
			}
			CurBlock %= 1024;
			if (MapData[CurBlock] >= LevelInfo.NumB) {
				ERR("Warning: Block Index out of range (%X, %X)\n", LevelInfo.NumB, MapData[CurBlock]);
				continue;
			}
			// Various checks for screen edges
			if (LoopB == 0) { // Left Edge
				if(LoopA == 0) { // Upper Left Corner
					DisplaySBlock(x, y, BArray[MapData[CurBlock]][3]);
				} else if(LoopA == 4) { // Lower Left Corner
					DisplaySBlock(x, y + 224, BArray[MapData[CurBlock]][1]);
				} else { // Left Edge
					DisplaySBlock(x, y + LoopA * 64 - 32, BArray[MapData[CurBlock]][1]);
					DisplaySBlock(x, y + LoopA * 64     , BArray[MapData[CurBlock]][3]);
				}
			} else if (LoopB == 4) { // Right Edge
				if(LoopA == 0) { // Upper Right Corner
					DisplaySBlock(x + 224, y, BArray[MapData[CurBlock]][2]);
				} else if(LoopA == 4) { // Lower Right Corner
					DisplaySBlock(x + 224, y + 224, BArray[MapData[CurBlock]][0]);
				} else { // Right Edge
					DisplaySBlock(x + 224, y + LoopA * 64 - 32, BArray[MapData[CurBlock]][0]);
					DisplaySBlock(x + 224, y + LoopA * 64     , BArray[MapData[CurBlock]][2]);
				}
			} else if (LoopA == 0) { // Upper Edge
				DisplaySBlock(x + LoopB * 64 - 32, y, BArray[MapData[CurBlock]][2]);
				DisplaySBlock(x + LoopB * 64     , y, BArray[MapData[CurBlock]][3]);
			} else if (LoopA == 4) { // Lower Edge
				DisplaySBlock(x + LoopB * 64 - 32, y + 224, BArray[MapData[CurBlock]][0]);
				DisplaySBlock(x + LoopB * 64     , y + 224, BArray[MapData[CurBlock]][1]);
			} else { // No Edge
				DisplayBlock(x + LoopB * 64 - 32, y + LoopA * 64 - 32, MapData[CurBlock]);
			}
		}
	}
}

// Displays the room without edge clipping

void cLevel::DisplayRoomPlus(int x, int y, Uint8 Room)
{
	int LoopA, LoopB;
	int RoomBase = (Room / 8 * 128) + (Room % 8 * 4);
	int CurBlock;
	for (LoopA = 0; LoopA < 5; LoopA++) {
		for (LoopB = 0; LoopB < 5; LoopB++) {
			CurBlock = (RoomBase + (LoopA * 32) + LoopB);
			// Check for being at the far right edge
			if ( ( (Room % 8) == 7 ) && (LoopB == 4) ) {
				CurBlock -= 0x20;
			}
			CurBlock %= 1024;
			DisplayBlock(x + LoopB * 64, y + LoopA * 64, MapData[CurBlock]);
		}
	}
}

// Display Things (assumes using DisplayRoomPlus at 0,0)

void cLevel::DisplayThings(int rx, int ry)
{
	char Buffer[80];
	int ThingNum = 0;
	for (Uint32 Loop = 0; Loop < LevelInfo.NumThing; Loop++) {
//		printf("Loop %02X: %02X %02X %02X\n", Loop, ThingInfo.Types[Loop], ThingInfo.XPos[Loop], ThingInfo.YPos[Loop]);
		if ((((ThingInfo.XPos[Loop] & 0xF0) >> 4) == rx) && (((ThingInfo.YPos[Loop] & 0xF0) >> 4) == ry)) {
			sprintf(Buffer, "%02X", Loop);
			Graphics->DisplayText((ThingInfo.XPos[Loop] & 0x0F) * 16, (ThingInfo.YPos[Loop] & 0x0F) * 16, Buffer);
			sprintf(Buffer, "%02X", ThingInfo.Type[Loop]);
			Graphics->DisplayText((ThingInfo.XPos[Loop] & 0x0F) * 16, (ThingInfo.YPos[Loop] & 0x0F) * 16 + 8, Buffer);
			if (ThingNum < 20) {
				sprintf(Buffer, "%02X %02X", Loop, ThingInfo.Type[Loop]);
				Graphics->DisplayText(322, 164 + ThingNum * 8, Buffer);
				if (!LevelInfo.isOverhead) {
					if (ThingInfo.Type[Loop] < NUM_TANK_THINGS) {
						Graphics->DisplayText(370, 164 + ThingNum * 8, TankThingNames[ThingInfo.Type[Loop]]);
					} else {
						Graphics->DisplayText(370, 164 + ThingNum * 8, "UNKNOWN");
					}
				} else {
					if (ThingInfo.Type[Loop] < NUM_OVERHEAD_THINGS) {
						Graphics->DisplayText(370, 164 + ThingNum * 8, OverheadThingNames[ThingInfo.Type[Loop]]);
					} else {
						Graphics->DisplayText(370, 164 + ThingNum * 8, "UNKNOWN");
					}
				}
			}
			ThingNum++;
		}
	}
}

void cLevel::DisplayGateways(int x, int y)
{
	char Buffer[80];
	for (int Loop = 0; Loop < NUM_GATES; Loop++) {
		if (GatewayInfo.Level[Loop] == (LevelInfo.LevelNum + (!LevelInfo.isOverhead * 8) - 1)) {
			if ((((GatewayInfo.X[Loop] & 0xF0) >> 4) == x) && (((GatewayInfo.Y[Loop] & 0xF0) >> 4) == y)) {
				sprintf(Buffer, "%02X", Loop);
				Graphics->DisplayText((GatewayInfo.X[Loop] & 0x0F) * 16, (GatewayInfo.Y[Loop] & 0x0F) * 16, Buffer, 0xFFFF00);
				sprintf(Buffer, "%02X", GatewayInfo.Level[Loop]);
				Graphics->DisplayText((GatewayInfo.X[Loop] & 0x0F) * 16, (GatewayInfo.Y[Loop] & 0x0F) * 16 + 8, Buffer, 0xFFFF00);
				sprintf(Buffer, "%02X", Loop ^ 1);
				Graphics->DisplayText((GatewayInfo.X[Loop] & 0x0F) * 16 + 16, (GatewayInfo.Y[Loop] & 0x0F) * 16, Buffer, 0x00FFFF);
				sprintf(Buffer, "%02X", GatewayInfo.Level[Loop ^ 0x01]);
				Graphics->DisplayText((GatewayInfo.X[Loop] & 0x0F) * 16 + 16, (GatewayInfo.Y[Loop] & 0x0F) * 16 + 8, Buffer, 0x00FFFF);
				Graphics->DisplayText(322, 132, "G  L  X  Y", 0xFFFF00);
				sprintf(Buffer, "%02X %02X %02X %02X", Loop, GatewayInfo.Level[Loop], GatewayInfo.X[Loop], GatewayInfo.Y[Loop]);
				Graphics->DisplayText(322, 140, Buffer, 0xFFFF00);
				Graphics->DisplayText(338, 148, "G  L  X  Y", 0x00FFFF);
				sprintf(Buffer, "%02X %02X %02X %02X", Loop ^ 0x01, GatewayInfo.Level[Loop ^ 0x01], GatewayInfo.X[Loop ^ 0x01], GatewayInfo.Y[Loop ^ 0x01]);
				Graphics->DisplayText(338, 156, Buffer, 0x00FFFF);
			}
		}
	}
}

void cLevel::DisplayUSBlockInfo(int x, int y, Uint8 USBlock)
{
	char Subpalette;
	Uint8 Temp = USBAtt[USBlock];
	char Buffer[80];

	if (USBlock >= LevelInfo.NumUSB) {
		return;
	}

	sprintf(Buffer, "%02X %02X", USBArray[USBlock][0], USBArray[USBlock][1]);
	Graphics->DisplayText(x, y, Buffer);
	sprintf(Buffer, "%02X %02X", USBArray[USBlock][2], USBArray[USBlock][3]);
	Graphics->DisplayText(x, y + 16, Buffer);
	Subpalette = '0' + subPalette(Temp);
	sprintf(Buffer, "BITMASK %02X", Temp);
	Graphics->DisplayText(x, y + 32, Buffer);
	Graphics->DisplayText(x, y + 40, "87654321");
	sprintf(Buffer, "%c%c%c%c%c%c%c%c", (Temp & 0x80) ? 'T' : 'F', (Temp & 0x40) ? 'T' : 'F', (Temp & 0x20) ? 'T' : 'F', (Temp & 0x10) ? 'T' : 'F', (Temp & 0x08) ? 'T' : 'F', (Temp & 0x04) ? 'T' : 'F', (Temp & 0x02) ? 'T' : 'F', (Temp & 0x01) ? 'T' : 'F');
	Graphics->DisplayText(x, y + 48, Buffer);
	sprintf(Buffer, "SUBPALETTE %c", Subpalette);
	Graphics->DisplayText(x, y + 56, Buffer);
	if (LevelInfo.isOverhead) {
		char Doorway, Overhang, Tunnel, Damaging, Death, Solid, Destroyable;
		Doorway = isODoorway(Temp) ? 'T' : 'F';
		Overhang = isOOverhang(Temp) ? 'T' : 'F';
		Tunnel = isOTunnel(Temp) ? 'T' : 'F';
		Damaging = isODamaging(Temp) ? 'T' : 'F';
		Death = isODeath(Temp) ? 'T' : 'F';
		Solid = isOSolid(Temp) ? 'T' : 'F';
		Destroyable = isOCrushable(Temp) ? 'T' : 'F';
		sprintf(Buffer, "DOORWAY %c", Doorway);
		Graphics->DisplayText(x, y + 64, Buffer);
		sprintf(Buffer, "OVERHANG %c", Overhang);
		Graphics->DisplayText(x, y + 72, Buffer);
		sprintf(Buffer, "TUNNEL %c", Tunnel);
		Graphics->DisplayText(x, y + 80, Buffer);
		sprintf(Buffer, "DAMAGING %c", Damaging);
		Graphics->DisplayText(x, y + 88, Buffer);
		sprintf(Buffer, "DEATH %c", Death);
		Graphics->DisplayText(x, y + 96, Buffer);
		sprintf(Buffer, "SOLID %c", Solid);
		Graphics->DisplayText(x, y + 104, Buffer);
		sprintf(Buffer, "DESTROYABLE %c", Destroyable);
		Graphics->DisplayText(x, y + 112, Buffer);
	} else {
		char Gateway, Tunnel, Damaging, Ladder, Water, Solid, Crushable, Doorway;
		Gateway = isTGateway(Temp) ? 'T' : 'F';
		Tunnel = isTTunnel(Temp) ? 'T' : 'F';
		Damaging = isTDamaging(Temp) ? 'T' : 'F';
		Ladder = isTLadder(Temp) ? 'T' : 'F';
		Water = isTWater(Temp) ? 'T' : 'F';
		Solid = isTSolid(Temp) ? 'T' : 'F';
		Crushable = isTCrushable(Temp) ? 'T' : 'F';
		Doorway = isTDoorway(Temp) ? 'T' : 'F';	
		sprintf(Buffer, "GATEWAY %c", Gateway);
		Graphics->DisplayText(x, y + 64, Buffer);
		sprintf(Buffer, "TUNNEL %c", Tunnel);
		Graphics->DisplayText(x, y + 72, Buffer);
		sprintf(Buffer, "DAMAGING %c", Damaging);
		Graphics->DisplayText(x, y + 80, Buffer);	
		sprintf(Buffer, "LADDER %c", Ladder);
		Graphics->DisplayText(x, y + 88, Buffer);
		sprintf(Buffer, "WATER %c", Water);
		Graphics->DisplayText(x, y + 96, Buffer);
		sprintf(Buffer, "SOLID %c", Solid);
		Graphics->DisplayText(x, y + 104, Buffer);
		sprintf(Buffer, "CRUSHABLE %c", Crushable);
		Graphics->DisplayText(x, y + 112, Buffer);
		sprintf(Buffer, "DOORWAY %c", Doorway);
		Graphics->DisplayText(x, y + 120, Buffer);
	}
}

void cLevel::DisplaySBlockInfo(int x, int y, Uint8 SBlock)
{
	char Buffer[80];
	
	if (SBlock >= LevelInfo.NumSB) {
		return;
	}
	
	sprintf(Buffer, "%02X %02X", SBArray[SBlock][0], SBArray[SBlock][1]);
	Graphics->DisplayText(x, y, Buffer);
	sprintf(Buffer, "%02X %02X", SBArray[SBlock][2], SBArray[SBlock][3]);
	Graphics->DisplayText(x, y + 16, Buffer);
}

void cLevel::DisplayBlockInfo(int x, int y, Uint8 Block)
{
	char Buffer[80];

	if (Block >= LevelInfo.NumB) {
		return;
	}

	sprintf(Buffer, "%02X %02X", BArray[Block][0], BArray[Block][1]);
	Graphics->DisplayText(x, y, Buffer);
	sprintf(Buffer, "%02X %02X", BArray[Block][2], BArray[Block][3]);
	Graphics->DisplayText(x, y + 16, Buffer);
}

void cLevel::DisplayRoomInfo(int x, int y, Uint8 Room)
{
	char Buffer[80];
	char Left, Right, Up, Down;

	for (int Loop = 0; Loop < 25; Loop++) {
		sprintf(Buffer, "%02X", GetMapData(Room, Loop));
		Graphics->DisplayText(x + (Loop % 5) * 24, y + (Loop / 5) * 16, Buffer);
	}
	Up = (scrollUp(Room) ? 'T' : 'F');
	Left = (scrollLeft(Room) ? 'T' : 'F');
	Down = (scrollDown(Room) ? 'T' : 'F');
	Right = (scrollRight(Room) ? 'T' : 'F');
	sprintf(Buffer, "UP %c", Up);
	Graphics->DisplayText(x, y + 80, Buffer);
	sprintf(Buffer, "LEFT %c", Left);
	Graphics->DisplayText(x, y + 88, Buffer);
	sprintf(Buffer, "DOWN %c", Down);
	Graphics->DisplayText(x, y + 96, Buffer);
	sprintf(Buffer, "RIGHT %c", Right);
	Graphics->DisplayText(x, y + 104, Buffer); 
}

void cLevel::DisplayInfo(int x, int y)
{
	char Buffer[80];
	sprintf(Buffer, "CHARACTER POINTER           %05X", LevelInfo.CharacterLocation);
	Graphics->DisplayText(x, y, Buffer);
	sprintf(Buffer, "PALETTE POINTER              %04X", LevelInfo.PaletteLocation);
	Graphics->DisplayText(x, y + 8, Buffer);
	sprintf(Buffer, "USB TABLE POINTER            %04X", LevelInfo.USBLocation);
	Graphics->DisplayText(x, y + 16, Buffer);
	sprintf(Buffer, "SB TABLE POINTER             %04X", LevelInfo.SBLocation);
	Graphics->DisplayText(x, y + 24, Buffer);
	sprintf(Buffer, "BLOCK TABLE POINTER          %04X", LevelInfo.BLocation);
	Graphics->DisplayText(x, y + 32, Buffer);
	sprintf(Buffer, "MAP DATA POINTER             %04X", LevelInfo.MapLocation);
	Graphics->DisplayText(x, y + 40, Buffer);
	sprintf(Buffer, "USB ATTRIBUTE TABLE POINTER  %04X", LevelInfo.USBAttributeLocation);
	Graphics->DisplayText(x, y + 48, Buffer);
	sprintf(Buffer, "SCROLL TABLE POINTER         %04X", LevelInfo.ScrollTableLocation);
	Graphics->DisplayText(x, y + 56, Buffer);
	sprintf(Buffer, "NUMBER OF USBLOCKS             %02X", LevelInfo.NumUSB);
	Graphics->DisplayText(x, y + 64, Buffer);
	sprintf(Buffer, "NUMBER OF SBLOCKS              %02X", LevelInfo.NumSB);
	Graphics->DisplayText(x, y + 72, Buffer);
	sprintf(Buffer, "NUMBER OF BLOCKS               %02X", LevelInfo.NumB);
	Graphics->DisplayText(x, y + 80, Buffer);
	sprintf(Buffer, "THING TYPE POINTER           %04X", LevelInfo.ThingTypeLocation);
	Graphics->DisplayText(x, y + 88, Buffer);
	sprintf(Buffer, "THING X POS POINTER          %04X", LevelInfo.ThingXLocation);
	Graphics->DisplayText(x, y + 96, Buffer);
	sprintf(Buffer, "THING Y POS POINTER          %04X", LevelInfo.ThingYLocation);
	Graphics->DisplayText(x, y + 104, Buffer);
	sprintf(Buffer, "NUMBER OF THINGS               %02X", LevelInfo.NumThing);
	Graphics->DisplayText(x, y + 112, Buffer);
	sprintf(Buffer, "START POINT                 %02X %02X", MiscInfo.StartPoints[LevelInfo.LevelNum * 2 - 2], MiscInfo.StartPoints[LevelInfo.LevelNum * 2 - 1]);
	Graphics->DisplayText(x, y + 120, Buffer);
	sprintf(Buffer, "BOSS POINT                  %02X %02X", MiscInfo.BossPoints[LevelInfo.LevelNum * 2 - 2], MiscInfo.BossPoints[LevelInfo.LevelNum * 2 - 1]);
	Graphics->DisplayText(x, y + 128, Buffer);
}

void cLevel::SaveLevel(FILE *DataFile)
{
	Uint32 Loop;
	fseek(DataFile, LevelInfo.USBLocation, SEEK_SET);
	for (Loop = 0; Loop < LevelInfo.NumUSB; Loop++)
	{
		DEBUG("%X USB %02X\n", ftell(DataFile), Loop);
		DEBUG("%08X\n", *(Uint32 *)USBArray[Loop]);
		fwrite(USBArray[Loop], 1, 4, DataFile);
	}
	fseek(DataFile, LevelInfo.SBLocation, SEEK_SET);
	for (Loop = 0; Loop < LevelInfo.NumSB; Loop++)
	{
		DEBUG("%X SB %02X\n", ftell(DataFile), Loop);
		DEBUG("%08X\n", *(Uint32 *)SBArray[Loop]);
		fwrite(SBArray[Loop], 1, 4, DataFile);
	}	
	fseek(DataFile, LevelInfo.BLocation, SEEK_SET);
	for (Loop = 0; Loop < LevelInfo.NumB; Loop++)
	{
		DEBUG("%X B %02X\n", ftell(DataFile), Loop);
		DEBUG("%08X\n", *(Uint32 *)BArray[Loop]);
		fwrite(BArray[Loop], 1, 4, DataFile);
	}	
	fseek(DataFile, LevelInfo.MapLocation, SEEK_SET);
	DEBUG("%X Map\n", ftell(DataFile));
	fwrite(MapData, 1, 1024, DataFile);
	fseek(DataFile, LevelInfo.USBAttributeLocation, SEEK_SET);
	DEBUG("%X USBAtt\n", ftell(DataFile));
	fwrite(USBAtt, 1, LevelInfo.NumUSB, DataFile);
	fseek(DataFile, LevelInfo.ScrollTableLocation, SEEK_SET);
	DEBUG("%X ScrollTable\n", ftell(DataFile));
	fwrite(ScrollTable, 1, 16, DataFile);
	fseek(DataFile, LevelInfo.ThingTypeLocation, SEEK_SET);
	DEBUG("%X ThingTypes\n", ftell(DataFile));
	fwrite(ThingInfo.Type, 1, LevelInfo.NumThing, DataFile);
	fseek(DataFile, LevelInfo.ThingXLocation, SEEK_SET);
	DEBUG("%X ThingX\n", ftell(DataFile));	
	fwrite(ThingInfo.XPos, 1, LevelInfo.NumThing, DataFile);
	fseek(DataFile, LevelInfo.ThingYLocation, SEEK_SET);
	DEBUG("%X ThingY\n", ftell(DataFile));
	fwrite(ThingInfo.YPos, 1, LevelInfo.NumThing, DataFile);
	fseek(DataFile, LevelInfo.PaletteLocation, SEEK_SET);
	DEBUG("%X Palette\n", ftell(DataFile));
	fwrite(Palette, 1, 16, DataFile);
	fseek(DataFile, GatewayLocation, SEEK_SET);
	DEBUG("%X GatewayLevel\n", ftell(DataFile));
	fwrite(GatewayInfo.Level, 1, NUM_GATES, DataFile);
	DEBUG("%X GatewayX\n", ftell(DataFile));
	fwrite(GatewayInfo.X, 1, NUM_GATES, DataFile);
	DEBUG("%X GatewayY\n", ftell(DataFile));
	fwrite(GatewayInfo.Y, 1, NUM_GATES, DataFile);
	DEBUG("%X Done\n", ftell(DataFile));
	
	SaveMisc(DataFile);
}

void cLevel::SaveMisc(FILE *DataFile)
{
	fseek(DataFile, BossPointLocation, SEEK_SET);
	fwrite(MiscInfo.BossPoints, 1, 16, DataFile);

	fseek(DataFile, StartPointLocation, SEEK_SET);
	fwrite(MiscInfo.StartPoints, 1, 16, DataFile);

	fseek(DataFile, GateAStructureLocation, SEEK_SET);
	fwrite(MiscInfo.GateAStructure, 1, 4, DataFile);

	fseek(DataFile, GateBStructureLocation, SEEK_SET);
	fwrite(MiscInfo.GateBStructure, 1, 4, DataFile);

	fseek(DataFile, OverheadIceLocation, SEEK_SET);
	fwrite(&MiscInfo.OverheadIce, 1, 1, DataFile);

	fseek(DataFile, TankIceLocation, SEEK_SET);
	fwrite(&MiscInfo.TankIce, 1, 1, DataFile);

	fseek(DataFile, BOSS_4_7_HP_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss47HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_4_ATTACK_PATTERN_LOCATION, SEEK_SET);
	fwrite(MiscInfo.Boss4APattern, 1, BOSS_4_ATTACK_PATTERN_LENGTH, DataFile);

	fseek(DataFile, BOSS_7_ATTACK_PATTERN_LOCATION, SEEK_SET);
	fwrite(MiscInfo.Boss7APattern, 1, BOSS_7_ATTACK_PATTERN_LENGTH, DataFile);

	fseek(DataFile, BOSS_2_6_HP_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss26HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_2_6_HSPEED_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss26HSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_2_6_VSPEED_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss26VSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_3_HP_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss3HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_3_SPAWN_PATTERN_X_LOCATION, SEEK_SET);
	fwrite(MiscInfo.Boss3SXPattern, 1, BOSS_3_SPAWN_PATTERN_LENGTH, DataFile);

	fseek(DataFile, BOSS_3_SPAWN_PATTERN_Y_LOCATION, SEEK_SET);
	fwrite(MiscInfo.Boss3SYPattern, 1, BOSS_3_SPAWN_PATTERN_LENGTH, DataFile);

	fseek(DataFile, BOSS_3_ATTACK_PATTERN_LOCATION, SEEK_SET);
	fwrite(MiscInfo.Boss3APattern, 1, BOSS_3_ATTACK_PATTERN_LENGTH, DataFile);

	fseek(DataFile, BOSS_1_HP_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss1HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_HSPEED_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss1HSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_VSPEED_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss1VSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_RIGHT_SPEED_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss1RSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_LEFT_SPEED_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss1LSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_DOWN_SPEED_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss1DSpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_1_UP_SPEED_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss1USpeed, 1, 1, DataFile);

	fseek(DataFile, BOSS_5_HP_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss5HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_8_HP_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.Boss8HP, 1, 1, DataFile);

	fseek(DataFile, BOSS_FINAL_HP_LOCATION, SEEK_SET);
	fwrite(&MiscInfo.BossFinalHP, 1, 1, DataFile);

	fseek(DataFile, TankEnemyStatsLocation, SEEK_SET);
	fwrite(MiscInfo.TankEnemyStats, 1, TankEnemyStatsLength, DataFile);

	if (MiscInfo.LevelSelect) {
		fseek(DataFile, DebugLocationA, SEEK_SET);
		fwrite(DEBUGSECA2, 1, 10, DataFile);
		fseek(DataFile, DebugLocationB, SEEK_SET);
		fwrite(DEBUGSECB2, 1, 10, DataFile);
		fseek(DataFile, DebugLocationC, SEEK_SET);
		fwrite(&DEBUGSECC2, 1, 1, DataFile);
	} else {
		fseek(DataFile, DebugLocationA, SEEK_SET);
		fwrite(DEBUGSECA1, 1, 10, DataFile);
		fseek(DataFile, DebugLocationB, SEEK_SET);
		fwrite(DEBUGSECB1, 1, 10, DataFile);
		fseek(DataFile, DebugLocationC, SEEK_SET);
		fwrite(&DEBUGSECC1, 1, 1, DataFile);
	}

#ifdef _DEBUG
	DEBUG("---Start Misc Dump (save)---\n");
	fwrite(&MiscInfo, 1, sizeof(sMiscInfo), Debug);
	DEBUG("\n---End Misc Dump (save)---\n");
#endif
}



void cLevel::SwitchTo()
{
	Graphics->LoadCharacters(CharData);
	Graphics->LoadPalette(Palette);
}

