#include <string.h>
#include "zones.h"

cZones::cZones()
{
	NumZones = 0;
	Zones = NULL;
}

cZones::~cZones()
{
	for (int Loop = 0; Loop < NumZones; Loop++) {
		if (Zones[Loop]) {
			delete Zones[Loop];
		}
	}
}

void cZones::SetNumZones(int NZones)
{
	for (int Loop = 0; Loop < NumZones; Loop++) {
		if (Zones[Loop]) {
			delete Zones[Loop];
		}
	}
	if (Zones) {
		delete Zones;
	}
	Zones = new sZone *[NZones];
	memset(Zones, 0, NZones * sizeof(sZone *));
	NumZones = NZones;
}

int cZones::AddZone(int X, int Y, int W, int H, int P)
{
	int Loop;
	for (Loop = 0; Loop < NumZones; Loop++) {
		if (!Zones[Loop]) {
			Zones[Loop] = new sZone;
			Zones[Loop]->X = X;
			Zones[Loop]->Y = Y;
			Zones[Loop]->W = W;
			Zones[Loop]->H = H;
			Zones[Loop]->P = P;
			break;
		}
	}
	return (Loop == NumZones) ? -1 : Loop;
}

int cZones::AddZone(int X, int Y, int W, int H, int P, int id)
{
	if (id >= NumZones) {
		return -1;
	}
	if (Zones[id])
	{
		delete Zones[id];
	}
	Zones[id] = new sZone;
	Zones[id]->X = X;
	Zones[id]->Y = Y;
	Zones[id]->W = W;
	Zones[id]->H = H;
	Zones[id]->P = P;
	return id;
}

void cZones::RemoveZone(int id)
{
	if (id >= NumZones) {
		return;
	}
	if (Zones[id]) {
		delete Zones[id];
		Zones[id] = NULL;
	}
}

int cZones::TestZone(int X, int Y)
{
	int Loop;
	int CurP = -1;
	int CurId = -1;
	for (Loop = 0; Loop < NumZones; Loop++) {
		if (Zones[Loop]) {
			if ((X >= Zones[Loop]->X) && (X <= (Zones[Loop]->X + Zones[Loop]->W)) &&
				(Y >= Zones[Loop]->Y) && (Y <= (Zones[Loop]->Y + Zones[Loop]->H))) {
				if (CurP < Zones[Loop]->P) {
					CurP = Zones[Loop]->P;
					CurId = Loop;
				}
			}
		}
	}
	return CurId;
}
