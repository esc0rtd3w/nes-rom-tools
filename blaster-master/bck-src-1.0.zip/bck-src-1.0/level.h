/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _LEVEL_H
#define _LEVEL_H 1

#include <stdio.h>
#include "bckcfg.h"

extern const char *TankThingNames[];

enum {
	DIR_UP = 1,
	DIR_DOWN,
	DIR_LEFT,
	DIR_RIGHT
};

struct sThingInfo {
	Uint8 NumThings;
	Uint8 *Type;
	Uint8 *XPos;
	Uint8 *YPos;
};

struct sGatewayInfo {
	Uint8 Level[NUM_GATES];
	Uint8 X[NUM_GATES];
	Uint8 Y[NUM_GATES];
};

struct sMiscInfo {
	Uint8 BossPoints[16];
	Uint8 StartPoints[16];
	Uint8 GateAStructure[4];
	Uint8 GateBStructure[4];
	Uint8 OverheadIce;
	Uint8 TankIce;
	Uint8 Boss47HP;
	Uint8 Boss4APattern[BOSS_4_ATTACK_PATTERN_LENGTH];
	Uint8 Boss7APattern[BOSS_7_ATTACK_PATTERN_LENGTH];
	Uint8 Boss26HP;
	Uint8 Boss26HSpeed;
	Uint8 Boss26VSpeed;
	Uint8 Boss3HP;
	Uint8 Boss3SXPattern[BOSS_3_SPAWN_PATTERN_LENGTH];
	Uint8 Boss3SYPattern[BOSS_3_SPAWN_PATTERN_LENGTH];
	Uint8 Boss3APattern[BOSS_3_ATTACK_PATTERN_LENGTH];
	Uint8 Boss1HP;
	Uint8 Boss1HSpeed;
	Uint8 Boss1VSpeed;
	Uint8 Boss1RSpeed;
	Uint8 Boss1LSpeed;
	Uint8 Boss1DSpeed;
	Uint8 Boss1USpeed;
	Uint8 Boss5HP;
	Uint8 Boss8HP;
	Uint8 BossFinalHP;
	bool LevelSelect;
	Uint8 TankEnemyStats[TankEnemyStatsLength];
};

class cLevel {
	private:
		Uint8 Palette[16];
		Uint8 CharData[4096];
		Uint8 *CharArray[256];
		Uint8 *USBArray[256];
		Uint8 *SBArray[256];
		Uint8 *BArray[256];
		Uint32 *USBPixelArray[256];
		SDL_Surface *USBSurfaceArray[256];
		Uint8 USBAtt[256];
		Uint8 MapData[1024];
		Uint8 ScrollTable[16];
		sLevelInfo LevelInfo;
		sThingInfo ThingInfo;
		static cGFX *Graphics;
		static sGatewayInfo GatewayInfo;
		static sMiscInfo MiscInfo;
	public:
		inline Uint8 GetPalette(Uint8 Index) { return Palette[Index]; }
		inline Uint8 GetUSBData(Uint8 USBlock, Uint8 Character) { return USBArray[USBlock][Character]; }
		inline Uint8 GetSBData(Uint8 SBlock, Uint8 USBlock) { return SBArray[SBlock][USBlock]; }
		inline Uint8 GetBData(Uint8 Block, Uint8 SBlock) { return BArray[Block][SBlock]; }
		inline Uint8 GetMapData(Uint8 Block) { return MapData[Block]; }
		inline Uint8 GetMapData(Uint8 Room, Uint8 Block) { return GetMapData(Room, Block % 5, Block / 5); }
		inline sLevelInfo GetLevelInfo() { return LevelInfo; }
		inline sThingInfo GetThingInfo() { return ThingInfo; }
		inline sGatewayInfo GetGatewayInfo() { return GatewayInfo; }
		inline sMiscInfo GetMiscInfo() { return MiscInfo; }
		inline Uint8 scrollUp(Uint8 Room) { return !((ScrollTable[Room / 8]) & (0x80 >> (Room % 8))); }
		inline Uint8 scrollDown(Uint8 Room) { return !((ScrollTable[(Room / 8 + 1) % 8]) & (0x80 >> (Room % 8))); }
		inline Uint8 scrollLeft(Uint8 Room) { return !((ScrollTable[Room / 8 + 8]) & (0x80 >> (Room % 8))); }
		inline Uint8 scrollRight(Uint8 Room) { return !((ScrollTable[Room / 8 + 8]) & (0x80 >> ((Room + 1) % 8))); }
		Uint8 GetMapData(Uint8 Room, Uint8 x, Uint8 y);
		void SetPalette(Uint8 Index, Uint8 Value);
		void SetUSBData(Uint8 USBlock, Uint8 Character, Uint16 Value);
		void SetSBData(Uint8 SBlock, Uint8 USBlock, Uint16 Value);
		void SetBData(Uint8 Block, Uint8 SBlock, Uint16 Value);
		void SetMapData(Uint8 Room, Uint8 x, Uint8 y, Uint16 Value);
		void ToggleUSBAttBit(Uint8 USBlock, int Bit);
		void ToggleScrollBit(Uint8 Room, int Direction);
		void BuildUSBGFX(Uint8 USBlock);
		void SetThingData(Uint8 Thing, Uint8 x, Uint8 y, Uint8 Type);
		void SetGatewayData(Uint8 Gateway, Uint8 x, Uint8 y, Uint8 Level);
		inline void SetMiscInfo(sMiscInfo NMiscInfo) { MiscInfo = NMiscInfo; }
		cLevel();
		~cLevel();
		void LoadInfo(sLevelInfo Info);
		void LoadLevel(FILE *DataFile);
		void LoadPalette(Uint8 *PaletteData);
		void LoadCharacters(Uint8 *CharData);
		void LoadUSBlocks(Uint8 *USBData);
		void LoadSBlocks(Uint8 *SBData);
		void LoadBlocks(Uint8 *BData);
		void LoadUSBAttributes(Uint8 *USBAttributes);
		void LoadMap(Uint8 *Map);
		void LoadScrollTable(Uint8 *Scroll);
		void LoadThings(Uint8 *Types, Uint8 *X, Uint8 *Y);
		static void LoadGateways(Uint8 *Gateway);
		static void LoadMisc(FILE *DataFile);
		static inline void SetGraphics(cGFX *NGraphics) { Graphics = NGraphics; }
		void DisplayUSBlock(int x, int y, Uint8 USBlock);
		void DisplayUSBlockScale(int x, int y, Uint8 USBlock, Uint8 Scale);
		void DisplaySBlock(int x, int y, Uint8 SBlock);
		void DisplayBlock(int x, int y, Uint8 Block);
		inline void DisplayRoom(Uint8 Room) { DisplayRoom(0, 0, Room); }
		void DisplayRoom(int x, int y, Uint8 Room);
		inline void DisplayRoomPlus(Uint8 Room) { DisplayRoomPlus(0, 0, Room); }
		void DisplayRoomPlus(int x, int y, Uint8 Room);
		void DisplayThings(int rx, int ry);
		void DisplayGateways(int rx, int ry);
		void DisplayUSBlockInfo(int x, int y, Uint8 USBlock);
		void DisplaySBlockInfo(int x, int y, Uint8 SBlock);
		void DisplayBlockInfo(int x, int y, Uint8 Block);
		void DisplayRoomInfo(int x, int y, Uint8 Room);
		void DisplayInfo(int x, int y);
		void SaveLevel(FILE *DataFile);
		void SaveMisc(FILE *DataFile);
		void SwitchTo();
};

#endif

