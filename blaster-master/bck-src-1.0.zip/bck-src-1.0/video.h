/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <SDL/SDL.h>
#include <string.h>

#ifndef _VIDEO_H
#define _VIDEO_H 1

class cGFX {
	private:
	        SDL_Surface *Screen;
        	Uint8 *CharArray[256];
		Uint8 *TextArray[256];
		Uint8 Palette[16];
		bool isFullScreen;
		int X, Y, BPP, Pitch;		// Local storage
	public:
		inline void Lock() { if (SDL_MUSTLOCK(Screen)) { SDL_LockSurface(Screen); } }
		inline void Unlock() { if (SDL_MUSTLOCK(Screen)) { SDL_UnlockSurface(Screen); } }
		inline void Update() { SDL_Flip(Screen); }
		inline void DumpToFile(const char *File) { SDL_SaveBMP(Screen, File); }
		inline void Clear() { Box(0, 0, Screen->w, Screen->h, 0); }
		void FullScreen();
		void Windowed();
		void ToggleFullScreen();
		cGFX();
		~cGFX();
		int InitGraphics(int x, int y, int bpp, int flags);
		void PutPixel(int x, int y, Uint32 pixel);
		void Box(int x, int y, int x2, int y2, Uint32 color);
		void Square(int x, int y, int x2, int y2, Uint32 color);
		void LoadCharacters(Uint8 *CharData);
		void LoadText(Uint8 *TextData);
		void LoadPalette(Uint8 *PaletteData);
		inline void DisplayCharacter(int x, int y, Uint8 Character) { DisplayCharacter(x, y, Character, 0); }
		void DisplayCharacter(int x, int y, Uint8 Character, Uint8 SubPalette);
		void DisplayCharacterScale(int x, int y, Uint8 Character, Uint8 SubPalette, Uint8 Scale);
		inline void DisplayLetter(int x, int y, Uint8 Letter) { DisplayLetter(x, y, Letter, 0xFFFFFF); }
		void DisplayLetter(int x, int y, Uint8 Letter, Uint32 Color);
		inline void DisplayText(int x, int y, const char *Text) { DisplayText(x, y, Text, 0xFFFFFF); }
		void DisplayText(int x, int y, const char *Text, Uint32 Color);
		void DisplayPalette(int x, int y);
		void BlitBlock(SDL_Surface *src, int x, int y);
};
#endif




