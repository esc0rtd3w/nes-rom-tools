/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _NESGFX_H
#define _NESGFX_H 1

const Uint32 NesColors[0x40] = {0x788084,	// 0x00
				0x0000FC,
				0x0000C4,
				0x4028C4,
				0x94008C,	// 0x04
				0xAC0028,
				0xAC1000,
				0x8C1800,
				0x503000,	// 0x08
				0x007800,
				0x006800,
				0x005800,
				0x004058,	// 0x0C
				0x000000,
				0x000000,
				0x000008,
				0xBCC0C4,	// 0x10
				0x0078FC,
				0x0088FC,
				0x6848FC,
				0xDC00D4,	// 0x14
				0xE40060,
				0xFC3800,
				0xE46018,
				0xAC8000,	// 0x18
				0x00B800,
				0x00A800,
				0x00A848,
				0x008894,	// 0x1C
				0x2C2C2C,
				0x000000,
				0x000000,
				0xFCF8FC,	// 0x20
				0x38C0FC,
				0x6888FC,
				0x9C78FC,
				0xFC78FC,	// 0x24
				0xFC589C,
				0xFC7858,
				0xFCA048,
				0xFCB800,	// 0x28
				0xBCF818,
				0x58D858,
				0x58F89C,
				0x00E8E4,	// 0x2C
				0x606060,
				0x000000,
				0x000000,
				0xFCF8FC,	// 0x30
				0xA4E8FC,
				0xBCB8FC,
				0xDCB8FC,
				0xFCB8FC,	// 0x34
				0xF4C0E0,
				0xF4D0B4,
				0xFCE0B4,
				0xFCD884,	// 0x38
				0xDCF878,
				0xB8F878,
				0xB0F0D8,
				0x00F8FC,	// 0x3C
				0xC8C0C0,
				0x000000,
				0x000000
				};
				

void LoadCharacter(Uint8 *Source, Uint8 *Dest, Uint8 Character);
#endif

