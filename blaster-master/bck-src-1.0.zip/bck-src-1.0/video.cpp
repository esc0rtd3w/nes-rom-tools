/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <SDL/SDL.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "video.h"
#include "nesgfx.h"
#include "bmtypes.h"
#include "bckcfg.h"

cGFX::cGFX()
{
	for (int Loop = 0; Loop < 256; Loop++)
	{
		CharArray[Loop] = TextArray[Loop] = NULL;
	}
	Screen = NULL;
	isFullScreen = false;
}

cGFX::~cGFX()
{
	for (int Loop = 0; Loop < 256; Loop++)
	{
		if (CharArray[Loop]) {
			delete CharArray[Loop];
		}
		if (TextArray[Loop]) {
			delete TextArray[Loop];
		}
	}
	if (isFullScreen) {
		ToggleFullScreen();
	}
	SDL_Quit();
}

int cGFX::InitGraphics(int x, int y, int bpp, int flags)
{
        Screen = SDL_SetVideoMode(x, y, bpp, flags);
        if ( Screen == NULL) {
        	char Buffer[80];
                sprintf(Buffer, "Couldn't set %dx%dx%d video mode: %s\n", x, y, bpp, SDL_GetError());
                ERR(Buffer);
		return 1;
        }
	X = Screen->w;
	Y = Screen->h;
	BPP = Screen->format->BitsPerPixel;
	Pitch = Screen->pitch;
	return 0;
}

void cGFX::FullScreen()
{
	if (!isFullScreen) {
		ToggleFullScreen();
	}
}

void cGFX::Windowed()
{
	if (isFullScreen) {
		ToggleFullScreen();
	}
}

void cGFX::ToggleFullScreen()
{
	int x, y, bpp, flags;
	x = Screen->w;
	y = Screen->h;
	bpp = Screen->format->BitsPerPixel;
	flags = Screen->flags ^ SDL_FULLSCREEN;
	Screen = SDL_SetVideoMode(x, y, bpp, flags);
	if ( Screen == NULL ) {
		ERR("Couldn't toggle screen mode: %s\n", SDL_GetError());
		flags ^= SDL_FULLSCREEN;
		Screen = SDL_SetVideoMode(x, y, bpp, flags);
	}
	isFullScreen = !isFullScreen;
}

void cGFX::PutPixel(int x, int y, Uint32 pixel)
{
	int bpp = Screen->format->BytesPerPixel;

	Uint8 *p = (Uint8 *)Screen->pixels + y * Screen->pitch + x * bpp;

	switch(bpp) {
		case 1: {
			*p = pixel;
			break;
		}
		case 2: {
			*(Uint16 *)p = pixel;
			break;
		}
		case 3: {
			if(SDL_BYTEORDER == SDL_BIG_ENDIAN) {
				p[0] = (pixel >> 16) & 0xff;
				p[1] = (pixel >> 8) & 0xff;
				p[2] = pixel & 0xff;
			} else {
				p[0] = pixel & 0xff;
				p[1] = (pixel >> 8) & 0xff;
				p[2] = (pixel >> 16) & 0xff;
			}
			break;
		}
		case 4: {
			*(Uint32 *)p = pixel;
			break;
		}
	}
}

void cGFX::Box(int x, int y, int x2, int y2, Uint32 color)
{
	SDL_Rect rect;

	if ((x2 < x) || (y2 < y)) {
		return;
	}

	rect.x = x;
	rect.y = y;
	rect.w = x2 - x;
	rect.h = y2 - y;

	if (BPP == 16) {
		color = SDL_MapRGB(Screen->format, (color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF);
	}
	
	SDL_FillRect(Screen, &rect, color);
}

void cGFX::Square(int x, int y, int x2, int y2, Uint32 color)
{
	if (BPP == 32) {
		int pitch = Pitch / 4;
		Uint32 *BaseP = (Uint32 *)Screen->pixels + y * pitch + x;
		Uint32 *P = BaseP;

		for (int Loop = x; Loop <= x2; Loop++) {
			*(P++) = color;
		}
		P = BaseP + (y2 - y) * pitch;
		for (int Loop = x; Loop <= x2; Loop++) {
			*(P++) = color;
		}
	
		P = BaseP;
		for (int Loop = y; Loop <= y2; Loop++) {
			*P = color;
			P += pitch;
		}
		P = BaseP + (x2 - x);
		for (int Loop = y; Loop <= y2; Loop++) {
			*P = color;
			P += pitch;
		}
	} else if (BPP == 16) {
		int pitch = Pitch / 2;
		Uint16 *BaseP = (Uint16 *)Screen->pixels + y * pitch + x;
		Uint16 *P = BaseP;
		color = SDL_MapRGB(Screen->format, (color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF);
		for (int Loop = x; Loop <= x2; Loop++) {
			*(P++) = color;
		}
		P = BaseP + (y2 - y) * pitch;
		for (int Loop = x; Loop <= x2; Loop++) {
			*(P++) = color;
		}
	
		P = BaseP;
		for (int Loop = y; Loop <= y2; Loop++) {
			*P = color;
			P += pitch;
		}
		P = BaseP + (x2 - x);
		for (int Loop = y; Loop <= y2; Loop++) {
			*P = color;
			P += pitch;
		}
	}
}

void cGFX::LoadCharacters(Uint8 *CharData)
{
        for (int Loop = 0; Loop < 256; Loop++) {
                CharArray[Loop] = new Uint8[64];
                LoadCharacter(CharData, CharArray[Loop], Loop);
        }
}

void cGFX::LoadText(Uint8 *TextData)
{
	for (int Loop = 0; Loop < 256; Loop++) {
		TextArray[Loop] = new Uint8[64];
		LoadCharacter(TextData, TextArray[Loop], Loop);
	}
}

void cGFX::LoadPalette(Uint8 *PaletteData)
{
	memcpy(Palette, PaletteData, 16);
}

void cGFX::DisplayCharacter(int x, int y, Uint8 Character, Uint8 SubPalette)
{
	int LoopA, LoopB, CurPixel = 0;
	if (BPP == 32) {
		int pitch = Screen->pitch / 4;
		Uint32 *P = (Uint32 *)Screen->pixels + y * pitch + x;
		Uint32 Temp[8];
		for (LoopA = 0; LoopA < 8; LoopA++) {
			for (LoopB = 0; LoopB < 8; LoopB++) {
				Temp[LoopB] = NesColors[Palette[CharArray[Character][CurPixel++] + SubPalette * 4]];
			}
			memcpy(P, Temp, 32);
			P += pitch;
		}
	} else if (BPP == 16) {
		int pitch = Pitch / 2;
		Uint16 *P = (Uint16 *)Screen->pixels + y * pitch + x;
		Uint16 Temp[8];
		Uint32 TempB;
		for (LoopA = 0; LoopA < 8; LoopA++) {
			for (LoopB = 0; LoopB < 8; LoopB++) {
				TempB = NesColors[Palette[CharArray[Character][CurPixel++] + SubPalette * 4]];
				Temp[LoopB] = SDL_MapRGB(Screen->format, (TempB >> 16) & 0xFF, (TempB >> 8) & 0xFF, TempB & 0xFF);
			}
			memcpy(P, Temp, 16);
			P += pitch;
		}
	}
}

void cGFX::DisplayCharacterScale(int x, int y, Uint8 Character, Uint8 SubPalette, Uint8 Scale)
{
	int LoopA, LoopB, LoopC;
	if (BPP == 32) {
		Uint32 Color;
		int pitch = Screen->pitch / 4;
		Uint32 *P = (Uint32 *)Screen->pixels + y * pitch + x;
		Uint32 *Temp;
		Uint8 CurPixel = 0;
		Uint8 CurIndex = 0;
		
		Temp = new Uint32[Scale * 8];
		
		for (LoopA = 0; LoopA < 8; LoopA++) {
			for (LoopB = 0; LoopB < 8; LoopB++) {
				Color = NesColors[Palette[CharArray[Character][CurPixel++] + SubPalette * 4]];
				for (LoopC = 0; LoopC < Scale; LoopC++) {
					Temp[CurIndex++] = Color;
				}
			}
			for (LoopC = 0; LoopC < Scale; LoopC++) {
				memcpy(P, Temp, Scale * 32);
				P += pitch;
			}
			CurIndex = 0;
		}
		delete Temp;
	} else if (BPP == 16) {
		Uint32 Color;
		int pitch = Pitch / 2;
		Uint16 *P = (Uint16 *)Screen->pixels + y * pitch + x;
		Uint16 *Temp;
		Uint8 CurPixel = 0;
		Uint8 CurIndex = 0;
		
		Temp = new Uint16[Scale * 8];
		
		for (LoopA = 0; LoopA < 8; LoopA++) {
			for (LoopB = 0; LoopB < 8; LoopB++) {
				Color = NesColors[Palette[CharArray[Character][CurPixel++] + SubPalette * 4]];
				for (LoopC = 0; LoopC < Scale; LoopC++) {
					Temp[CurIndex++] = SDL_MapRGB(Screen->format, (Color >> 16) & 0xFF, (Color >> 8) & 0xFF, Color & 0xFF);
				}
			}
			for (LoopC = 0; LoopC < Scale; LoopC++) {
				memcpy(P, Temp, Scale * 16);
				P += pitch;
			}
			CurIndex = 0;
		}
		delete Temp;
	}
}

void cGFX::DisplayLetter(int x, int y, Uint8 Letter, Uint32 Color)
{
	int LoopA, LoopB, CurPixel = 0;
	if (BPP == 32) {
		int pitch = Pitch / 4;
		Uint32 *P = (Uint32 *)Screen->pixels + y * pitch + x;
		Uint32 TempA[8];
		for (LoopA = 0; LoopA < 8; LoopA++) {
			for (LoopB = 0; LoopB < 8; LoopB++) {
				TempA[LoopB] = (TextArray[Letter][CurPixel++]) ? Color : 0;
			}
			memcpy(P, TempA, 32);
			P += pitch;
		}
	} else if (BPP == 16) {
		int pitch = Pitch / 2;
		Uint16 *P = (Uint16 *)Screen->pixels + y * pitch + x;
		Uint16 TempA[8];
		for (LoopA = 0; LoopA < 8; LoopA++) {
			for (LoopB = 0; LoopB < 8; LoopB++) {
				TempA[LoopB] = (TextArray[Letter][CurPixel++]) ? SDL_MapRGB(Screen->format, (Color >> 16) & 0xFF, (Color >> 8) & 0xFF, Color & 0xFF) : 0;
			}
			memcpy(P, TempA, 16);
			P += pitch;
		}
	}
}

void cGFX::DisplayText(int x, int y, const char *Text, Uint32 Color)
{
	int Loop = 0;
	while ( isupper(Text[Loop]) || isblank(Text[Loop]) || isdigit(Text[Loop]) || Text[Loop] == '!' )
	{
		DisplayLetter(x + Loop * 8, y, Text[Loop], Color);
		Loop++;
	}
}

void cGFX::DisplayPalette(int x, int y)
{
	for (int Loop = 0; Loop < 16; Loop++) {
		Box(x, y + Loop * 16, x + 15, y + Loop * 16 + 15, NesColors[Palette[Loop]]);
		Square(x, y + Loop * 16, x + 15, y + Loop * 16 + 15, 0xFFFFFF);
	}
}

void cGFX::BlitBlock(SDL_Surface *src, int x, int y)
{
	SDL_Rect rect;
	rect.x = x;
	rect.y = y;
	if (SDL_BlitSurface(src, NULL, Screen, &rect)) {
		ERR("%d %d Blit Unsucessful!\n", x, y);
	}
}

