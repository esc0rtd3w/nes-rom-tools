/* cZones - Class for handling "zones" on a screen, useful for GUI mouse clicks -
 * Built with SDL in mind, but should be fairly portable
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

struct sZone {
	int X, Y, W, H, P;
};

class cZones {
	private:
		sZone **Zones;
		int NumZones;
	public:
		cZones();
		~cZones();
		void SetNumZones(int NZones); 						// Allocates a set of pointers for sZone structures, destroys any old zones
		int AddZone(int X, int Y, int W, int H, int P); 	// Searches for an empty zone and adds it, returns an id which can be used to identify the zone later, or -1 if there were no empty zones left
		int AddZone(int X, int Y, int W, int H, int P, int id);		// Adds a new zone in the specified location, or replaces an existing one. Returns -1 if it could not be added (probably due to NumZones being set too low)
		void RemoveZone(int id);							// Removes the zone from use
		int TestZone(int X, int Y);							// Returns which zone the point is in, or -1 for none
		inline sZone *RetrieveZone(int id) { return (id < NumZones) ? Zones[id] : NULL; };					// Returns the identified zone, useful for drawing a rectangle or box in the zone's position, or NULL if the zone doesn't exist (all zones are initialized to NULL, so this should be safe)
};
