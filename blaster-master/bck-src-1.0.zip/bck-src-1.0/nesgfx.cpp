/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <SDL/SDL.h>
#include <stdio.h>
#include "nesgfx.h"

/** This function converts a raw NES character into an 8 bit bitmap
  * Source = Pointer to the 4k raw character table
  * Dest = Pointer to a 64 byte character array to store the converted data
  * Character = Which character to load in (Y = Character / 16, X = Character % 16)
  */ 

void LoadCharacter(Uint8 *Source, Uint8 *Dest, Uint8 Character) {
	Uint8 *CurSource = Source + (Character * 16);
	Uint32 Loop;
	for(Loop = 0; Loop < 64; Loop++) {
		Uint8 CurByte, CurBit, Bit1, Bit2;
		CurByte = Loop / 8;
		CurBit = 128 >> ( Loop % 8 );
		Bit1 = ( CurSource[CurByte] & CurBit ) && 1;
		Bit2 = ( CurSource[CurByte + 8] & CurBit ) && 1;
		Bit2 *= 2; 
		Dest[Loop] = Bit1 + Bit2;
	}	
}

