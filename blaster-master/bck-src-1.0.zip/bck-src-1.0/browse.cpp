/* Blaster Construction Kit - Views/Edits Blaster Master NES ROM
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Benjamin Cutler
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <SDL/SDL.h>
#include <stdio.h>
#include "nesgfx.h"
#include "video.h"
#include "level.h"
#include "zones.h"
#include "bmtypes.h"
#include "rle.h"

enum BSTATE {
	BSTATE_NONE,
	BSTATE_USBLOCK,
	BSTATE_SBLOCK,
	BSTATE_BLOCK,
	BSTATE_MAP,
	BSTATE_THINGS,
	BSTATE_GLOBAL,
	BSTATE_PALETTE,
	BSTATE_RLE,
	BSTATE_TEST,
	BSTATE_QUIT
};

enum GSTATE {
	GSTATE_NONE,
	GSTATE_GATEWAYS,
	GSTATE_START,
	GSTATE_GATEA,
	GSTATE_GATEB,
	GSTATE_BOSS3,
	GSTATE_BOSS4,
	GSTATE_BOSS7,
	GSTATE_MISC,
	GSTATE_ENEMY,
	GSTATE_TOGGLE,
	GSTATE_SAVE,
	GSTATE_RESET,
	GSTATE_QUIT
};

enum {
	BROWSE_SAVE,
	BROWSE_REVERT,
	BROWSE_QUITSAVE,
	BROWSE_QUIT,
	BROWSE_TEST,
	BROWSE_SWITCHSAVE,
	BROWSE_SWITCH
};

const char *BOSS3ATTACKS[] = { "", "RIGHT", "LEFT", "DOWN", "UP", "SHOOT" };
const char *BOSS47ATTACKS[] = { "PAUSE", "HOP", "FIREBALL", "TRIBALL", "TONGUE", "FIRE TONGUE" };

void BrowseUSBlocks(cLevel &Level, cGFX *Graphics);
void BrowseSBlocks(cLevel &Level, cGFX *Graphics);
void BrowseBlocks(cLevel &Level, cGFX *Graphics);
void BrowseMap(cLevel &Level, cGFX *Graphics);
void BrowseThings(cLevel &Level, cGFX *Graphics);
void BrowseGateways(cLevel &Level, cGFX *Graphics);
void BrowseGlobal(cLevel &Level, cGFX *Graphics);
void BrowsePalette(cLevel &Level, cGFX *Graphics);

void BrowseRLE(cGFX *Graphics, cRLE *RLE);

void BrowseStart(cLevel &Level, cGFX *Graphics, sMiscInfo &MiscInfo);

void BrowseBoss3(sMiscInfo &MiscInfo, cGFX *Graphics);
void BrowseBoss4(sMiscInfo &MiscInfo, cGFX *Graphics);
void BrowseBoss7(sMiscInfo &MiscInfo, cGFX *Graphics);
void BrowseMisc(sMiscInfo &MiscInfo, cGFX *Graphics);
void BrowseGateA(sMiscInfo &MiscInfo, cGFX *Graphics);
void BrowseGateB(sMiscInfo &MiscInfo, cGFX *Graphics);

void BrowseEnemyStats(sMiscInfo &MiscInfo, cGFX *Graphics);

int DropExtraMouseEvents(const SDL_Event *Event);

int BrowseLevel(cLevel &Level, cGFX *Graphics, cRLE *RLE) {
	BSTATE state = BSTATE_NONE;
	int returnvalue = BROWSE_QUIT;
	int Loop;
	int PrevZone = -1;
	SDL_Event event;
	char Buffer[80];
	cZones Zones;
	bool Draw = true;
	const int NUM_COMMANDS = 15;
	const char *COMMANDS[] = { 	"U  EDIT USBLOCKS",
							"S  EDIT SBLOCKS",
							"B  EDIT BLOCKS",
							"M  EDIT MAP",
							"E  EDIT THINGS",
							"G  EDIT GLOBAL DATA",
							"P  EDIT PALETTE",
							"Z  VIEW RLE SCREENS",
							"T  TEST ROM",
							"W  SAVE CURRENT LEVEL",
							"R  REVERT TO LAST SAVED",
							"C  CHANGE LEVEL",
							"V  SAVE CURRENT LEVEL AND CHANGE LEVEL",
							"Q  SAVE CURRENT LEVEL AND QUIT",
							"ESC QUIT WITHOUT SAVE" };

	Zones.SetNumZones(NUM_COMMANDS);

	for (Loop = 0; Loop < NUM_COMMANDS; Loop++) {
		Zones.AddZone(0, Loop * 8, strlen(COMMANDS[Loop]) * 8 - 1, 7, 0);
	}

	do {
		switch(state) {
			case(BSTATE_NONE) : {
				if (Draw) {
					Graphics->Lock();
					Graphics->Clear();

					for (Loop = 0; Loop < NUM_COMMANDS; Loop++) {
						Graphics->DisplayText(0, Loop * 8, COMMANDS[Loop]);
					}
	
					sprintf(Buffer, "CURRENT LEVEL %d %c", Level.GetLevelInfo().LevelNum, Level.GetLevelInfo().isOverhead ? 'O' : 'T');
	
					Graphics->DisplayText(0, NUM_COMMANDS * 8 + 16, Buffer);
	
					Graphics->Unlock();
					Graphics->Update();
					
					Draw = false;
				}
		 		SDL_WaitEvent(&event);
				switch (event.type) {
					case(SDL_QUIT) : {
						state = BSTATE_QUIT;
						returnvalue = BROWSE_QUIT;
						break;
					} 
					case(SDL_KEYDOWN) : {
						switch (event.key.keysym.sym) {
							case (SDLK_ESCAPE): {
								state = BSTATE_QUIT;
								returnvalue = BROWSE_QUIT;
								break;
							}
							case (SDLK_q): {
									state = BSTATE_QUIT;
									returnvalue = BROWSE_QUITSAVE;
								break;
							}
							case (SDLK_w): {
								state = BSTATE_QUIT;
								returnvalue = BROWSE_SAVE;
								break;
							}
							case (SDLK_r): {
								state = BSTATE_QUIT;
								returnvalue = BROWSE_REVERT;
								break;
							}
							case (SDLK_t): {
								state = BSTATE_QUIT;
								returnvalue = BROWSE_TEST;
								break;
							}
							case (SDLK_c): {
								state = BSTATE_QUIT;
								returnvalue = BROWSE_SWITCH;
								break;
							}
							case (SDLK_v): {
								state = BSTATE_QUIT;
								returnvalue = BROWSE_SWITCHSAVE;
								break;
							}
							case (SDLK_u): {
								state = BSTATE_USBLOCK;
								break;
							}
							case (SDLK_s): {
								state = BSTATE_SBLOCK;
								break;
							}
							case (SDLK_b): {
								state = BSTATE_BLOCK;
								break;
							}
							case (SDLK_m): {
								state = BSTATE_MAP;
								break;
							}
							case (SDLK_e): {
								state = BSTATE_THINGS;
								break;
							}
							case (SDLK_g): {
								state = BSTATE_GLOBAL;
								break;
							}
							case (SDLK_z): {
								state = BSTATE_RLE;
								break;
							}
							case (SDLK_p): {
								state = BSTATE_PALETTE;
								break;
							}
							case (SDLK_RETURN) : {
								if (event.key.keysym.mod && KMOD_ALT) {
									Graphics->ToggleFullScreen();
									Draw = true;
								}
								break;
							}
							default: break;
						}	// switch (event.key.keysym.sym)
						break;
					} // case(SDL_KEYDOWN)
					case(SDL_MOUSEBUTTONDOWN) : {
						if (event.button.button == SDL_BUTTON_LEFT) {
							switch (Zones.TestZone(event.button.x, event.button.y)) {
								case(0) : {
									state = BSTATE_USBLOCK;
									break;
								}
								case(1) : {
									state = BSTATE_SBLOCK;
									break;
								}
								case(2) : {
									state = BSTATE_BLOCK;
									break;
								}
								case(3) : {
									state = BSTATE_MAP;
									break;
								}
								case(4) : {
									state = BSTATE_THINGS;
									break;
								}
								case(5) : {
									state = BSTATE_GLOBAL;
									break;
								}
								case(6) : {
									state = BSTATE_PALETTE;
									break;
								}
								case(7) : {
									state = BSTATE_RLE;
									break;
								}
								case(8) : {
									state = BSTATE_QUIT;
									returnvalue = BROWSE_TEST;
									break;
								}
								case(9) : {
									state = BSTATE_QUIT;
									returnvalue = BROWSE_SAVE;
									break;
								}
								case(10) : {
									state = BSTATE_QUIT;
									returnvalue = BROWSE_REVERT;
									break;
								}
								case(11) : {
									state = BSTATE_QUIT;
									returnvalue = BROWSE_SWITCH;
									break;
								}
								case(12) : {
									state = BSTATE_QUIT;
									returnvalue = BROWSE_SWITCHSAVE;
									break;
								}
								case(13) : {
									state = BSTATE_QUIT;
									returnvalue = BROWSE_QUITSAVE;
									break;
								}
								case(14) : {
									state = BSTATE_QUIT;
									returnvalue = BROWSE_QUIT;
									break;
								}
								default : break;
							} // switch (Zones.TestZone(event.button.x, event.button.y)
						} // if (event.button.button == SDL_BUTTON_LEFT)
						break;
					} // case (SDL_MOUSEBUTTONDOWN)
					case (SDL_MOUSEMOTION) : {
						int Temp = Zones.TestZone(event.motion.x, event.motion.y);
						if (PrevZone != Temp) {
							Graphics->Lock();
							if (PrevZone != -1) {
								Graphics->DisplayText(0, PrevZone * 8, COMMANDS[PrevZone]);
							}
							if (Temp != -1) {
								Graphics->DisplayText(0, Temp * 8, COMMANDS[Temp], 0xFFFF00);
							}
							PrevZone = Temp;
							Graphics->Unlock();
							Graphics->Update();
						}
						break;
					}
					default : break;
				} // switch(event.type)
				break;
			}	// case (BSTATE_NONE):
			case (BSTATE_USBLOCK) : {
				BrowseUSBlocks(Level, Graphics);
				state = BSTATE_NONE;
				Draw = true;
				break;
			}
			case (BSTATE_SBLOCK) : {
				BrowseSBlocks(Level, Graphics);
				state = BSTATE_NONE;
				Draw = true;
				break;
			}
			case (BSTATE_BLOCK) : {
				BrowseBlocks(Level, Graphics);
				state = BSTATE_NONE;
				Draw = true;
				break;
			}
			case (BSTATE_MAP) : {
				BrowseMap(Level, Graphics);
				state = BSTATE_NONE;
				Draw = true;
				break;
			}
			case (BSTATE_THINGS) : {
				BrowseThings(Level, Graphics);
				state = BSTATE_NONE;
				Draw = true;
				break;
			}
			case (BSTATE_GLOBAL) : {
				BrowseGlobal(Level, Graphics);
				state = BSTATE_NONE;
				Draw = true;
				break;
			}
			case (BSTATE_RLE) : {
				BrowseRLE(Graphics, RLE);
				state = BSTATE_NONE;
				Draw = true;
				break;
			}
			case (BSTATE_PALETTE) : {
				BrowsePalette(Level, Graphics);
				state = BSTATE_NONE;
				Draw = true;
				break;
			}
			default: {
				state = BSTATE_QUIT;
				break;
			}
		}	// switch(state)
	} while ( state != BSTATE_QUIT );

	return returnvalue;
}

void BrowseUSBlocks(cLevel &Level, cGFX *Graphics)
{
	Uint8 CurUSBlock = 0;
	Uint8 CurCharacter = 0;
	Uint16 Delta = 1;
	bool Update = true, Quit = false;
	sLevelInfo LevelInfo = Level.GetLevelInfo();
	SDL_Event event;
	char Buffer[80];
	cZones Zones;
	unsigned int Loop;

	Zones.SetNumZones(276);

	// Block Zones
	for (Loop = 0; Loop < LevelInfo.NumUSB; Loop++) {
		Zones.AddZone((Loop % 16) * 16, (Loop / 16) * 16, 15, 15, 0);
	}

	
	// Text Picker Zones
	Zones.AddZone(258, 12, 23, 7, 0, 256);
	Zones.AddZone(272, 12, 23, 7, 0, 257);
	Zones.AddZone(258, 28, 23, 7, 0, 258);
	Zones.AddZone(272, 28, 23, 7, 0, 259);

	// Zoom Zones
	Zones.AddZone(400, 0, 31, 31, 0, 264);
	Zones.AddZone(432, 0, 31, 31, 0, 265);
	Zones.AddZone(400, 32, 31, 31, 0, 266);
	Zones.AddZone(432, 32, 31, 31, 0, 267);

	// Bit Zones (right to left)
	Zones.AddZone(258, 60, 7, 7, 0, 275);
	Zones.AddZone(266, 60, 7, 7, 0, 274);
	Zones.AddZone(274, 60, 7, 7, 0, 273);
	Zones.AddZone(282, 60, 7, 7, 0, 272);
	Zones.AddZone(290, 60, 7, 7, 0, 271);
	Zones.AddZone(298, 60, 7, 7, 0, 270);
	Zones.AddZone(306, 60, 7, 7, 0, 269);
	Zones.AddZone(314, 60, 7, 7, 0, 268);

	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			for (Loop = 0; Loop < LevelInfo.NumUSB; Loop++) {
				Level.DisplayUSBlock((Loop % 16) * 16, (Loop / 16) * 16, Loop);
			}
			Graphics->Lock();
			Level.DisplayUSBlockScale(400, 0, CurUSBlock, 4);
			Graphics->Box(258, 12, 305, 35, 0);
			Level.DisplayUSBlockInfo(258, 12, CurUSBlock);
			sprintf(Buffer, "U  %02X", CurUSBlock);
			Graphics->DisplayText(258, 2, Buffer);
			Graphics->DisplayText((CurCharacter % 2) ? 298 : 274, (CurCharacter / 2) ? 28 : 12, "!");
			Graphics->Square((CurUSBlock % 16) * 16 + ((CurCharacter % 2) ? 8 : 0), 
							(CurUSBlock / 16) * 16 + ((CurCharacter / 2) ? 8 : 0), 
							(CurUSBlock % 16) * 16 + ((CurCharacter % 2) ? 15 : 7), 
							(CurUSBlock / 16) * 16 + ((CurCharacter / 2) ? 15 : 7), 0x7F7F7F);
			Graphics->Square((CurCharacter % 2) ? 432 : 400, 
							(CurCharacter / 2) ? 32 : 0, 
							(CurCharacter % 2) ? 463 : 431, 
							(CurCharacter / 2) ? 63 : 31, 0x7F7F7F);
			Graphics->Square((CurUSBlock % 16) * 16, 
							(CurUSBlock / 16) * 16, 
							(CurUSBlock % 16) * 16 + 15, 
							(CurUSBlock / 16) * 16 + 15, 0xFFFFFF);
			Graphics->Square(256, 0, 307, 10, 0xFFFFFF);
			Graphics->Square(256, 10, 362, 140, 0xFFFFFF);
			if (LevelInfo.NumUSB == 0xFF) {
				Graphics->DisplayText(0, 256, "ATTRIBUTE BITMASK EDITING NOT ADVISED DUE TO UNSET USB NUMBER");
			}
			Graphics->Unlock();
			Graphics->Update();

			// Reset graphics picker zones
			Zones.AddZone((CurUSBlock % 16) * 16, (CurUSBlock / 16) * 16, 7, 7, 1, 260);
			Zones.AddZone((CurUSBlock % 16) * 16 + 8, (CurUSBlock / 16) * 16, 7, 7, 1, 261);
			Zones.AddZone((CurUSBlock % 16) * 16, (CurUSBlock / 16) * 16 + 8, 7, 7, 1, 262);
			Zones.AddZone((CurUSBlock % 16) * 16 + 8, (CurUSBlock / 16) * 16 + 8, 7, 7, 1, 263);

			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_RIGHT) : {
						CurUSBlock++;
						CurUSBlock %= LevelInfo.NumUSB;
						Update = true;
						break;
					}
					case(SDLK_LEFT) : {
						if (CurUSBlock == 0x00) {
							CurUSBlock = LevelInfo.NumUSB;
						}
						CurUSBlock--;
						Update = true;
						break;
					}
					case(SDLK_UP) : {
						if (CurUSBlock < 0x10) {
							CurUSBlock += LevelInfo.NumUSB;
						}
						CurUSBlock -= 0x10;
						Update = true;
						break;
					}
					case(SDLK_DOWN) : {
						CurUSBlock += 0x10;
						CurUSBlock %= LevelInfo.NumUSB;
						Update = true;
						break;
					}
					case(SDLK_LEFTBRACKET) : {
						if (!CurCharacter) {
							CurCharacter = 3;
						} else {
							CurCharacter--;
						}
						Update = true;
						break;
					}
					case(SDLK_RIGHTBRACKET) : {
						if (CurCharacter == 3) {
							CurCharacter = 0;
						} else {
							CurCharacter++;
						}
						Update = true;
						break;
					}
					case(SDLK_EQUALS) : {
						Level.SetUSBData(CurUSBlock, CurCharacter, Level.GetUSBData(CurUSBlock, CurCharacter) + Delta);
						Update = true;
						break;
					}
					case(SDLK_MINUS) : {
						if (Level.GetUSBData(CurUSBlock, CurCharacter) >= Delta) {
							Level.SetUSBData(CurUSBlock, CurCharacter, Level.GetUSBData(CurUSBlock, CurCharacter) - Delta);
						}
						Update = true;
						break;
					}
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case(SDLK_1) : {
						Level.ToggleUSBAttBit(CurUSBlock, 0);
						Update = true;
						break;
					}
					case(SDLK_2) : {
						Level.ToggleUSBAttBit(CurUSBlock, 1);
						Update = true;
						break;
					}
					case(SDLK_3) : {
						Level.ToggleUSBAttBit(CurUSBlock, 2);
						Update = true;
						break;
					}
					case(SDLK_4) : {
						Level.ToggleUSBAttBit(CurUSBlock, 3);
						Update = true;
						break;
					}
					case(SDLK_5) : {
						Level.ToggleUSBAttBit(CurUSBlock, 4);
						Update = true;
						break;
					}
					case(SDLK_6) : {
						Level.ToggleUSBAttBit(CurUSBlock, 5);
						Update = true;
						break;
					}
					case(SDLK_7) : {
						Level.ToggleUSBAttBit(CurUSBlock, 6);
						Update = true;
						break;
					}
					case(SDLK_8) : {
						Level.ToggleUSBAttBit(CurUSBlock, 7);
						Update = true;
						break;
					}
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE):
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: break;
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			case(SDL_MOUSEBUTTONDOWN) : {
				if ((event.button.button != SDL_BUTTON_WHEELUP) && (event.button.button != SDL_BUTTON_WHEELDOWN)) {
					int Temp = Zones.TestZone(event.button.x, event.button.y);
					if (Temp != -1) {
						if (Temp > 263 && Temp < 268) { // Dynamic Zone Click, map to Zoom Block Click
							Temp -= 4;
						}
						if (Temp < 256) {			// Block Click
							CurUSBlock = Temp;
						} else if (Temp < 260) {	// Character Click
							CurCharacter = Temp - 256;
						} else if (Temp < 264) {	// Zoom Block Click
							if ((CurCharacter + 260) == Temp) {
								switch(event.button.button) {
									case(SDL_BUTTON_LEFT) : {
										if (Level.GetUSBData(CurUSBlock, CurCharacter) >= Delta) {
											Level.SetUSBData(CurUSBlock, CurCharacter, Level.GetUSBData(CurUSBlock, CurCharacter) - Delta);
										}
										break;
									}
									case(SDL_BUTTON_RIGHT) : {
										Level.SetUSBData(CurUSBlock, CurCharacter, Level.GetUSBData(CurUSBlock, CurCharacter) + Delta);
										break;
									}
									default : break;
								}
							} else {
								CurCharacter = Temp - 260;
							}
						} else {					// Bit Click
							Level.ToggleUSBAttBit(CurUSBlock, Temp - 268);
						}
						Update = true;
					}
				} else {	//	Wheel rolled
					if (event.button.button == SDL_BUTTON_WHEELUP) {
						Level.SetUSBData(CurUSBlock, CurCharacter, Level.GetUSBData(CurUSBlock, CurCharacter) + Delta);
					} else { // Wheel down
						if (Level.GetUSBData(CurUSBlock, CurCharacter) >= Delta) {
							Level.SetUSBData(CurUSBlock, CurCharacter, Level.GetUSBData(CurUSBlock, CurCharacter) - Delta);
						}
					}
					Update = true;
				}	// if (not [wheel])
				break;
			}
			default: break;
		} // switch (event.type)
	} while (!Quit);
}

void BrowseSBlocks(cLevel &Level, cGFX *Graphics)
{
	Uint8 CurSBlock = 0;
	Uint8 CurUSBlock = 0;
	Uint16 Delta = 1;
	bool Update = true, Quit = false;
	sLevelInfo LevelInfo = Level.GetLevelInfo();
	SDL_Event event;
	char Buffer[80];
	unsigned int Loop;
	cZones Zones;

	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	Zones.SetNumZones(264);

	for (Loop = 0; Loop < LevelInfo.NumSB; Loop++) {
		Zones.AddZone((Loop % 16) * 32, (Loop / 16) * 32, 31, 31, 0);
	}

	Zones.AddZone(514, 12, 23, 7, 0, 256);
	Zones.AddZone(538, 12, 23, 7, 0, 257);
	Zones.AddZone(514, 28, 23, 7, 0, 258);
	Zones.AddZone(538, 28, 23, 7, 0, 259);

	do {
		if (Update) {
			for (Loop = 0; Loop < LevelInfo.NumSB; Loop++) {
				Level.DisplaySBlock((Loop % 16) * 32, (Loop / 16) * 32, Loop);
			}
			Graphics->Lock();
			Graphics->Box(514, 12, 562, 36, 0);
			Level.DisplaySBlockInfo(514, 12, CurSBlock);
			Level.DisplayUSBlockInfo(565, 12, Level.GetSBData(CurSBlock, CurUSBlock));
			sprintf(Buffer, "S %02X", CurSBlock);
			Graphics->DisplayText(514, 2, Buffer);
			sprintf(Buffer, "U %02X", Level.GetSBData(CurSBlock, CurUSBlock));
			Graphics->DisplayText(565, 2, Buffer);
			Graphics->DisplayText((CurUSBlock % 2) ? 554 : 530, (CurUSBlock / 2) ? 28 : 12, "!");
			Graphics->Square((CurSBlock % 16) * 32 + ((CurUSBlock % 2) ? 16 : 0), 
							(CurSBlock / 16) * 32 + ((CurUSBlock / 2) ? 16 : 0), 
							(CurSBlock % 16) * 32 + ((CurUSBlock % 2) ? 31 : 15), 
							(CurSBlock / 16) * 32 + ((CurUSBlock / 2) ? 31 : 15), 0x7F7F7F);
			Graphics->Square((CurSBlock % 16) * 32, 
							(CurSBlock / 16) * 32, 
							(CurSBlock % 16) * 32 + 31, 
							(CurSBlock / 16) * 32 + 31, 0xFFFFFF);
			Graphics->Square(514, 0, 563, 10, 0xFFFFFF);
			Graphics->Square(514, 10, 563, 36, 0xFFFFFF);
			Graphics->Square(563, 0, 614, 10, 0xFFFFFF);
			Graphics->Square(563, 10, 670, 140, 0xFFFFFF);
			Graphics->Unlock();
			Graphics->Update();

			// Reset picker zones
			Zones.AddZone((CurSBlock % 16) * 32, (CurSBlock / 16) * 32, 15, 15, 1, 260);
			Zones.AddZone((CurSBlock % 16) * 32 + 16, (CurSBlock / 16) * 32, 15, 15, 1, 261);
			Zones.AddZone((CurSBlock % 16) * 32, (CurSBlock / 16) * 32 + 16, 15, 15, 1, 262);
			Zones.AddZone((CurSBlock % 16) * 32 + 16, (CurSBlock / 16) * 32 + 16, 15, 15, 1, 263);
			
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_RIGHT) : {
						CurSBlock++;
						CurSBlock %= LevelInfo.NumSB;
						Update = true;
						break;
					}
					case(SDLK_LEFT) : {
						if (CurSBlock == 0x00) {
							CurSBlock = LevelInfo.NumSB;
						}
						CurSBlock--;
						Update = true;
						break;
					}
					case(SDLK_UP) : {
						if (CurSBlock < 0x10) {
							CurSBlock += LevelInfo.NumSB;
						}
						CurSBlock -= 0x10;
						Update = true;
						break;
					}
					case(SDLK_DOWN) : {
						CurSBlock += 0x10;
						CurSBlock %= LevelInfo.NumSB;
						Update = true;
						break;
					}
					case(SDLK_LEFTBRACKET) : {
						if (!CurUSBlock) {
							CurUSBlock = 3;
						} else {
							CurUSBlock--;
						}
						Update = true;
						break;
					}
					case(SDLK_RIGHTBRACKET) : {
						if (CurUSBlock == 3) {
							CurUSBlock = 0;
						} else {
							CurUSBlock++;
						}
						Update = true;
						break;
					}
					case(SDLK_EQUALS) : {
						Level.SetSBData(CurSBlock, CurUSBlock, Level.GetSBData(CurSBlock, CurUSBlock) + Delta);
						Update = true;
						break;
					}
					case(SDLK_MINUS) : {
						if (Level.GetSBData(CurSBlock, CurUSBlock) >= Delta) {
							Level.SetSBData(CurSBlock, CurUSBlock, Level.GetSBData(CurSBlock, CurUSBlock) - Delta);
						}
						Update = true;
						break;
					}
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: break;
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			case(SDL_MOUSEBUTTONDOWN) : {
				if ((event.button.button != SDL_BUTTON_WHEELUP) && (event.button.button != SDL_BUTTON_WHEELDOWN)) {
					int Temp = Zones.TestZone(event.button.x, event.button.y);
					if (Temp != -1) {
						if (Temp < 256) {
							CurSBlock = Temp;
						} else if (Temp < 260) {
							CurUSBlock = Temp - 256;
						} else {
							if ((CurUSBlock + 260) == Temp) {
								switch(event.button.button) {
									case(SDL_BUTTON_LEFT) : {
										if (Level.GetSBData(CurSBlock, CurUSBlock) >= Delta) {
											Level.SetSBData(CurSBlock, CurUSBlock, Level.GetSBData(CurSBlock, CurUSBlock) - Delta);
										}
										break;
									}
									case(SDL_BUTTON_RIGHT) : {
										Level.SetSBData(CurSBlock, CurUSBlock, Level.GetSBData(CurSBlock, CurUSBlock) + Delta);
										break;
									}
									default : break;
								}
							} else {
								CurUSBlock = Temp - 260;
							}
						}
						Update = true;
					}
				} else {	//	Wheel rolled
					if (event.button.button == SDL_BUTTON_WHEELUP) {
						Level.SetSBData(CurSBlock, CurUSBlock, Level.GetSBData(CurSBlock, CurUSBlock) + Delta);
					} else { // Wheel down
						if (Level.GetSBData(CurSBlock, CurUSBlock) >= Delta) {
							Level.SetSBData(CurSBlock, CurUSBlock, Level.GetSBData(CurSBlock, CurUSBlock) - Delta);
						}
					}
					Update = true;
				}	// if (not [wheel])
				break;
			}
			default: break;
		} // switch (event.type)
	} while (!Quit);
}

void BrowseBlocks(cLevel &Level, cGFX *Graphics)
{
	Uint8 CurBlock = 0;
	Uint8 CurSBlock = 0;
	Uint16 Delta = 1;
	bool Update = true, Quit = false;
	sLevelInfo LevelInfo = Level.GetLevelInfo();
	SDL_Event event;
	char Buffer[80];
	cZones Zones;
	int PrevZone = -1, CurPage = 0, Loop;

	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	Zones.SetNumZones(74);

	// Block Zones (0-63)
	for (Loop = 0; Loop < 64; Loop++)
	{
		Zones.AddZone((Loop % 8) * 64, (Loop / 8) * 64, 63, 63, 0);
	}

	// Page Zones (64-65)
	Zones.AddZone(128, 528, 31, 15, 0, 64);
	Zones.AddZone(384, 528, 31, 15, 0, 65);

	// Picker Zones (text) (66-69)
	Zones.AddZone(514, 12, 23, 7, 0, 66);
	Zones.AddZone(538, 12, 23, 7, 0, 67);
	Zones.AddZone(514, 28, 23, 7, 0, 68);
	Zones.AddZone(538, 28, 23, 7, 0, 69);


	do {
		if (Update) {
			if ((CurBlock / 64) != CurPage) {
				Graphics->Lock();
				Graphics->Clear();
				Graphics->Unlock();
			}
			CurPage = CurBlock / 64;
			for (Loop = 0; Loop < 64; Loop++) {
				if (CurPage * 64 + Loop < (int)LevelInfo.NumB) {
					Level.DisplayBlock((Loop % 8) * 64, (Loop / 8) * 64, CurPage * 64 + Loop); 
				}
			}
			Graphics->Lock();
			Graphics->Box(514, 12, 562, 35, 0);
			Level.DisplayBlockInfo(514, 12, CurBlock);
			Level.DisplaySBlockInfo(565, 12, Level.GetBData(CurBlock, CurSBlock));
			sprintf(Buffer, "B %02X", CurBlock);
			Graphics->DisplayText(514, 2, Buffer);
			sprintf(Buffer, "S %02X", Level.GetBData(CurBlock, CurSBlock));
			Graphics->DisplayText(565, 2, Buffer);
			Graphics->DisplayText((CurSBlock % 2) ? 554 : 530, (CurSBlock / 2) ? 28 : 12, "!");
			Graphics->DisplayText(128, 528, "PREV");
			Graphics->DisplayText(128, 536, "PAGE");
			Graphics->DisplayText(384, 528, "NEXT");
			Graphics->DisplayText(384, 536, "PAGE");
			Graphics->Square((CurBlock % 8) * 64 + ((CurSBlock % 2) ? 32 : 0), 
								((CurBlock % 64) / 8) * 64 + ((CurSBlock / 2) ? 32 : 0), 
								(CurBlock % 8) * 64 + ((CurSBlock % 2) ? 63 : 31), 
								((CurBlock % 64) / 8) * 64 + ((CurSBlock / 2) ? 63 : 31), 0x7F7F7F);
			Graphics->Square((CurBlock % 8) * 64, ((CurBlock % 64) / 8) * 64, (CurBlock % 8) * 64 + 63, ((CurBlock % 64) / 8) * 64 + 63, 0xFFFFFF);
			Graphics->Square(512, 0, 563, 10, 0xFFFFFF);
			Graphics->Square(512, 10, 563, 36, 0xFFFFFF);
			Graphics->Square(563, 0, 614, 10, 0xFFFFFF);
			Graphics->Square(563, 10, 614, 36, 0xFFFFFF);
			Graphics->Unlock();
			Graphics->Update();
			// Redo Picker Zones (graphics) (70-73)
			Zones.AddZone((CurBlock % 8) * 64, ((CurBlock % 64) / 8) * 64, 31, 31, 1, 70);
			Zones.AddZone((CurBlock % 8) * 64 + 32, ((CurBlock % 64) / 8) * 64, 31, 31, 1, 71);
			Zones.AddZone((CurBlock % 8) * 64, ((CurBlock % 64) / 8) * 64 + 32, 31, 31, 1, 72);
			Zones.AddZone((CurBlock % 8) * 64 + 32, ((CurBlock % 64) / 8) * 64 + 32, 31, 31, 1, 73);
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_RIGHT) : {
						if (Delta == 0x01) {
							CurBlock++;
							if (CurBlock >= LevelInfo.NumB) {
								CurBlock = LevelInfo.NumB - 1;
							}
						} else {
							CurBlock += 0x40;
							if (CurBlock >= LevelInfo.NumB) {
								CurBlock = LevelInfo.NumB - 1;
							}
						}
						Update = true;
						break;
					}
					case(SDLK_LEFT) : {
						if (Delta == 0x01) {
							CurBlock--;
							if (CurBlock >= LevelInfo.NumB) {
								CurBlock = LevelInfo.NumB - 1;
							}
						} else {
							CurBlock -= 0x40;
							if (CurBlock >= LevelInfo.NumB) {
								CurBlock = LevelInfo.NumB - 1;
							}
						}
						Update = true;
						break;
					}
					case(SDLK_UP) : {
						CurBlock -= 0x08;
						if (CurBlock >= LevelInfo.NumB) {
							CurBlock = LevelInfo.NumB - 1;
						}
						Update = true;
						break;
					}
					case(SDLK_DOWN) : {
						CurBlock += 0x08;
						if (CurBlock >= LevelInfo.NumB) {
							CurBlock -= LevelInfo.NumB;
						}
						Update = true;
						break;
					}
					case(SDLK_LEFTBRACKET) : {
						if (!CurSBlock) {
							CurSBlock = 3;
						} else {
							CurSBlock--;
						}
						Update = true;
						break;
					}
					case(SDLK_RIGHTBRACKET) : {
						if (CurSBlock == 3) {
							CurSBlock = 0;
						} else {
							CurSBlock++;
						}
						Update = true;
						break;
					}
					case(SDLK_EQUALS) : {
						Level.SetBData(CurBlock, CurSBlock, Level.GetBData(CurBlock, CurSBlock) + Delta);
						Update = true;
						break;
					}
					case(SDLK_MINUS) : {
						if (Level.GetBData(CurBlock, CurSBlock) >= Delta) {
							Level.SetBData(CurBlock, CurSBlock, Level.GetBData(CurBlock, CurSBlock) - Delta);
						}
						Update = true;
						break;
					}
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case (SDLK_ESCAPE):
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: break;
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			case(SDL_MOUSEBUTTONDOWN) : {
				if ((event.button.button != SDL_BUTTON_WHEELUP) && (event.button.button != SDL_BUTTON_WHEELDOWN)) {
					int Temp = Zones.TestZone(event.button.x, event.button.y);
					if (Temp == -1) {
					} else if (Temp < 64) {			// Block Click
						if (Temp + CurPage * 64 < (int)LevelInfo.NumB) {
							CurBlock = Temp + CurPage * 64;
							Update = true;
						}
					} else if (Temp == 64) {		// Page Left Click
						CurBlock -= 64;
						if (CurBlock >= LevelInfo.NumB) {
							CurBlock = LevelInfo.NumB - 1;
						}
						Update = true;
					} else if (Temp == 65) {		// Page Right Click
						CurBlock += 64;
						if (CurBlock >= LevelInfo.NumB) {
							CurBlock = LevelInfo.NumB - 1;
						}
						Update = true;
					} else {						// Picker Zone
						if (Temp > 69) {			// Graphics Picker Zone
							Temp -= 4;				// Map to Text Picker
						}
						if (PrevZone == Temp) {
							switch(event.button.button) {
								case(SDL_BUTTON_LEFT) : {
									Level.SetBData(CurBlock, CurSBlock, Level.GetBData(CurBlock, CurSBlock) + Delta);
									Update = true;
									break;
								}
								case(SDL_BUTTON_RIGHT) : {
									if (Level.GetBData(CurBlock, CurSBlock) >= Delta) {
										Level.SetBData(CurBlock, CurSBlock, Level.GetBData(CurBlock, CurSBlock) - Delta);
									}
									Update = true;
									break;
								}
								default : break;
							}
						} else {
							CurSBlock = Temp - 66;
							Update = true;
						}
					}
					PrevZone = Temp;
				} else {	//	Wheel rolled
					if (event.button.button == SDL_BUTTON_WHEELUP) {
						Level.SetBData(CurBlock, CurSBlock, Level.GetBData(CurBlock, CurSBlock) + Delta);
					} else { // Wheel down
						if (Level.GetSBData(CurBlock, CurSBlock) >= Delta) {
							Level.SetBData(CurBlock, CurSBlock, Level.GetBData(CurBlock, CurSBlock) - Delta);
						}
					}
					Update = true;
				}	// if (not [wheel])
				break;
			}
			default: break;
		} // switch (event.type)
	} while (!Quit);
}

void BrowseMap(cLevel &Level, cGFX *Graphics)
{
	Uint8 x = 0, y = 0, rx = 0, ry = 0, CurRoom = 0;
	Uint16 Delta = 1;
	bool Update = true, Quit = false, Things = true, Gateways = true, Misc = true;
	sLevelInfo LevelInfo = Level.GetLevelInfo();
	sMiscInfo MiscInfo = Level.GetMiscInfo();
	SDL_Event event;
	char Buffer[80];
	cZones Zones;
	int PrevZone = -1;

	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	Zones.SetNumZones(37);

	// Set Block Zones (0-24)
	for (int Loop = 0; Loop < 25; Loop++) {
		Zones.AddZone((Loop % 5) * 64, (Loop / 5) * 64, 63, 63, 0);
	}

	// Set Scroll Table Zones (25-28)
	Zones.AddZone(324, 92, 55, 7, 0);		
	Zones.AddZone(324, 100, 55, 7, 0);
	Zones.AddZone(324, 108, 55, 7, 0);
	Zones.AddZone(324, 116, 55, 7, 0);

	// Set Borders (29-32)
	Zones.AddZone(0, 0, 319, 15, 1);
	Zones.AddZone(0, 304, 319, 15, 1);
	Zones.AddZone(0, 0, 15, 319, 1);
	Zones.AddZone(304, 0, 15, 319, 1);

	// Set Corners (33-36)
	Zones.AddZone(0, 0, 15, 15, 2);
	Zones.AddZone(0, 304, 15, 15, 2);
	Zones.AddZone(304, 0, 15, 15, 2);
	Zones.AddZone(304, 304, 15, 15, 2);

	do {
		if (Update) {
			CurRoom = y * 8 + x;
			Level.DisplayRoomPlus(0, 0, CurRoom);
			Graphics->Lock();
			Graphics->Box(322, 0, 520, 330, 0);
			Level.DisplayRoomInfo(324, 12, CurRoom);
			Level.DisplayBlockInfo(448, 12, Level.GetMapData(CurRoom, rx, ry));
			sprintf(Buffer, "R %02X X%d Y%d", CurRoom, x, y);
			Graphics->DisplayText(324, 2, Buffer);
			sprintf(Buffer, "B %02X X%d Y%d", Level.GetMapData(CurRoom, rx, ry), rx, ry);
			Graphics->DisplayText(448, 2, Buffer);
			Graphics->Square(rx * 64, ry * 64, rx * 64 + 63, ry * 64 + 63, 0xFFFFFF);
			Graphics->Square(322, 10, 436, 124, 0xFFFFFF);
			Graphics->Square(322, 0, 404, 10, 0xFFFFFF);
			Graphics->Square(446, 10, 488, 36, 0xFFFFFF);
			Graphics->Square(446, 0, 528, 10, 0xFFFFFF);
			if (Things) {
				Level.DisplayThings(x, y);
			}
			if (Gateways) {
				Level.DisplayGateways(x, y);
			}
			if (Misc) {
				if (LevelInfo.isOverhead) {
					if ((((MiscInfo.BossPoints[LevelInfo.LevelNum * 2 - 2] & 0xF0) >> 4) == x) && (((MiscInfo.BossPoints[LevelInfo.LevelNum * 2 - 1] & 0xF0) >> 4) == y)) {
						Graphics->DisplayText((MiscInfo.BossPoints[LevelInfo.LevelNum * 2 - 2] & 0x0F) * 16, (MiscInfo.BossPoints[LevelInfo.LevelNum * 2 - 1] & 0x0F) * 16, "B", 0xFF0000);
					}
				} else {
					if ((((MiscInfo.StartPoints[LevelInfo.LevelNum * 2 - 2] & 0xF0) >> 4) == x) && (((MiscInfo.StartPoints[LevelInfo.LevelNum * 2 - 1] & 0xF0) >> 4) == y)) {
						Graphics->DisplayText((MiscInfo.StartPoints[LevelInfo.LevelNum * 2 - 2] & 0x0F) * 16, (MiscInfo.StartPoints[LevelInfo.LevelNum * 2 - 1] & 0x0F) * 16, "S", 0xFF0000);
					}
				}
			}
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_RIGHT) : {
						if (Delta > 1) {
							if (x < 7) {
								x++;
							} else {
								x = 0;
							}
							Update = true;
						} else if (rx < 4) {
							rx++;
							Update = true;
						}
						break;
					}
					case(SDLK_LEFT) : {
						if (Delta > 1) {
							if (x > 0) {
								x--;
							} else {
								x = 7;
							}
							Update = true;
						} else if (rx > 0) {
							rx--;
							Update = true;
						}
						break;
					}
					case(SDLK_DOWN) : {
						if (Delta > 1) {
							if (y < 7) {
								y++;
							} else {
								y = 0;
							}
							Update = true;
						} else if (ry < 4) {
							ry++;
							Update = true;
						}
						break;
					}
					case(SDLK_UP) : {
						if (Delta > 1) {
							if (y > 0) {
								y--;
							} else {
								y = 7;
							}
							Update = true;
						} else if (ry > 0) {
							ry--;
							Update = true;
						}
						break;
					}
					case(SDLK_EQUALS) : {
						Level.SetMapData(CurRoom, rx, ry, Level.GetMapData(CurRoom, rx, ry) + Delta);
						Update = true;
						break;
					}
					case(SDLK_MINUS) : {
						if (Level.GetMapData(CurRoom, rx, ry) >= Delta) {
							Level.SetMapData(CurRoom, rx, ry, Level.GetMapData(CurRoom, rx, ry) - Delta);
						}
						Update = true;
						break;
					}
					case(SDLK_t) : {
						Things = !Things;
						Update = true;
						break;
					}
					case(SDLK_g) : {
						Gateways = !Gateways;
						Update = true;
						break;
					}
					case(SDLK_m) : {
						Misc = !Misc;
						Update = true;
						break;
					}
					case(SDLK_1) : {
						Level.ToggleScrollBit(CurRoom, DIR_UP);
						Update = true;
						break;
					}
					case(SDLK_2) : {
						Level.ToggleScrollBit(CurRoom, DIR_LEFT);
						Update = true;
						break;
					}
					case(SDLK_3) : {
						Level.ToggleScrollBit(CurRoom, DIR_DOWN);
						Update = true;
						break;
					}
					case(SDLK_4) : {
						Level.ToggleScrollBit(CurRoom, DIR_RIGHT);
						Update = true;
						break;
					}
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: {
						break;
					}
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			case(SDL_MOUSEBUTTONDOWN) : {
				if ((event.button.button != SDL_BUTTON_WHEELUP) && (event.button.button != SDL_BUTTON_WHEELDOWN)) {
					int Temp = Zones.TestZone(event.button.x, event.button.y);
					if ((PrevZone == Temp) && (Temp < 25)) {			// Reclick on same Map spot
						switch(event.button.button) {
							case(SDL_BUTTON_LEFT) : {
								if (Level.GetMapData(CurRoom, rx, ry) >= Delta) {
									Level.SetMapData(CurRoom, rx, ry, Level.GetMapData(CurRoom, rx, ry) - Delta);
								}
								Update = true;
								break;
							}
							case(SDL_BUTTON_RIGHT) : {
								Level.SetMapData(CurRoom, rx, ry, Level.GetMapData(CurRoom, rx, ry) + Delta);
								Update = true;
								break;
							}
							default : break;
						}
					} else if (Temp < 25) {		// Map Click
						rx = Temp % 5;
						ry = Temp / 5;
						Update = true;
					} else if (Temp < 29) {		// Scroll Click
						switch(Temp) {
							case(25) : {
								Level.ToggleScrollBit(CurRoom, DIR_UP);
								Update = true;
								break;
							}
							case(26) : {
								Level.ToggleScrollBit(CurRoom, DIR_LEFT);
								Update = true;
								break;
							}
							case(27) : {
								Level.ToggleScrollBit(CurRoom, DIR_DOWN);
								Update = true;
								break;
							}
							case(28) : {
								Level.ToggleScrollBit(CurRoom, DIR_RIGHT);
								Update = true;
								break;
							}
						}
					} else if (Temp < 33) {		// Border Click
						switch(Temp) {
							case(29) : {
								--y %= 0x08;
								break;
							}
							case(30) : {
								++y %= 0x08;
								break;
							}
							case(31) : {
								--x %= 0x08;
								break;
							}
							case(32) : {
								++x %= 0x08;
								break;
							}
						}
						Update = true;
					} else {					// Corner Click
						switch(Temp) {
							case(33) : {
								--y %= 0x08;
								--x %= 0x08;
								break;
							}
							case(34) : {
								++y %= 0x08;
								--x %= 0x08;
								break;
							}
							case(35) : {
								--y %= 0x08;
								++x %= 0x08;
								break;
							}
							case(36) : {
								++y %= 0x08;
								++x %= 0x08;
								break;
							}
							}
						Update = true;
					} // Zone Test
					PrevZone = Temp;
				} else {	//	Wheel rolled
					if (event.button.button == SDL_BUTTON_WHEELUP) {
						Level.SetMapData(CurRoom, rx, ry, Level.GetMapData(CurRoom, rx, ry) + Delta);
					} else { // Wheel down
						if (Level.GetMapData(CurRoom, rx, ry) >= Delta) {
							Level.SetMapData(CurRoom, rx, ry, Level.GetMapData(CurRoom, rx, ry) - Delta);
						}
					}
					Update = true;
				}	// if (not [wheel])
				break;
			} // case(SDL_MOUSEBUTTONDOWN)
			default: break;
		} // switch (event.type)
	} while (!Quit);
}

void BrowseThings(cLevel &Level, cGFX *Graphics)
{
	Uint8 x = 0, y = 0, CurRoom = 0, CurThing = 0;
	Uint16 Delta = 1;
	bool Update = true, Quit = false, LockMouse = false;
	sLevelInfo LevelInfo = Level.GetLevelInfo();
	sThingInfo ThingInfo = Level.GetThingInfo();
	SDL_Event event;
	char Buffer[80];

	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			y = (ThingInfo.YPos[CurThing] & 0xF0) >> 4;
			x = (ThingInfo.XPos[CurThing] & 0xF0) >> 4;
			CurRoom = y * 8 + x;
			Level.DisplayRoomPlus(0, 0, CurRoom);
			Graphics->Lock();
			Graphics->Box(322, 74, 520, 330, 0);
			Level.DisplayThings(x, y);
			sprintf(Buffer, "%02X", CurThing);
			Graphics->DisplayText((ThingInfo.XPos[CurThing] & 0x0F) * 16, (ThingInfo.YPos[CurThing] & 0x0F) * 16, Buffer, 0xFFFF00);
			sprintf(Buffer, "%02X", ThingInfo.Type[CurThing]);
			Graphics->DisplayText((ThingInfo.XPos[CurThing] & 0x0F) * 16, (ThingInfo.YPos[CurThing] & 0x0F) * 16 + 8, Buffer, 0xFFFF00);
			sprintf(Buffer, "%02X %02X %02X %02X", CurThing, ThingInfo.Type[CurThing], ThingInfo.XPos[CurThing], ThingInfo.YPos[CurThing]);
			Graphics->DisplayText(322, 74, "   T  X  Y");
			Graphics->DisplayText(322, 82, Buffer, 0xFFFF00);
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		if (LockMouse) {
			SDL_WM_GrabInput(SDL_GRAB_ON);
			SDL_ShowCursor(SDL_DISABLE);
			SDL_SetEventFilter(DropExtraMouseEvents);
		} else {
			SDL_WM_GrabInput(SDL_GRAB_OFF);
			SDL_ShowCursor(SDL_ENABLE);
			SDL_SetEventFilter(NULL);
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_RIGHT) : {
						ThingInfo.XPos[CurThing] += Delta;
						ThingInfo.XPos[CurThing] %= 0x80;
						Level.SetThingData(CurThing, ThingInfo.XPos[CurThing], ThingInfo.YPos[CurThing], ThingInfo.Type[CurThing]);
						Update = true;
						break;
					}
					case(SDLK_LEFT) : {
						if (ThingInfo.XPos[CurThing] < Delta) {
							ThingInfo.XPos[CurThing] += 0x80;
						}
						ThingInfo.XPos[CurThing] -= Delta;
						Level.SetThingData(CurThing, ThingInfo.XPos[CurThing], ThingInfo.YPos[CurThing], ThingInfo.Type[CurThing]);
						Update = true;
						break;
					}
					case(SDLK_DOWN) : {
						ThingInfo.YPos[CurThing] += Delta;
						ThingInfo.YPos[CurThing] %= 0x80;
						Level.SetThingData(CurThing, ThingInfo.XPos[CurThing], ThingInfo.YPos[CurThing], ThingInfo.Type[CurThing]);
						Update = true;
						break;
					}
					case(SDLK_UP) : {
						if (ThingInfo.YPos[CurThing] < Delta) {
							ThingInfo.YPos[CurThing] += 0x80;
						}
						ThingInfo.YPos[CurThing] -= Delta;
						Level.SetThingData(CurThing, ThingInfo.XPos[CurThing], ThingInfo.YPos[CurThing], ThingInfo.Type[CurThing]);
						Update = true;
						break;
					}
					case(SDLK_EQUALS) : {
						ThingInfo.Type[CurThing] += Delta;
						Level.SetThingData(CurThing, ThingInfo.XPos[CurThing], ThingInfo.YPos[CurThing], ThingInfo.Type[CurThing]);
						Update = true;
						break;
					}
					case(SDLK_MINUS) : {
						ThingInfo.Type[CurThing] -= Delta;
						Level.SetThingData(CurThing, ThingInfo.XPos[CurThing], ThingInfo.YPos[CurThing], ThingInfo.Type[CurThing]);
						Update = true;
						break;
					}
					case(SDLK_LEFTBRACKET) : {
						if (CurThing < Delta) {
							CurThing += LevelInfo.NumThing;
						}
						CurThing -= Delta;
						Update = true;
						break;
					}
					case(SDLK_RIGHTBRACKET) : {
						CurThing += Delta;
						CurThing %= LevelInfo.NumThing;
						Update = true;
						break;
					}
					case(SDLK_r) : {
						ThingInfo.Type[CurThing] = 0x1F;
						ThingInfo.XPos[CurThing] = ThingInfo.YPos[CurThing] = 0;
						Level.SetThingData(CurThing, ThingInfo.XPos[CurThing], ThingInfo.YPos[CurThing], ThingInfo.Type[CurThing]);
						Update = true;
						break;
					}
					case(SDLK_m) : {
						LockMouse = !LockMouse;
						break;
					}
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: {
						break;
					}
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			case (SDL_MOUSEMOTION) : {
				if (!LockMouse) {
					break;
				}
				(ThingInfo.XPos[CurThing] += (event.motion.xrel / 4)) %= 0x80;
				(ThingInfo.YPos[CurThing] += (event.motion.yrel / 4)) %= 0x80;
				Level.SetThingData(CurThing, ThingInfo.XPos[CurThing], ThingInfo.YPos[CurThing], ThingInfo.Type[CurThing]);
				
				if ((event.motion.xrel / 4) || (event.motion.yrel / 4)) {
					Update = true;
				}
				break;
			}
			case (SDL_MOUSEBUTTONDOWN) : {
				if (!LockMouse) {
					break;
				}
				switch(event.button.button) {
					case(SDL_BUTTON_LEFT) : {
						ThingInfo.Type[CurThing] -= Delta;
						break;
					}
					case(SDL_BUTTON_RIGHT) : {
						ThingInfo.Type[CurThing] += Delta;
						break;
					}
					case(SDL_BUTTON_WHEELDOWN) : {
						if (CurThing) {
							CurThing--;
						} else {
							CurThing = LevelInfo.NumThing - 1;
						}
						break;
					}
					case(SDL_BUTTON_WHEELUP) : {
						if (CurThing < LevelInfo.NumThing) {
							CurThing++;
						} else {
							CurThing = 0;
						}
						break;
					}
					default : break;
				}
				Level.SetThingData(CurThing, ThingInfo.XPos[CurThing], ThingInfo.YPos[CurThing], ThingInfo.Type[CurThing]);
				Update = true;
				break;
			}				
			default: break;
		} // switch (event.type)
	} while (!Quit);
	if (LockMouse) {
		SDL_WM_GrabInput(SDL_GRAB_OFF);
		SDL_ShowCursor(SDL_ENABLE);
		SDL_SetEventFilter(NULL);
	}
}

void BrowseGateways(cLevel &Level, cGFX *Graphics)
{
	Uint8 x = 0, y = 0, CurRoom = 0, CurGateway = 0;
	Uint16 Delta = 1;
	bool Update = true, Quit = false, LockMouse = false;
	sLevelInfo LevelInfo = Level.GetLevelInfo();
	sGatewayInfo GatewayInfo = Level.GetGatewayInfo();
	SDL_Event event;
	char Buffer[80];
	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			if (GatewayInfo.Level[CurGateway] == (LevelInfo.LevelNum - 1 + 8 * !LevelInfo.isOverhead)) {
				y = (GatewayInfo.Y[CurGateway] & 0xF0) >> 4;
				x = (GatewayInfo.X[CurGateway] & 0xF0) >> 4;
				CurRoom = y * 8 + x;
			}
			Level.DisplayRoomPlus(0, 0, CurRoom);
			Graphics->Lock();
			Graphics->Box(322, 132, 410, 164, 0);
			if (GatewayInfo.Level[CurGateway] == (LevelInfo.LevelNum - 1 + 8 * !LevelInfo.isOverhead)) {
				Level.DisplayGateways(x, y);
			}
			Graphics->DisplayText(322, 132, "G  L  X  Y", 0xFFFF00);
			sprintf(Buffer, "%02X %02X %02X %02X", CurGateway, GatewayInfo.Level[CurGateway], GatewayInfo.X[CurGateway], GatewayInfo.Y[CurGateway]);
			Graphics->DisplayText(322, 140, Buffer, 0xFFFF00);
			Graphics->DisplayText(338, 148, "G  L  X  Y", 0x00FFFF);
			sprintf(Buffer, "%02X %02X %02X %02X", CurGateway ^ 0x01, GatewayInfo.Level[CurGateway ^ 0x01], GatewayInfo.X[CurGateway ^ 0x01], GatewayInfo.Y[CurGateway ^ 0x01]);
			Graphics->DisplayText(338, 156, Buffer, 0x00FFFF);
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		if (LockMouse) {
			SDL_WM_GrabInput(SDL_GRAB_ON);
			SDL_ShowCursor(SDL_DISABLE);
			SDL_SetEventFilter(DropExtraMouseEvents);
		} else {
			SDL_WM_GrabInput(SDL_GRAB_OFF);
			SDL_ShowCursor(SDL_ENABLE);
			SDL_SetEventFilter(NULL);
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_RIGHT) : {
						GatewayInfo.X[CurGateway] += Delta;
						GatewayInfo.X[CurGateway] %= 0x80;
						Level.SetGatewayData(CurGateway, GatewayInfo.X[CurGateway], GatewayInfo.Y[CurGateway], GatewayInfo.Level[CurGateway]);
						Update = true;
						break;
					}
					case(SDLK_LEFT) : {
						GatewayInfo.X[CurGateway] -= Delta;
						GatewayInfo.X[CurGateway] %= 0x80;
						Level.SetGatewayData(CurGateway, GatewayInfo.X[CurGateway], GatewayInfo.Y[CurGateway], GatewayInfo.Level[CurGateway]);
						Update = true;
						break;
					}
					case(SDLK_DOWN) : {
						GatewayInfo.Y[CurGateway] += Delta;
						GatewayInfo.Y[CurGateway] %= 0x80;
						Level.SetGatewayData(CurGateway, GatewayInfo.X[CurGateway], GatewayInfo.Y[CurGateway], GatewayInfo.Level[CurGateway]);
						Update = true;
						break;
					}
					case(SDLK_UP) : {
						GatewayInfo.Y[CurGateway] -= Delta;
						GatewayInfo.Y[CurGateway] %= 0x80;
						Level.SetGatewayData(CurGateway, GatewayInfo.X[CurGateway], GatewayInfo.Y[CurGateway], GatewayInfo.Level[CurGateway]);
						Update = true;
						break;
					}
					case(SDLK_EQUALS) : {
						GatewayInfo.Level[CurGateway]++;
						GatewayInfo.Level[CurGateway] %= 0x10;
						Level.SetGatewayData(CurGateway, GatewayInfo.X[CurGateway], GatewayInfo.Y[CurGateway], GatewayInfo.Level[CurGateway]);
						Update = true;
						break;
					}
					case(SDLK_MINUS) : {
						GatewayInfo.Level[CurGateway]--;
						GatewayInfo.Level[CurGateway] %= 0x10;
						Level.SetGatewayData(CurGateway, GatewayInfo.X[CurGateway], GatewayInfo.Y[CurGateway], GatewayInfo.Level[CurGateway]);
						Update = true;
						break;
					}
					case(SDLK_LEFTBRACKET) : {
						CurGateway -= Delta;
						CurGateway %= NUM_GATES;
						Update = true;
						break;
					}
					case(SDLK_RIGHTBRACKET) : {
						CurGateway += Delta;
						CurGateway %= NUM_GATES;
						Update = true;
						break;
					}
					case(SDLK_m) : {
						LockMouse = !LockMouse;
						break;
					}
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: {
						break;
					}
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			case (SDL_MOUSEMOTION) : {
				if (!LockMouse) {
					break;
				}
				(GatewayInfo.X[CurGateway] += (event.motion.xrel / 4)) %= 0x80;
				(GatewayInfo.Y[CurGateway] += (event.motion.yrel / 4)) %= 0x80;
				Level.SetGatewayData(CurGateway, GatewayInfo.X[CurGateway], GatewayInfo.Y[CurGateway], GatewayInfo.Level[CurGateway]);
				
				if ((event.motion.xrel / 4) || (event.motion.yrel / 4)) {
					Update = true;
				}
				break;
			}
			case (SDL_MOUSEBUTTONDOWN) : {
				if (!LockMouse) {
					break;
				}
				switch(event.button.button) {
					case(SDL_BUTTON_LEFT) : {
						GatewayInfo.Level[CurGateway]--;
						break;
					}
					case(SDL_BUTTON_RIGHT) : {
						GatewayInfo.Level[CurGateway]++;
						break;
					}
					case(SDL_BUTTON_WHEELDOWN) : {
						CurGateway--;
						CurGateway %= NUM_GATES;
						break;
					}
					case(SDL_BUTTON_WHEELUP) : {
						CurGateway++;
						CurGateway %= NUM_GATES;
						break;
					}
					default : break;
				}
				GatewayInfo.Level[CurGateway] %= 0x10;
				Level.SetGatewayData(CurGateway, GatewayInfo.X[CurGateway], GatewayInfo.Y[CurGateway], GatewayInfo.Level[CurGateway]);
				Update = true;
				break;
			}				
			default: break;
		} // switch (event.type)
	} while (!Quit);
	if (LockMouse) {
		SDL_WM_GrabInput(SDL_GRAB_OFF);
		SDL_ShowCursor(SDL_ENABLE);
		SDL_SetEventFilter(NULL);
	}
}	

void BrowseGlobal(cLevel &Level, cGFX *Graphics)
{
	GSTATE state = GSTATE_NONE;
	SDL_Event event;
	sMiscInfo MiscInfo = Level.GetMiscInfo();
	char Buffer[80];
	cZones Zones;
	int PrevZone = -1, Loop;
	bool Draw = true;
	const int NUM_COMMANDS = 13;
	const char *COMMANDS[] = {	"G  EDIT GATEWAYS",
							"B  EDIT START OR BOSS POINT",
							"3  EDIT BOSS 3 PATTERN",
							"4  EDIT BOSS 4 PATTERN",
							"7  EDIT BOSS 7 PATTERN",
							"M  EDIT MISC DATA",
							"A  EDIT GATEA STRUCTURE",
							"Z  EDIT GATEB STRUCTURE",
							"E  EDIT ENEMY STATS",
							"T  TOGGLE LEVEL SELECT",
							"R  RESET CHANGES",
							"S  SAVE CHANGES TO MEMORY",
							"ESC QUIT" };

	Zones.SetNumZones(NUM_COMMANDS);

	for (Loop = 0; Loop < NUM_COMMANDS; Loop++) {
		Zones.AddZone(0, Loop * 8, strlen(COMMANDS[Loop]) * 8 - 1, 7, 0);
	}

	do {
		switch(state) {
			case(GSTATE_NONE) : {
				if (Draw) {
					Graphics->Lock();
					Graphics->Clear();

					for(Loop = 0; Loop < NUM_COMMANDS; Loop++) {
						Graphics->DisplayText(0, Loop * 8, COMMANDS[Loop]);
					}

					sprintf(Buffer, "CURRENT LEVEL %d %c", Level.GetLevelInfo().LevelNum, Level.GetLevelInfo().isOverhead ? 'O' : 'T');

					Graphics->DisplayText(0, NUM_COMMANDS * 8 + 16, Buffer);

					Graphics->DisplayText(192, 72, (MiscInfo.LevelSelect) ? "ON" : "OFF");

					Graphics->Unlock();
					Graphics->Update();

					Draw = false;
				}

		 		SDL_WaitEvent(&event);

				switch (event.type) {
					case (SDL_QUIT) : {
						state = GSTATE_QUIT;
						break;
					} 
					case (SDL_KEYDOWN) : {
						switch (event.key.keysym.sym) {
							case (SDLK_ESCAPE): {
								state = GSTATE_QUIT;
								break;
							}
							case (SDLK_s): {
								state = GSTATE_SAVE;
								break;
							}
							case (SDLK_r): {
								state = GSTATE_RESET;
								break;
							}
							case (SDLK_g): {
								state = GSTATE_GATEWAYS;
								break;
							}
							case (SDLK_b): {
								state = GSTATE_START;
								break;
							}
							case (SDLK_3): {
								state = GSTATE_BOSS3;
								break;
							}
							case (SDLK_4): {
								state = GSTATE_BOSS4;
								break;
							}
							case (SDLK_7): {
								state = GSTATE_BOSS7;
								break;
							}
							case (SDLK_m): {
								state = GSTATE_MISC;
								break;
							}
							case (SDLK_a): {
								state = GSTATE_GATEA;
								break;
							}
							case (SDLK_z): {
								state = GSTATE_GATEB;
								break;
							}
							case (SDLK_t): {
								state = GSTATE_TOGGLE;
								break;
							}
							case (SDLK_e): {
								state = GSTATE_ENEMY;
								break;
							}
							case (SDLK_RETURN) : {
								if (event.key.keysym.mod && KMOD_ALT) {
									Graphics->ToggleFullScreen();
									Draw = true;
								}
								break;
							}
							default: break;
						}	// switch (event.key.keysym.sym)
						break;
					} // case (SDL_KEYDOWN)
					case (SDL_MOUSEBUTTONDOWN) : {
						if (event.button.button == SDL_BUTTON_LEFT) {
							switch(Zones.TestZone(event.button.x, event.button.y)) {
								case (0): {
									state = GSTATE_GATEWAYS;
									break;
								}
								case (1): {
									state = GSTATE_START;
									break;
								}
								case (2): {
									state = GSTATE_BOSS3;
									break;
								}
								case (3): {
									state = GSTATE_BOSS4;
									break;
								}
								case (4): {
									state = GSTATE_BOSS7;
									break;
								}
								case (5): {
									state = GSTATE_MISC;
									break;
								}
								case (6): {
									state = GSTATE_GATEA;
									break;
								}
								case (7): {
									state = GSTATE_GATEB;
									break;
								}
								case (8): {
									state = GSTATE_ENEMY;
									break;
								}
								case (9): {
									state = GSTATE_TOGGLE;
									break;
								}
								case (10): {
									state = GSTATE_RESET;
									break;
								}
								case (11): {
									state = GSTATE_SAVE;
									break;
								}
								case (12): {
									state = GSTATE_QUIT;
									break;
								}
								default: break;
							} // switch(Zones.TestZone())
						} // if (SDL_BUTTON_LEFT)
						break;
					} // case (SDL_MOUSEBUTTONDOWN)
					case (SDL_MOUSEMOTION) : {
						int Temp = Zones.TestZone(event.motion.x, event.motion.y);
						if (PrevZone != Temp) {
							Graphics->Lock();
							if (PrevZone != -1) {
								Graphics->DisplayText(0, PrevZone * 8, COMMANDS[PrevZone]);
							}
							if (Temp != -1) {
								Graphics->DisplayText(0, Temp * 8, COMMANDS[Temp], 0xFFFF00);
							}
							PrevZone = Temp;
							Graphics->Unlock();
							Graphics->Update();
						}
						break;
					} // case (SDL_MOUSEMOTION)
					default : break;		
				}	// switch (event.type) 
				break;
			}	// case (GSTATE_NONE):
			case (GSTATE_GATEWAYS) : {
				BrowseGateways(Level, Graphics);
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_RESET) : {
				MiscInfo = Level.GetMiscInfo();
				ERR("Reloaded Misc Info From Memory\n");
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_SAVE) : {
				Level.SetMiscInfo(MiscInfo);
				ERR("Saved Misc Info To Memory\n");
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_START) : {
				BrowseStart(Level, Graphics, MiscInfo);
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_BOSS3) : {
				BrowseBoss3(MiscInfo, Graphics);
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_BOSS4) : {
				BrowseBoss4(MiscInfo, Graphics);
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_BOSS7) : {
				BrowseBoss7(MiscInfo, Graphics);
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_MISC) : {
				BrowseMisc(MiscInfo, Graphics);
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_GATEA) : {
				BrowseGateA(MiscInfo, Graphics);
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_GATEB) : {
				BrowseGateB(MiscInfo, Graphics);
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_TOGGLE) : {
				MiscInfo.LevelSelect = !(MiscInfo.LevelSelect);
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			case (GSTATE_ENEMY) : {
				BrowseEnemyStats(MiscInfo, Graphics);
				state = GSTATE_NONE;
				Draw = true;
				break;
			}
			default: {
				state = GSTATE_QUIT;
				break;
			}
		}	// switch(state)
	} while ( state != GSTATE_QUIT );
}

void BrowseStart(cLevel &Level, cGFX *Graphics, sMiscInfo &MiscInfo)
{
	Uint8 x = 0, y = 0, CurRoom = 0, CurPoint;
	Uint16 Delta = 1;
	bool Update = true, Quit = false, LockMouse = false;
	sLevelInfo LevelInfo = Level.GetLevelInfo();
	SDL_Event event;
	char Buffer[80];
	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	CurPoint = (LevelInfo.LevelNum - 1) * 2;

	do {
		if (Update) {
			x = (LevelInfo.isOverhead ? (MiscInfo.BossPoints[CurPoint]) : (MiscInfo.StartPoints[CurPoint]) & 0xF0) >> 4;
			y = (LevelInfo.isOverhead ? (MiscInfo.BossPoints[CurPoint + 1]) : (MiscInfo.StartPoints[CurPoint + 1]) & 0xF0) >> 4;
			CurRoom = y * 8 + x;
			Level.DisplayRoomPlus(0, 0, CurRoom);
			Graphics->Lock();
			Graphics->Box(336, 132, 400, 148, 0);
			if (LevelInfo.isOverhead) {
				Graphics->DisplayText((MiscInfo.BossPoints[CurPoint] & 0x0F) * 16, (MiscInfo.BossPoints[CurPoint + 1] & 0x0F) * 16, "B", 0xFF0000);
			} else {
				Graphics->DisplayText((MiscInfo.StartPoints[CurPoint] & 0x0F) * 16, (MiscInfo.StartPoints[CurPoint + 1] & 0x0F) * 16, "S", 0xFF0000);
			}
			sprintf(Buffer, "%02X %02X", LevelInfo.isOverhead ? (MiscInfo.BossPoints[CurPoint]) : (MiscInfo.StartPoints[CurPoint]), LevelInfo.isOverhead ? (MiscInfo.BossPoints[CurPoint + 1]) : (MiscInfo.StartPoints[CurPoint + 1]));
			Graphics->DisplayText(336, 132, "X   Y");
			Graphics->DisplayText(336, 140, Buffer);
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		if (LockMouse) {
			SDL_WM_GrabInput(SDL_GRAB_ON);
			SDL_ShowCursor(SDL_DISABLE);
			SDL_SetEventFilter(DropExtraMouseEvents);
		} else {
			SDL_WM_GrabInput(SDL_GRAB_OFF);
			SDL_ShowCursor(SDL_ENABLE);
			SDL_SetEventFilter(NULL);
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_RIGHT) : {
						LevelInfo.isOverhead ? ((MiscInfo.BossPoints[CurPoint] += Delta) %= 0x80) : ((MiscInfo.StartPoints[CurPoint] += Delta) %= 0x80);
						Update = true;
						break;
					}
					case(SDLK_LEFT) : {
						LevelInfo.isOverhead ? ((MiscInfo.BossPoints[CurPoint] -= Delta) %= 0x80) : ((MiscInfo.StartPoints[CurPoint] -= Delta) %= 0x80);
						Update = true;
						break;
					}
					case(SDLK_DOWN) : {
						LevelInfo.isOverhead ? ((MiscInfo.BossPoints[CurPoint + 1] += Delta) %= 0x80) : ((MiscInfo.StartPoints[CurPoint + 1] += Delta) %= 0x80);
						Update = true;
						break;
					}
					case(SDLK_UP) : {
						LevelInfo.isOverhead ? ((MiscInfo.BossPoints[CurPoint + 1] -= Delta) %= 0x80) : ((MiscInfo.StartPoints[CurPoint + 1] -= Delta) %= 0x80);
						Update = true;
						break;
					}
					case(SDLK_m) : {
						LockMouse = !LockMouse;
						break;
					}
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: {
						break;
					}
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			case (SDL_MOUSEMOTION) : {
				if (!LockMouse) {
					break;
				}
				if (LevelInfo.isOverhead) {
					(MiscInfo.BossPoints[CurPoint] += (event.motion.xrel / 4)) %= 0x80;
					(MiscInfo.BossPoints[CurPoint + 1] += (event.motion.yrel / 4)) %= 0x80;
				} else {
					(MiscInfo.StartPoints[CurPoint] += (event.motion.xrel / 4)) %= 0x80;
					(MiscInfo.StartPoints[CurPoint + 1] += (event.motion.yrel / 4)) %= 0x80;
				}
				if ((event.motion.xrel / 4) || (event.motion.yrel / 4)) {
					Update = true;
				}
				break;
			}
			default: break;
		} // switch (event.type)
	} while (!Quit);
	if (LockMouse) {
		SDL_WM_GrabInput(SDL_GRAB_OFF);
		SDL_ShowCursor(SDL_ENABLE);
		SDL_SetEventFilter(NULL);
	}
}	

void BrowseBoss3(sMiscInfo &MiscInfo, cGFX *Graphics)
{
	Uint8 x = 0, y = 0;
	int Loop, Delta = 1;
	SDL_Event event;
	bool Update = true, Quit = false;
	char Buffer[80];
	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			Graphics->Lock();
			Graphics->Clear();
			Graphics->DisplayText(0, 0, "X  Y  P  C");
			for (Loop = 0; Loop < BOSS_3_SPAWN_PATTERN_LENGTH; Loop++) {
				sprintf(Buffer, "%02X %02X", MiscInfo.Boss3SXPattern[Loop], MiscInfo.Boss3SYPattern[Loop]);
				Graphics->DisplayText(0, Loop * 8 + 8, Buffer);
			}
			for (Loop = 0; Loop < BOSS_3_ATTACK_PATTERN_LENGTH; Loop += 2) {
				sprintf(Buffer, "%02X %02X %s", MiscInfo.Boss3APattern[Loop + 1], MiscInfo.Boss3APattern[Loop], BOSS3ATTACKS[MiscInfo.Boss3APattern[Loop]]);
				Graphics->DisplayText(48, Loop * 4 + 8, Buffer);
			}
			Graphics->DisplayText(x * 24 + 16, y * 8 + 8, "!");
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_LEFT): {
						--x %= 4;
						y %= ((x < 2) ? 16 : 10);
						Update = true;
						break;
					}
					case(SDLK_RIGHT): {
						++x %= 4;
						y %= ((x < 2) ? 16 : 10);
						Update = true;
						break;
					}
					case(SDLK_UP): {
						--y %= ((x < 2) ? 16 : 10);
						Update = true;
						break;
					}
					case(SDLK_DOWN): {
						++y %= ((x < 2) ? 16 : 10);
						Update = true;
						break;
					}
					case(SDLK_MINUS): {
						switch(x) {
							case(0) : {
								MiscInfo.Boss3SXPattern[y]--;
								if (MiscInfo.Boss3SXPattern[y] < 0x3) {
									MiscInfo.Boss3SXPattern[y] = 0xD;
								}
								break;
							}
							case(1) : {
								MiscInfo.Boss3SYPattern[y]--;
								if (MiscInfo.Boss3SYPattern[y] < 0x3) {
									MiscInfo.Boss3SYPattern[y] = 0xD;
								}
								break;
							}
							case(2) : {
								MiscInfo.Boss3APattern[y * 2 + 1] -= Delta;
								break;
							}
							case(3) : {
								MiscInfo.Boss3APattern[y * 2]--;
								if (MiscInfo.Boss3APattern[y * 2] < 1) {
									MiscInfo.Boss3APattern[y * 2] = 5;
								}
								break;
							}
						} // switch(x)
						Update = true;
						break;
					} // case(SDLK_MINUS)
					case(SDLK_EQUALS): {
						switch(x) {
							case(0) : {
								MiscInfo.Boss3SXPattern[y]++;
								if (MiscInfo.Boss3SXPattern[y] > 0xD) {
									MiscInfo.Boss3SXPattern[y] = 0x3;
								}
								break;
							}
							case(1) : {
								MiscInfo.Boss3SYPattern[y]++;
								if (MiscInfo.Boss3SYPattern[y] > 0xD) {
									MiscInfo.Boss3SYPattern[y] = 0x3;
								}
								break;
							}
							case(2) : {
								MiscInfo.Boss3APattern[y * 2 + 1] += Delta;
								break;
							}
							case(3) : {
								MiscInfo.Boss3APattern[y * 2]++;
								if (MiscInfo.Boss3APattern[y * 2] > 1) {
									MiscInfo.Boss3APattern[y * 2] = 1;
								}
								break;
							}
						} // switch(x)
						Update = true;
						break;
					} // case(SDLK_EQUALS)
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: {
						break;
					}
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			default: break;
		} // switch (event.type)
	} while (!Quit);
}

void BrowseBoss4(sMiscInfo &MiscInfo, cGFX *Graphics)
{
	Uint8 y = 0;
	int Loop;
	SDL_Event event;
	bool Update = true, Quit = false;
	char Buffer[80];
	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			Graphics->Lock();
			Graphics->Clear();
			for (Loop = 0; Loop < BOSS_4_ATTACK_PATTERN_LENGTH - 1; Loop++) {
				sprintf(Buffer, "%02X %s", MiscInfo.Boss4APattern[Loop], BOSS47ATTACKS[MiscInfo.Boss4APattern[Loop]]);
				Graphics->DisplayText(0, Loop * 8, Buffer);
			}
			Graphics->DisplayText(16, y * 8, "!");
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_UP): {
						--y %= BOSS_4_ATTACK_PATTERN_LENGTH - 1;
						Update = true;
						break;
					}
					case(SDLK_DOWN): {
						++y %= BOSS_4_ATTACK_PATTERN_LENGTH - 1;
						Update = true;
						break;
					}
					case(SDLK_MINUS): {
						--MiscInfo.Boss4APattern[y] %= 6;
						Update = true;
						break;
					}
					case(SDLK_EQUALS): {
						++MiscInfo.Boss4APattern[y] %= 6;
						Update = true;
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: {
						break;
					}
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			default: break;
		} // switch (event.type)
	} while (!Quit);
}

void BrowseBoss7(sMiscInfo &MiscInfo, cGFX *Graphics)
{
	Uint8 y = 0;
	int Loop;
	SDL_Event event;
	bool Update = true, Quit = false;
	char Buffer[80];
	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			Graphics->Lock();
			Graphics->Clear();
			for (Loop = 0; Loop < BOSS_7_ATTACK_PATTERN_LENGTH - 1; Loop++) {
				sprintf(Buffer, "%02X %s", MiscInfo.Boss7APattern[Loop], BOSS47ATTACKS[MiscInfo.Boss7APattern[Loop]]);
				Graphics->DisplayText(0, Loop * 8, Buffer);
			}
			Graphics->DisplayText(16, y * 8, "!");
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_UP): {
						--y %= BOSS_7_ATTACK_PATTERN_LENGTH - 1;
						Update = true;
						break;
					}
					case(SDLK_DOWN): {
						++y %= BOSS_7_ATTACK_PATTERN_LENGTH - 1;
						Update = true;
						break;
					}
					case(SDLK_MINUS): {
						--MiscInfo.Boss7APattern[y] %= 6;
						Update = true;
						break;
					}
					case(SDLK_EQUALS): {
						++MiscInfo.Boss7APattern[y] %= 6;
						Update = true;
						break;
					}
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: {
						break;
					}
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			default: break;
		} // switch (event.type)
	} while (!Quit);
}

void BrowseMisc(sMiscInfo &MiscInfo, cGFX *Graphics)
{
	Uint8 y = 0;
	int Delta = 1;
	SDL_Event event;
	bool Update = true, Quit = false;
	char Buffer[80];
	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			Graphics->Lock();
			Graphics->Clear();
			sprintf(Buffer, "%02X OVERHEAD ICE SECTION", MiscInfo.OverheadIce);
			Graphics->DisplayText(0, 0, Buffer); 
			sprintf(Buffer, "%02X TANK ICE SECTION", MiscInfo.TankIce); 
			Graphics->DisplayText(0, 8, Buffer); 
			sprintf(Buffer, "%02X BOSS 4 7 HP", MiscInfo.Boss47HP); 
			Graphics->DisplayText(0, 16, Buffer); 
			sprintf(Buffer, "%02X BOSS 2 6 HP", MiscInfo.Boss26HP); 
			Graphics->DisplayText(0, 24, Buffer); 
			sprintf(Buffer, "%02X BOSS 2 6 H SPEED", MiscInfo.Boss26HSpeed); 
			Graphics->DisplayText(0, 32, Buffer); 
			sprintf(Buffer, "%02X BOSS 2 6 V SPEED", MiscInfo.Boss26VSpeed); 
			Graphics->DisplayText(0, 40, Buffer); 
			sprintf(Buffer, "%02X BOSS 3 HP", MiscInfo.Boss3HP); 
			Graphics->DisplayText(0, 48, Buffer); 
			sprintf(Buffer, "%02X BOSS 1 HP", MiscInfo.Boss1HP); 
			Graphics->DisplayText(0, 56, Buffer); 
			sprintf(Buffer, "%02X BOSS 1 H SPEED", MiscInfo.Boss1HSpeed); 
			Graphics->DisplayText(0, 64, Buffer); 
			sprintf(Buffer, "%02X BOSS 1 V SPEED", MiscInfo.Boss1VSpeed); 
			Graphics->DisplayText(0, 72, Buffer); 
			sprintf(Buffer, "%02X BOSS 1 R SPEED", MiscInfo.Boss1RSpeed); 
			Graphics->DisplayText(0, 80, Buffer); 
			sprintf(Buffer, "%02X BOSS 1 L SPEED", MiscInfo.Boss1LSpeed); 
			Graphics->DisplayText(0, 88, Buffer); 
			sprintf(Buffer, "%02X BOSS 1 D SPEED", MiscInfo.Boss1DSpeed); 
			Graphics->DisplayText(0, 96, Buffer); 
			sprintf(Buffer, "%02X BOSS 1 U SPEED", MiscInfo.Boss1USpeed); 
			Graphics->DisplayText(0, 104, Buffer); 
			sprintf(Buffer, "%02X BOSS 5 HP", MiscInfo.Boss5HP); 
			Graphics->DisplayText(0, 112, Buffer); 
			sprintf(Buffer, "%02X BOSS 8 HP", MiscInfo.Boss8HP); 
			Graphics->DisplayText(0, 120, Buffer); 
			sprintf(Buffer, "%02X BOSS FINAL HP", MiscInfo.BossFinalHP); 
			Graphics->DisplayText(0, 128, Buffer); 
			Graphics->DisplayText(16, y * 8, "!");
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_UP): {
						--y %= NUM_MISC;
						Update = true;
						break;
					}
					case(SDLK_DOWN): {
						++y %= NUM_MISC;
						Update = true;
						break;
					}
					case(SDLK_MINUS): {
						switch(y) {
							case(0) : {
								--MiscInfo.OverheadIce %= 0x10;
								break;
							}
							case(1) : {
								--MiscInfo.TankIce %= 0x10;
								break;
							}
							case(2) : {
								MiscInfo.Boss47HP -= Delta;
								break;
							}
							case(3) : {
								MiscInfo.Boss26HP -= Delta;
								break;
							}
							case(4) : {
								MiscInfo.Boss26HSpeed -= Delta;
								break;
							}
							case(5) : {
								MiscInfo.Boss26VSpeed -= Delta;
								break;
							}
							case(6) : {
								MiscInfo.Boss3HP -= Delta;
								break;
							}
							case(7) : {
								MiscInfo.Boss1HP -= Delta;
								break;
							}
							case(8) : {
								MiscInfo.Boss1HSpeed -= Delta;
								break;
							}
							case(9) : {
								MiscInfo.Boss1VSpeed -= Delta;
								break;
							}
							case(10) : {
								MiscInfo.Boss1RSpeed -= Delta;
								break;
							}
							case(11) : {
								MiscInfo.Boss1LSpeed -= Delta;
								break;
							}
							case(12) : {
								MiscInfo.Boss1DSpeed -= Delta;
								break;
							}
							case(13) : {
								MiscInfo.Boss1USpeed -= Delta;
								break;
							}
							case(14) : {
								MiscInfo.Boss5HP -= Delta;
								break;
							}
							case(15) : {
								MiscInfo.Boss8HP -= Delta;
								break;
							}
							case(16) : {
								MiscInfo.BossFinalHP -= Delta;
								break;
							}
						} // switch(y)
						Update = true;
						break;
					} // case(SDLK_MINUS)
					case(SDLK_EQUALS): {
						switch(y) {
							case(0) : {
								++MiscInfo.OverheadIce %= 0x10;
								break;
							}
							case(1) : {
								++MiscInfo.TankIce %= 0x10;
								break;
							}
							case(2) : {
								MiscInfo.Boss47HP += Delta;
								break;
							}
							case(3) : {
								MiscInfo.Boss26HP += Delta;
								break;
							}
							case(4) : {
								MiscInfo.Boss26HSpeed += Delta;
								break;
							}
							case(5) : {
								MiscInfo.Boss26VSpeed += Delta;
								break;
							}
							case(6) : {
								MiscInfo.Boss3HP += Delta;
								break;
							}
							case(7) : {
								MiscInfo.Boss1HP += Delta;
								break;
							}
							case(8) : {
								MiscInfo.Boss1HSpeed += Delta;
								break;
							}
							case(9) : {
								MiscInfo.Boss1VSpeed += Delta;
								break;
							}
							case(10) : {
								MiscInfo.Boss1RSpeed += Delta;
								break;
							}
							case(11) : {
								MiscInfo.Boss1LSpeed += Delta;
								break;
							}
							case(12) : {
								MiscInfo.Boss1DSpeed += Delta;
								break;
							}
							case(13) : {
								MiscInfo.Boss1USpeed += Delta;
								break;
							}
							case(14) : {
								MiscInfo.Boss5HP += Delta;
								break;
							}
							case(15) : {
								MiscInfo.Boss8HP += Delta;
								break;
							}
							case(16) : {
								MiscInfo.BossFinalHP += Delta;
								break;
							}
						} // switch(y)
						Update = true;
						break;
					} // case(SDLK_EQUALS)
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: {
						break;
					}
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			default: break;
		} // switch (event.type)
	} while (!Quit);
}

void BrowseGateA(sMiscInfo &MiscInfo, cGFX *Graphics)
{
	Uint8 CurCharacter = 0, SubPalette = 0;
	Uint16 Delta = 1;
	bool Update = true, Quit = false;
	SDL_Event event;
	char Buffer[80];

	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			Graphics->Lock();
			Graphics->DisplayCharacter(0, 0, MiscInfo.GateAStructure[0], SubPalette);
			Graphics->DisplayCharacter(0, 8, MiscInfo.GateAStructure[1], SubPalette);
			Graphics->DisplayCharacter(8, 0, MiscInfo.GateAStructure[2], SubPalette);
			Graphics->DisplayCharacter(8, 8, MiscInfo.GateAStructure[3], SubPalette);
			Graphics->DisplayCharacterScale(0, 32, MiscInfo.GateAStructure[0], SubPalette, 4);
			Graphics->DisplayCharacterScale(0, 64, MiscInfo.GateAStructure[1], SubPalette, 4);
			Graphics->DisplayCharacterScale(32, 32, MiscInfo.GateAStructure[2], SubPalette, 4);
			Graphics->DisplayCharacterScale(32, 64, MiscInfo.GateAStructure[3], SubPalette, 4);
			Graphics->Square((CurCharacter / 2) * 8, (CurCharacter % 2) * 8, (CurCharacter / 2) * 8 + 7, (CurCharacter % 2) * 8 + 7, 0x7F7F7F);
			Graphics->Square((CurCharacter / 2) * 32, (CurCharacter % 2) * 32 + 32, (CurCharacter / 2) * 32 + 31, (CurCharacter % 2) * 32 + 63, 0x7F7F7F);
			sprintf(Buffer, "%02X %02X", MiscInfo.GateAStructure[0], MiscInfo.GateAStructure[2]);
			Graphics->DisplayText(80, 0, Buffer);
			sprintf(Buffer, "%02X %02X", MiscInfo.GateAStructure[1], MiscInfo.GateAStructure[3]);
			Graphics->DisplayText(80, 16, Buffer);
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_DOWN) : {
						--SubPalette %= 4;
						Update = true;
						break;
					}
					case(SDLK_UP) : {
						++SubPalette %= 4;
						Update = true;
						break;
					}
					case(SDLK_LEFT) : {
						--CurCharacter %= 4;
						Update = true;
						break;
					}
					case(SDLK_RIGHT) : {
						++CurCharacter %= 4;
						Update = true;
						break;
					}
					case(SDLK_MINUS) : {
						MiscInfo.GateAStructure[CurCharacter] -= Delta;
						Update = true;
						break;
					}
					case(SDLK_EQUALS) : {
						MiscInfo.GateAStructure[CurCharacter] += Delta;
						Update = true;
						break;
					}
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE):
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: break;
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			default: break;
		} // switch (event.type)
	} while (!Quit);

}

void BrowseGateB(sMiscInfo &MiscInfo, cGFX *Graphics)
{
	Uint8 CurCharacter = 0, SubPalette = 0;
	Uint16 Delta = 1;
	bool Update = true, Quit = false;
	SDL_Event event;
	char Buffer[80];

	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			Graphics->Lock();
			Graphics->DisplayCharacter(0, 0, MiscInfo.GateBStructure[0], SubPalette);
			Graphics->DisplayCharacter(0, 8, MiscInfo.GateBStructure[1], SubPalette);
			Graphics->DisplayCharacter(8, 0, MiscInfo.GateBStructure[2], SubPalette);
			Graphics->DisplayCharacter(8, 8, MiscInfo.GateBStructure[3], SubPalette);
			Graphics->DisplayCharacterScale(0, 32, MiscInfo.GateBStructure[0], SubPalette, 4);
			Graphics->DisplayCharacterScale(0, 64, MiscInfo.GateBStructure[1], SubPalette, 4);
			Graphics->DisplayCharacterScale(32, 32, MiscInfo.GateBStructure[2], SubPalette, 4);
			Graphics->DisplayCharacterScale(32, 64, MiscInfo.GateBStructure[3], SubPalette, 4);
			Graphics->Square((CurCharacter / 2) * 8, (CurCharacter % 2) * 8, (CurCharacter / 2) * 8 + 7, (CurCharacter % 2) * 8 + 7, 0x7F7F7F);
			Graphics->Square((CurCharacter / 2) * 32, (CurCharacter % 2) * 32 + 32, (CurCharacter / 2) * 32 + 31, (CurCharacter % 2) * 32 + 63, 0x7F7F7F);
			sprintf(Buffer, "%02X %02X", MiscInfo.GateBStructure[0], MiscInfo.GateBStructure[2]);
			Graphics->DisplayText(80, 0, Buffer);
			sprintf(Buffer, "%02X %02X", MiscInfo.GateBStructure[1], MiscInfo.GateBStructure[3]);
			Graphics->DisplayText(80, 16, Buffer);
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_DOWN) : {
						--SubPalette %= 4;
						Update = true;
						break;
					}
					case(SDLK_UP) : {
						++SubPalette %= 4;
						Update = true;
						break;
					}
					case(SDLK_LEFT) : {
						--CurCharacter %= 4;
						Update = true;
						break;
					}
					case(SDLK_RIGHT) : {
						++CurCharacter %= 4;
						Update = true;
						break;
					}
					case(SDLK_MINUS) : {
						MiscInfo.GateBStructure[CurCharacter] -= Delta;
						Update = true;
						break;
					}
					case(SDLK_EQUALS) : {
						MiscInfo.GateBStructure[CurCharacter] += Delta;
						Update = true;
						break;
					}
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE):
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: break;
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			default: break;
		} // switch (event.type)
	} while (!Quit);

}

void BrowseRLE(cGFX *Graphics, cRLE *RLE) {
	Uint8 CurRLE = 0;
	bool Update = true, Quit = false;
	SDL_Event event;

	do {
		if (Update) {
			Graphics->Lock();
			Graphics->Clear();
			RLE[CurRLE].SwitchTo();
			RLE[CurRLE].DisplayRLE(0, 0);
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch (event.type) {
			case (SDL_KEYDOWN) : {
				switch (event.key.keysym.sym) {
					case (SDLK_LEFT) :
					case (SDLK_LEFTBRACKET) : {
						if (CurRLE) {
							CurRLE--;
						} else {
							CurRLE = NUM_RLE - 1;
						}
						Update = true;
						break;
					}
					case (SDLK_RIGHT) :
					case (SDLK_RIGHTBRACKET) : {
						++CurRLE %= NUM_RLE;
						Update = true;
						break;
					}
					case (SDLK_ESCAPE) : 
					case (SDLK_q) :	{
						Quit = true;
					}
					default : break;
				}
				break;
			}
			case (SDL_QUIT) : {
				Quit = true;
				break;
			}
			case (SDL_MOUSEBUTTONDOWN) : {
				switch (event.button.button) {
					case (SDL_BUTTON_LEFT) :
					case (SDL_BUTTON_WHEELDOWN) : {
						if (CurRLE) {
							CurRLE--;
						} else {
							CurRLE = NUM_RLE - 1;
						}
						Update = true;
						break;
					}
					case (SDL_BUTTON_RIGHT) :
					case (SDL_BUTTON_WHEELUP) : {
						++CurRLE %= NUM_RLE;
						Update = true;
						break;
					}
					default : break;
				}
				break;
			}
			default : break;
		} // switch (event.type)
	} while (!Quit);
}

void BrowseEnemyStats(sMiscInfo &MiscInfo, cGFX *Graphics)
{
	Uint8 x = 0, y = 0;
	Uint32 Loop, Delta = 1;
	SDL_Event event;
	bool Update = true, Quit = false;
	char Buffer[80];
	Uint8 DropMap[9] = { 0x21, 0x22, 0x25, 0x26, 0x23, 0x24, 0x27, 0x28, 0x29 };

	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			Graphics->Lock();
			Graphics->Clear();
			Graphics->DisplayText(0, 0, "HP  DMG DR  UN");
			for (Loop = 0; Loop < TankEnemyStatsLength; Loop += 4) {
				sprintf(Buffer, "%02X  %02X  %02X  %02X", MiscInfo.TankEnemyStats[Loop], MiscInfo.TankEnemyStats[Loop + 1], MiscInfo.TankEnemyStats[Loop + 2], MiscInfo.TankEnemyStats[Loop + 3]);
				Graphics->DisplayText(0, Loop * 2 + 8, Buffer);
				Graphics->DisplayText(128, Loop * 2 + 8, TankThingNames[Loop / 4]);
				Graphics->DisplayText(288, Loop * 2 + 8, TankThingNames[DropMap[MiscInfo.TankEnemyStats[Loop + 2] - 0x2C]]);
			}
			Graphics->DisplayText(x * 32 + 16, y * 8 + 8, "!");
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_LEFT): {
						--x %= 4;
						Update = true;
						break;
					}
					case(SDLK_RIGHT): {
						++x %= 4;
						Update = true;
						break;
					}
					case(SDLK_UP): {
						if (y) {
							y--;
						} else {
							y = 0x1C;
						}
						Update = true;
						break;
					}
					case(SDLK_DOWN): {
						++y %= 0x1D;
						Update = true;
						break;
					}
					case(SDLK_MINUS): {
						if (x == 2) {
							MiscInfo.TankEnemyStats[y * 4 + x]--;
							if (MiscInfo.TankEnemyStats[y * 4 + x] < 0x2C) {
								MiscInfo.TankEnemyStats[y * 4 + x] = 0x34;
							}
						} else {
							MiscInfo.TankEnemyStats[y * 4 + x] -= Delta;
						}
						Update = true;
						break;
					} // case(SDLK_MINUS)
					case(SDLK_EQUALS): {
						if (x == 2) {
							MiscInfo.TankEnemyStats[y * 4 + x]++;
							if (MiscInfo.TankEnemyStats[y * 4 + x] > 0x34) {
								MiscInfo.TankEnemyStats[y * 4 + x] = 0x2C;
							}
						} else {
							MiscInfo.TankEnemyStats[y * 4 + x] += Delta;
						}
						Update = true;
						break;
					} // case(SDLK_EQUALS)
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x10;
						break;
					} 
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: {
						break;
					}
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			case(SDL_KEYUP) : {
				switch (event.key.keysym.sym) {
					case(SDLK_LSHIFT) :
					case(SDLK_RSHIFT) : {
						Delta = 0x01;
						break;
					}
					default: break;
				}
				break;
			}
			default: break;
		} // switch (event.type)
	} while (!Quit);
	
}

void BrowsePalette(cLevel &Level, cGFX *Graphics)
{
	Uint8 x = 0;
	Uint32 Loop;
	SDL_Event event;
	bool Update = true, Quit = false;
	char Buffer[80];

	Graphics->Lock();
	Graphics->Clear();
	Graphics->Unlock();

	do {
		if (Update) {
			Graphics->Lock();
			Graphics->Clear();
			for (Loop = 0; Loop < 16; Loop++) {
				Graphics->Box(Loop * 16, 0, Loop * 16 + 15, 15, NesColors[Level.GetPalette(Loop)]);
				sprintf(Buffer, "%02X", Level.GetPalette(Loop));
				Graphics->DisplayText(Loop * 16, 20, Buffer);
			}
			Graphics->Square(x * 16, 0, x * 16 + 15, 15, 0xFFFFFF);
			Graphics->Unlock();
			Graphics->Update();
			Update = false;
		}
		SDL_WaitEvent(&event);
		switch(event.type) {
			case(SDL_QUIT) : {
				Quit = true;
				break;
			}
			case(SDL_KEYDOWN) : {
				switch(event.key.keysym.sym) {
					case(SDLK_LEFT): {
						--x %= 0x10;
						Update = true;
						break;
					}
					case(SDLK_RIGHT): {
						++x %= 0x10;
						Update = true;
						break;
					}
					case(SDLK_MINUS): {
						Level.SetPalette(x, Level.GetPalette(x) - 1);
						Update = true;
						break;
					} // case(SDLK_MINUS)
					case(SDLK_EQUALS): {
						Level.SetPalette(x, Level.GetPalette(x) + 1);
						Update = true;
						break;
					} // case(SDLK_EQUALS)
					case (SDLK_RETURN) : {
						if (event.key.keysym.mod && KMOD_ALT) {
							Graphics->ToggleFullScreen();
							Update = true;
						}
						break;
					}
					case(SDLK_ESCAPE): 
					case(SDLK_q) : {
						Quit = true;
						break;
					}
					default: {
						break;
					}
				} // switch (event.key.keysym.sym)
				break;
			} // case (SDL_KEYDOWN)
			default: break;
		} // switch (event.type)
	} while (!Quit);
	// Really, really kludgy, but I want this done dammit
	for (Loop = 0; Loop < Level.GetLevelInfo().NumUSB; Loop++) {
		Level.BuildUSBGFX(Loop);
	}
	Level.SwitchTo();
}


int DropExtraMouseEvents(const SDL_Event *Event)
{
	return 1;
	if (Event->type == SDL_MOUSEMOTION) {
		if (SDL_PeepEvents(NULL, 1, SDL_PEEKEVENT, SDL_EVENTMASK(SDL_MOUSEMOTION))) {
			return 0;
		}
		return 1;
	} 
	return 1;
}
