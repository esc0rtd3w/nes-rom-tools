MegaFLE - Guide
===============
version 0.1
for MegaFLE 0.4

This is the guide for editing MM3, MM4 and MM5 using MegaFLE.
It is to be updated in later versions.

The html-file to start in is "guide.htm"