Capcom Sprite Assembler
made by Matrixz

what
----

I worked on this partially to help me create my own hack for megaman 4.
The sprite arrangement data is similar in many capcom games, so i wrote a
module system which can (to a degree) configure this editor to work for
other capcom games. They are plain .txt files, so they may be changed
to work for hacks where sprite banks are moved.

If anyone reports a bug or request a feature, or request support for a game, i will
most likely not fix it/add it.

Its possible to use the modules to configure the editor so that CHR is loaded
from a offset for each sprite, so the sprites show up with the right graphics. 
But the games have only few or default settings for this, so few sprites will show right.
(And i will most likely not update the modules).

Supported/Partially supported games
-----------------------------------

Darkwing Duck
Duck Tales (no insert/delete)
Mega Man 2 (no insert/delete)
Mega Man 3 (no insert/delete)
Mega Man 4
Mega Man 5 (no insert/delete)
Mighty Final Fight (no insert/delete)

Games that are not supported and why
------------------------------------

Megaman - Uses a different arrangement of pointer bytes. Number of frames & animation
	speed is spliced into the same byte. But what makes it totally different is
	that X and Y coordinates are decided by one byte functioning as an index
	into two tables with presets for the X and Y values respectively.
Mega Man 6 - Each frame has its own length byte. Too much work to restructure the
	editor for this.
Bionic Commando - Entirely different sprite engine.
Duck Tales 2 - Graphics are compressed. Thats a problem. 

I haven't checked out games except these, so its possible certain games could be supported
by writing a .txt file alone. (such as Chip n' Dale, Chip n' Dale 2, Little Nemo, and Strider).

What you can touch and not
--------------------------

It may not be equally clear if something you touch in the editor will affect the
loaded ROM. Here are some pointers:

 * Editing the tiles themselves will modify the ROM's data.
 * Editing the palette will not modify the ROM.
 * Changing "animation speed" (1x, 0.5x, 2x) will not affect the ROM.

Modification Functions
======================

Sprite Properties
-----------------

"Address:" (Below Sprite)

	Allows you to directly change the memory pointer of the current Sprite ID.
	Dont play with it unless you know what youre doing.

"Frame Page"

	This is a property associated with the sprite.
	For Megaman 2, it's inchangable, so don't worry about it.
	There are two pages of Frame ID's. (2 * 256).
	This decides which page to use for the sprite.

"Delay"

	Change the tempo of the animated sprite.

"Animation Frames:" - Add

	Add a frame to the animation.

"Animation Frames:" - Del

	Remove a frame from the animation.



Tile Modification
-----------------

"Center Sprite"

	Centers the whole sprite, changing all tile's X and Y coordinates.

"New Tile"

	Add a tile to the frame.

"Remove Tile"

	Remove current tile from the frame.

"BG Priority"

	Toggles the BG Priority bit for the current tile.
	Im not sure if this has any efffect.


Pattern Editor
--------------

"Copy"
	Copies the current tile to the clipboard.

"Paste"

	Pastes the clipboard over the current tile.

Frame Selecter
--------------

"Find Unused"

	Seek for the next Frame ID which is not used by any Sprite.

"Address" TextBox:

	Allows you to directly change the selected Frame ID's memory pointer,
	if you so desire..

"Kill Data"

	Removes all the Frame ID's data, freeing some bytes in the bank.
	It's pointer is set to 0.
	No other kind of data is affected.

"Clean Up Data"
---------------

Removes unused bytes from the current bank, or all data if there is only 1 bank.
Use this if there is no free space left.. as there is usually unused data lying
around.

Keys
====

Insert - insert a tile (same as "New Tile" button).
Delete - delete a tile (Same as "Remove Tile" button).

Editing Options
===============

"Top tile priority" & "Bottom tile priority"

	If tiles overlap each other, this decides which tile is given priority when
	hovering the mouse over the tiles and clicking the left mousebutton.
	When a tile is inserted, this option is automatically snapped to "Bottom
	tile priority", becouse the new tile is placed at "the bottom", below
	any other tiles.


Contact
-------
mail: ingegjoestoel@hotmail.com