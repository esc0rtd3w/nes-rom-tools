using CadEditor;
using System.Collections.Generic;
using System.Drawing;

public class Config
{
  public string getFileName()      {  return "Dune - The Battle for Arrakis (U) [!].bin";     }
  public string getDumpName()      { return "";                                               }
  public string getConfigName()    { return "settings_sega_dune_2/Settings_Dune2.cs";         }
  public bool showDumpFileField()  { return false;  }
}